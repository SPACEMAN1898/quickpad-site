#!/usr/bin/env bash
# Quickpad installer for any Linux distro. Detects the package manager and session type.
# Usage: ./install-linux.sh [--autostart] [--no-dictation]
set -e
cd "$(dirname "$0")"

# The same rules as pick_backend() in quickpad.py: Hyprland, or a Wayland session (the session type says so, or there
# is a Wayland display and no X display).
WAYLAND=0
if [ -n "$HYPRLAND_INSTANCE_SIGNATURE" ] || [ "$XDG_SESSION_TYPE" = "wayland" ] \
   || { [ -n "$WAYLAND_DISPLAY" ] && [ -z "$DISPLAY" ]; }; then WAYLAND=1; fi
TOOL=xdotool; [ "$WAYLAND" = 1 ] && TOOL=wtype

# KDE Plasma on Wayland (Kubuntu 25.10 and later log in to it): wtype can't work there, because KDE's compositor has
# no virtual-keyboard protocol. Quickpad types through KDE's remote-control permission instead, which it reaches with
# python3-gi. xdotool is still wanted, to bring the panel to the front. XDG_CURRENT_DESKTOP is a list ("KDE",
# "KDE:Plasma", "KDE;Plasma"): KDE is one of its names, in any case.
KDE_WAYLAND=0
if [ "$WAYLAND" = 1 ] && [ -z "$HYPRLAND_INSTANCE_SIGNATURE" ]; then
  DESKTOPS=":$(printf '%s' "${XDG_CURRENT_DESKTOP:-}" | tr 'a-z;' 'A-Z:'):"
  case "$DESKTOPS" in *:KDE:*) KDE_WAYLAND=1; TOOL=xdotool ;; esac
fi
GI=""

# The extra packages on each line are for dictation: a private Python space for its engine, and the microphone.
if   command -v apt    >/dev/null; then [ "$KDE_WAYLAND" = 1 ] && GI="python3-gi"
  sudo apt install -y python3-tk "$TOOL" python3-venv libportaudio2 alsa-utils $GI
elif command -v pacman >/dev/null; then [ "$KDE_WAYLAND" = 1 ] && GI="python-gobject"
  sudo pacman -S --needed --noconfirm python tk "$TOOL" portaudio alsa-utils $GI
elif command -v dnf    >/dev/null; then [ "$KDE_WAYLAND" = 1 ] && GI="python3-gobject"
  sudo dnf install -y python3-tkinter "$TOOL" portaudio alsa-utils $GI
elif command -v zypper >/dev/null; then [ "$KDE_WAYLAND" = 1 ] && GI="python3-gobject"
  sudo zypper install -y python3-tk "$TOOL" portaudio alsa-utils $GI
else echo "Install python3 with tkinter and $TOOL using your package manager, then re-run."; exit 1
fi

if [ -n "$HYPRLAND_INSTANCE_SIGNATURE" ] && [ -f install-omarchy.sh ]; then
  exec bash install-omarchy.sh "$@"
fi

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
install -m 755 quickpad.py "$HOME/.local/bin/quickpad"

cat > "$HOME/.local/share/applications/quickpad.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Quickpad
Comment=Button panel that types text and keystrokes
Exec=$HOME/.local/bin/quickpad
Icon=accessories-text-editor
StartupWMClass=Quickpad
Terminal=false
Categories=Utility;
EOF

if [[ " $* " == *" --autostart "* ]]; then
  mkdir -p "$HOME/.config/autostart"
  cp "$HOME/.local/share/applications/quickpad.desktop" "$HOME/.config/autostart/"
fi

[ "$XDG_CURRENT_DESKTOP" = "GNOME" ] && [ "$WAYLAND" = 1 ] && \
  echo "Note: GNOME on Wayland blocks simulated typing. Use the 'GNOME on Xorg' session for Quickpad."
[ "$KDE_WAYLAND" = 1 ] && \
  echo "Note: the first time a button types, KDE asks whether Quickpad may type for you. Choose Allow."

if [[ " $* " != *" --no-dictation "* ]]; then
  echo "Setting up dictation (a few minutes; needs the internet)…"
  "$HOME/.local/bin/quickpad" --setup-dictation || echo "Dictation can be set up later in Settings > Dictation."
fi

echo "Installed. Launch with: quickpad"

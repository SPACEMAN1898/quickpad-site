#!/usr/bin/env bash
# Quickpad installer for Linux Mint (and other Debian/Ubuntu-based X11 desktops).
# Usage: ./install-mint.sh [--autostart] [--no-dictation]
set -e
cd "$(dirname "$0")"

# python3-venv + libportaudio2 + alsa-utils: Quickpad's own dictation (its private engine space and the microphone)
# python3-gi: how Quickpad reaches KDE's permission window when this is run on Kubuntu's Wayland session
sudo apt install -y python3-tk xdotool python3-gi python3-venv libportaudio2 alsa-utils

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
install -m 755 quickpad.py "$HOME/.local/bin/quickpad"

cat > "$HOME/.local/share/applications/quickpad.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Quickpad
Comment=Button panel that types text and keystrokes
Exec=$HOME/.local/bin/quickpad
Icon=accessories-text-editor
StartupWMClass=Quickpad
Terminal=false
Categories=Utility;
EOF

if [[ " $* " == *" --autostart "* ]]; then
  mkdir -p "$HOME/.config/autostart"
  cp "$HOME/.local/share/applications/quickpad.desktop" "$HOME/.config/autostart/"
  echo "Quickpad will start on login."
fi

if [ "${XDG_SESSION_TYPE:-x11}" = "wayland" ]; then
  case ":${XDG_CURRENT_DESKTOP:-}:" in
    *:KDE:*) echo "Note: KDE on Wayland. The first time a button types, KDE asks whether Quickpad may type for you. Choose Allow." ;;
    *) echo "Note: Wayland session detected. Install wtype too (sudo apt install wtype), or log in with X11." ;;
  esac
fi

if [[ " $* " != *" --no-dictation "* ]]; then
  echo
  echo "Setting up dictation (a few minutes; needs the internet)…"
  "$HOME/.local/bin/quickpad" --setup-dictation || echo "Dictation can be set up later in Settings > Dictation."
fi

echo "Installed. Open 'Quickpad' from the menu, or run: quickpad"

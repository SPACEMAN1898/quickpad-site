#!/bin/bash
# Quickpad installer for macOS. Double-click this file in Finder (or run it in Terminal).
set -e
cd "$(dirname "$0")"

# Find a Python 3 whose Tk actually works (Apple's /usr/bin/python3 Tk is too old).
PY=""
for p in /opt/homebrew/bin/python3 /usr/local/bin/python3 python3; do
  if command -v "$p" >/dev/null 2>&1 && "$p" -c "import tkinter; assert tkinter.TkVersion >= 8.6" 2>/dev/null; then
    PY="$(command -v "$p")"; break
  fi
done

if [ -z "$PY" ]; then
  if command -v brew >/dev/null; then
    brew install python-tk
    PY="$(brew --prefix)/bin/python3"
  else
    echo "Need Python 3 with Tk 8.6. Install Homebrew (https://brew.sh) then run: brew install python-tk"
    exit 1
  fi
fi

APPDIR="$HOME/Applications/Quickpad.app"
mkdir -p "$APPDIR/Contents/MacOS" "$APPDIR/Contents/Resources"
cp quickpad.py "$APPDIR/Contents/Resources/quickpad.py"
[ -f assets/Quickpad.icns ] && cp assets/Quickpad.icns "$APPDIR/Contents/Resources/Quickpad.icns"

cat > "$APPDIR/Contents/MacOS/Quickpad" <<EOF
#!/bin/bash
exec "$PY" "\$(dirname "\$0")/../Resources/quickpad.py"
EOF
chmod +x "$APPDIR/Contents/MacOS/Quickpad"

cat > "$APPDIR/Contents/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Quickpad</string>
  <key>CFBundleIdentifier</key><string>com.praxentis.quickpad</string>
  <key>CFBundleExecutable</key><string>Quickpad</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleIconFile</key><string>Quickpad.icns</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>NSMicrophoneUsageDescription</key><string>Quickpad listens when you click a Dictate button, and types what you say. It is worked out on this Mac and never sent anywhere.</string>
</dict></plist>
EOF

# Dictation. Macs with an M chip get a ready-made engine; an Intel Mac has to build it, which needs the Xcode
# command line tools and cmake. If that fails Quickpad still works, and Settings > Dictation can try again later.
if [ "$1" != "--no-dictation" ]; then
  echo
  echo "Setting up dictation (a few minutes; needs the internet)…"
  "$PY" "$APPDIR/Contents/Resources/quickpad.py" --setup-dictation || echo "Dictation can be set up later in Settings > Dictation."
fi

echo
echo "Installed to ~/Applications/Quickpad.app"
echo
echo "One-time step: macOS must allow Quickpad to type for you."
echo "  System Settings > Privacy & Security > Accessibility: turn on Quickpad (and Terminal if you launch from it)."
echo "  The first button press may also ask to let it control System Events: click OK."
echo "  The first time you dictate, macOS asks to let Quickpad use the microphone: click Allow."
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility" 2>/dev/null || true
open "$APPDIR"

#!/usr/bin/env python3
"""
Quickpad: a TypeItIn-style button panel for Linux, macOS and Windows.

Click a button and it types text and/or presses keys in the window you were
last using. Buttons are grouped into families and edited in a built-in editor.
Text steps understand TypeItIn-style commands such as {Enter}, {Tab},
{Date dd/MM/yyyy}, {List A,B,C} and {Paste ...} — see COMMAND_HELP below.

Typing backend is picked automatically:
  Linux X11 (Mint etc.)    xdotool
  Hyprland (Omarchy)       hyprctl + wtype
  Other Wayland            wtype (panel hides briefly to hand focus back)
  macOS                    osascript / System Events (needs Accessibility permission)
  Windows                  built-in SendInput (no extra installs)

Config: ~/.config/quickpad/buttons.json  (Windows: %APPDATA%\\Quickpad\\buttons.json)
Portable: put an empty file named portable.txt next to quickpad.py and the
buttons are stored beside it in quickpad-data/ (e.g. on a USB stick).
"""

import atexit
import base64
import binascii
import collections
import configparser
import contextlib
import copy
import ctypes
import ctypes.util
import datetime
import glob
import hashlib
import hmac
import http.client
import http.server
import io
import ipaddress
import json
import os
import logging
import logging.handlers
import ntpath
import platform
import plistlib
import queue
import re
import secrets
import select
import shlex
import shutil
import socket
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import zipfile
import tkinter as tk
import tkinter.font as tkfont
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from tkinter import ttk, messagebox, colorchooser, filedialog, simpledialog

APP = "Quickpad"
VERSION = "3.4.1"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PORTABLE = os.path.exists(os.path.join(SCRIPT_DIR, "portable.txt"))
if PORTABLE:
    DEFAULT_DIR = os.path.join(SCRIPT_DIR, "quickpad-data")
elif sys.platform.startswith("win"):
    DEFAULT_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), APP)
else:
    DEFAULT_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "quickpad")
POINTER_PATH = os.path.join(DEFAULT_DIR, "data-folder.txt")   # optional: "keep my buttons in this other folder"


def _read_pointer():
    if PORTABLE:
        return ""
    try:
        with open(POINTER_PATH, encoding="utf-8") as f:
            path = f.read().strip()
    except (OSError, ValueError):
        return ""
    return path if path and os.path.isdir(path) else ""


CONFIG_DIR = _read_pointer() or DEFAULT_DIR
CONFIG_PATH = os.path.join(CONFIG_DIR, "buttons.json")
LOCAL_BACKUP_DIR = os.path.join(CONFIG_DIR, "backups")


def use_data_dir(path):
    """Point Quickpad at a different data folder from now on ('' = back to the default folder)."""
    global CONFIG_DIR, CONFIG_PATH, LOCAL_BACKUP_DIR
    if not PORTABLE:
        os.makedirs(DEFAULT_DIR, exist_ok=True)
        if path and os.path.abspath(path) != os.path.abspath(DEFAULT_DIR):
            with open(POINTER_PATH, "w", encoding="utf-8") as f:
                f.write(os.path.abspath(path))
        elif os.path.exists(POINTER_PATH):
            os.remove(POINTER_PATH)
    CONFIG_DIR = (os.path.abspath(path) if path and not PORTABLE else DEFAULT_DIR)
    CONFIG_PATH = os.path.join(CONFIG_DIR, "buttons.json")
    LOCAL_BACKUP_DIR = os.path.join(CONFIG_DIR, "backups")


# Per-computer state, kept even when the data folder is shared between computers.
LOCAL_DIR = DEFAULT_DIR
PENDING_PATH = os.path.join(LOCAL_DIR, "update-pending.json")       # "an update was just installed"
PREVIOUS_PATH = os.path.join(LOCAL_DIR, "quickpad-previous.py")     # the version before the update
BAD_VERSIONS_PATH = os.path.join(LOCAL_DIR, "bad-versions.txt")     # versions that failed to start here
LOG_PATH = os.path.join(LOCAL_DIR, "quickpad.log")
STARTED_PATH = os.path.join(LOCAL_DIR, "child-started")             # written once the panel is up (see main())


def _quiet_remove(path):
    try:
        os.remove(path)
    except OSError:
        pass


def _probation_guard():
    """First launch after an update: run the app as a child process. If it dies early, put the previous version
    back and start that instead, so a bad release can never leave the computer without a working Quickpad.
    Standard library only, and placed early so it still works if the new code fails while loading."""
    if __name__ != "__main__" or "--child" in sys.argv or "--setup-dictation" in sys.argv or not os.path.exists(PENDING_PATH):
        return
    try:
        with open(PENDING_PATH, encoding="utf-8") as f:
            info = json.load(f)
    except (OSError, ValueError):
        info = None
    if not info or info.get("to") != VERSION or not os.path.exists(PREVIOUS_PATH):
        _quiet_remove(PENDING_PATH)          # stale marker, or nothing to fall back to: just run normally
        return
    me = os.path.abspath(__file__)
    try:
        seconds = float(os.environ.get("QUICKPAD_PROBATION_SECONDS", "60"))
    except ValueError:
        seconds = 60.0
    err_path = os.path.join(LOCAL_DIR, "last-start-error.txt")
    _quiet_remove(STARTED_PATH)
    try:
        err = open(err_path, "wb")
    except OSError:
        return                                # can't watch it (disk full / read-only): just start normally
    with err:
        proc = subprocess.Popen([sys.executable, me, "--child"] + sys.argv[1:], stderr=err)
        start = time.time()
        while proc.poll() is None:
            if time.time() - start > seconds:
                _quiet_remove(PENDING_PATH)  # it has run long enough: the update is fine
                sys.exit(proc.wait())
            time.sleep(0.25)
    rc = proc.returncode
    try:
        with open(err_path, encoding="utf-8", errors="replace") as f:
            tail = f.read()[-1500:]
    except OSError:
        tail = ""
    came_up = os.path.exists(STARTED_PATH)
    native_crash = rc in (-4, -6, -7, -8, -11) or rc >= 0xC0000000     # SIGILL/ABRT/BUS/FPE/SEGV, Windows access violation etc.
    # Roll back only if the new version really failed: it never got as far as showing the panel, it died with a Python
    # traceback, or it crashed natively. A normal quit, logging off, or the user ending the task are not failures.
    failed = rc != 0 and (native_crash or not came_up or "Traceback (most recent call last)" in tail) \
        and rc not in (-1, -2, -9, -15)
    if not failed:
        _quiet_remove(PENDING_PATH)
        sys.exit(rc if rc >= 0 else 0)
    try:
        shutil.copy2(me, os.path.join(LOCAL_DIR, f"quickpad-failed-{VERSION}.py"))
        tmp = me + ".rollback"
        shutil.copy2(PREVIOUS_PATH, tmp)
        os.replace(tmp, me)
        with open(BAD_VERSIONS_PATH, "a", encoding="utf-8") as f:
            f.write(VERSION + "\n")
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} ERROR update to v{VERSION} failed to start (exit {rc}"
                    f"{'' if came_up else ', never showed the panel'}); put the previous version back.\n{tail}\n")
    except OSError:
        sys.exit(rc)                          # couldn't roll back; nothing more we can safely do
    _quiet_remove(PENDING_PATH)
    if shutil.which("notify-send"):
        subprocess.run(["notify-send", "Quickpad", f"The update to v{VERSION} didn't start properly, so the "
                        "previous version was put back. Nothing was lost."], check=False)
    os.execv(sys.executable, [sys.executable, me] + [a for a in sys.argv[1:] if a != "--child"])


_probation_guard()

KEEP_BACKUPS = 30
# Settings that belong to one computer: never written into a backup, never overwritten by a restore.
MACHINE_SETTINGS = ("geometry", "fixed_geometry", "position_mode", "backup_dir", "last_backup_folder", "actions_seeded",
                    "password_hash", "password_salt", "lock_on_start", "lock_on_restore", "show_on_start",
                    "dictation_model", "dictation_device")      # which model is downloaded / which microphone: this PC only
# Updates come from one unlisted (secret) gist holding just this file, so the private repo stays private and no
# computer needs a token. `./release.sh` publishes to it after a merge.
GIST_ID = "7abfcb63a7a23e1ecd6e4847fe208b67"
UPDATE_URL = f"https://gist.githubusercontent.com/SPACEMAN1898/{GIST_ID}/raw/quickpad.py"
# The gist's raw quickpad.py.sig holds a base64 RSA-SHA256 (PKCS#1 v1.5) signature over the exact bytes of
# quickpad.py, made by `release.sh` with the private key Nick keeps outside this repo. An update that doesn't verify
# against this public key is never installed — see verify_release_signature() and HANDOFF.md ("Update signing").
SIG_URL = UPDATE_URL + ".sig"
# The frozen Mac and Windows builds (PyInstaller) have no quickpad.py to replace and sys.executable is their own
# binary, not a generic interpreter, so they update differently: a signed Quickpad-<platform>.zip from the repo's
# GitHub Releases, verified with the same key and release.sh step as above, then handed to a small relauncher
# script (see relauncher_script()) that swaps the build once Quickpad quits. Worked out at call time, not stored as
# a constant here - the same quickpad.py source is frozen separately on each platform, so a value fixed at import
# time would be wrong on whichever platform it wasn't computed on.
def app_update_url():
    asset = "Quickpad-mac.zip" if sys.platform == "darwin" else "Quickpad-windows.zip"
    return f"https://github.com/SPACEMAN1898/quickpad/releases/latest/download/{asset}"


def app_sig_url():
    return app_update_url() + ".sig"
RELEASE_PUBLIC_KEY_E = 65537
RELEASE_PUBLIC_KEY_N = int(
    "d7723fb0d132327cd343785dc6489551a144319c19d34a08a51b4ce18d6c7d9883410b91769c4540835cf7595fdd42690388758936d14a"
    "4a2b983938aaecfee73b89c1d2515065442d5a2146701c02524240f35ce0fe4e1b96a09ee3dfbed8206355e709a4c16a010b40afac2dd8"
    "f9c094dfa14bbf369fb0809b600f677f9cbe4cbf939e19c6f5b816e9a92e768ac8f1bb49275bfcac94be74d9b90f50b5a9772baec34c39"
    "50dab0bef62b92023e4466dee609769d0a83a0282403e04bb07171c565fc0d42cf69e9b70da51413d8398b9fc6dc10770031bf2e04aa34"
    "61a408fe06d141c09dcfe0c5f0e9e0945fdb981513f902962c431fe82a39f949dba58f9517e92c22d1843034a276a892764bc4f81311be"
    "8d8dc198a7ce69eb784293fe7425bf79d700caec9436974584c820dbf2d8cfff2f97cab5001cdc4ee302b58842d458c033c2742b00cfe4"
    "3224f7799fecd3ee7b2af9f48da12ead228ea37b5c0256cf61b688523ce9086fd77e945d7e3258efeca170400e4866bb031f5b9793bb",
    16)
# DER prefix for a SHA-256 DigestInfo (RFC 8017 Note 1), the fixed bytes that precede the raw hash in PKCS#1 v1.5.
_RSA_SHA256_DIGESTINFO_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


def _rsa_pkcs1v15_sha256_verify(message, signature, n=RELEASE_PUBLIC_KEY_N, e=RELEASE_PUBLIC_KEY_E):
    """Textbook RSA / PKCS#1 v1.5 signature check (RFC 8017 §8.2.2), stdlib-only so the running app can verify an
    update without any third-party crypto library. Matches what `openssl dgst -sha256 -sign` produces."""
    k = (n.bit_length() + 7) // 8
    if len(signature) != k:
        return False
    s = int.from_bytes(signature, "big")
    if s >= n:
        return False
    em = pow(s, e, n).to_bytes(k, "big")
    t = _RSA_SHA256_DIGESTINFO_PREFIX + hashlib.sha256(message).digest()
    ps_len = k - 3 - len(t)
    if ps_len < 8:
        return False
    expected = b"\x00\x01" + b"\xff" * ps_len + b"\x00" + t
    return hmac.compare_digest(em, expected)


def verify_release_signature(data, signature_text):
    """True if `signature_text` (base64) is a valid signature over `data` from the release signing key."""
    try:
        sig = base64.b64decode(signature_text.strip(), validate=True)
    except (ValueError, binascii.Error):
        return False
    return _rsa_pkcs1v15_sha256_verify(data, sig)
ALL_FAMILIES = "All families"
IS_MAC = sys.platform == "darwin"

# Colours. `apply_theme()` swaps these before any window is built (changing the look restarts Quickpad), so the
# rest of the file just reads the names.
THEMES = {
    "light": {"INK": "#1b1f24", "APP_BG": "#eef0f3", "FOCUS_RING": "#0b57d0", "MUTED": "#5f6b7a", "CARD": "#ffffff",
              "EDGE": "#6b7480", "HOVER": "#e2e7ec", "PRESS": "#c9d0d8", "SB": "#c3cad2", "SB_TROUGH": "#dde1e6",
              "SB_EDGE": "#9aa3ad", "SB_ACTIVE": "#aab3bd", "SOLID": "#1b1f24", "SOLID_TEXT": "#ffffff",
              "RING": 2},
    "dark": {"INK": "#e8ebef", "APP_BG": "#1f2329", "FOCUS_RING": "#6cb0ff", "MUTED": "#a3adb8", "CARD": "#2b3038",
             "EDGE": "#8b95a1", "HOVER": "#39404a", "PRESS": "#4a525e", "SB": "#4a525e", "SB_TROUGH": "#2b3038",
             "SB_EDGE": "#6b7480", "SB_ACTIVE": "#5d6674", "SOLID": "#0e1114", "SOLID_TEXT": "#ffffff", "RING": 2},
    "contrast": {"INK": "#ffffff", "APP_BG": "#000000", "FOCUS_RING": "#ffe600", "MUTED": "#dcdcdc", "CARD": "#000000",
                 "EDGE": "#ffffff", "HOVER": "#333333", "PRESS": "#555555", "SB": "#ffffff", "SB_TROUGH": "#000000",
                 "SB_EDGE": "#ffffff", "SB_ACTIVE": "#ffe600", "SOLID": "#000000", "SOLID_TEXT": "#ffffff", "RING": 3},
}
THEME_NAMES = {"Light (standard)": "light", "Dark": "dark", "High contrast (black and white)": "contrast"}
THEME = "light"
INK = APP_BG = FOCUS_RING = MUTED = CARD = EDGE = HOVER = PRESS = SB = SB_TROUGH = SB_EDGE = SB_ACTIVE = ""
SOLID = SOLID_TEXT = ""
RING = 2


def apply_theme(name):
    """Point the colour names above at one theme. macOS keeps its own look, so it is always 'light' there."""
    global THEME
    THEME = name if name in THEMES and not IS_MAC else "light"
    globals().update(THEMES[THEME])
    return THEME


apply_theme("light")

THEME_PATH = os.path.join(LOCAL_DIR, "theme.txt")     # per computer, never in the (possibly shared) buttons file


def read_local_theme():
    try:
        with open(THEME_PATH, encoding="utf-8") as f:
            name = f.read().strip()
    except OSError:
        return "light"
    return name if name in THEMES else "light"


def write_local_theme(name):
    try:
        os.makedirs(LOCAL_DIR, exist_ok=True)
        with open(THEME_PATH, "w", encoding="utf-8") as f:
            f.write(name)
    except OSError:
        pass

PALETTE = ["#3b6fd4", "#2e9d6a", "#d08a1e", "#c2413b", "#8a4fc7", "#1f9bb0", "#5f6b7a", "#c4487f"]

KEY_PRESETS = [
    "Return", "Tab", "shift+Tab", "Escape", "BackSpace", "Delete",
    "ctrl+a", "ctrl+c", "ctrl+v", "ctrl+x", "ctrl+z", "ctrl+s", "ctrl+Return",
    "cmd+a", "cmd+c", "cmd+v", "cmd+s", "alt+Tab", "Up", "Down", "Left", "Right", "Home", "End",
    "Tab Tab Return",
]

# Handed to the speech model as context, so it expects these words. Tested on two synthetic voices (2026-09-27):
# a bare comma list fixed "palpation" but made the model start a note "Palpation, report, ..." when it heard
# "Patient reports" (a wrong but believable word: the worst kind of error in a clinical record). Leading with a real
# sentence that contains "The patient reports" stopped that; what is left are visible misspellings ("sacrileac").
DEFAULT_DICTATION_WORDS = ("Chiropractic clinical note. The patient reports pain. Terms: palpation, levator scapulae, "
                           "trapezius, sacroiliac, myofascial, lumbar, thoracic, cervical, facet irritation, "
                           "radiculopathy, straight leg raise, range of motion, adjustment, mobilisation.")

DEFAULT_CLAUDE_MODEL = "claude-opus-5"
CLAUDE_HOST = "api.anthropic.com"
DEFAULT_PASTE_PROGRAMS = "libreoffice|soffice"     # window classes Auto pastes into (a pattern; | separates names)

DEFAULT_CONFIG = {
    "settings": {
        "type_delay_ms": 8, "always_on_top": True, "geometry": "", "collapsed": [], "current_family": ALL_FAMILIES,
        "start_family": "",                       # "" = the one I used last, ALL_FAMILIES, or a family name
        "show_on_start": True,                    # False = start minimised
        "position_mode": "last", "fixed_geometry": "",   # "last" = where I left it; "fixed" = a saved spot
        "text_size": "normal",
        "idle_fade": True, "idle_seconds": 30, "idle_opacity": 50,
        "idle_style": "rollup",                   # when idle: "rollup" (slim bar), "shrink", or "fade" (opacity only)
        "global_hotkeys": True,                   # shortcut keys work in any program (Linux with X11)
        "backup_dir": "", "backup_schedule": "daily", "backup_on_save": True, "last_backup_folder": "",
        "password_hash": "", "password_salt": "", "lock_on_start": False, "lock_on_restore": False,
        "auto_update_check": True,
        "hover_preview": True,                    # a note showing what a button will type when you point at it
        "dictation_model": "",                    # "" = the model suggested for this computer
        "dictation_device": "",                   # "" = the computer's standard microphone
        "dictation_review": True,                 # True = show what it heard, to check/correct before typing
        "dictation_show_heard": True,             # when not checking first: show "Heard: …" + Fix a word afterwards
        "dictation_fixes": [],                    # custom vocabulary: [{"heard": "arm", "write": "leg"}, …]
        "typing_wpm": 40,                         # how fast this person types, for Settings > Time saved
        "clinic_days": 5, "weeks_per_year": 48,   # for the time-saved forecast
        "ai_model": DEFAULT_CLAUDE_MODEL,         # Settings > AI note
        "ai_layout": "soap",                      # the AI note's layout: "soap", "foaming" or "custom" (AI_LAYOUTS)
        "ai_instructions": "",                    # the "custom" layout's own instructions
        "dictation_max_seconds": 180,             # stop listening after this long, in case Stop is forgotten
        "dictation_words": DEFAULT_DICTATION_WORDS,
        # How a button's text goes into the other program: "type" (key by key), "paste" (through the clipboard and
        # Ctrl+V, which LibreOffice on some Linux Mint desktops needs), or "auto" (paste only into the programs below)
        "insert_method": "type",
        "paste_programs": DEFAULT_PASTE_PROGRAMS,
        "last_workflow": "",                      # id of the workflow started last, only to offer it first
    },
    "families": [
        {"name": "General", "colour": "#3b6fd4", "buttons": [
            {"label": "Email sign-off", "steps": [{"type": "text", "value": "Kind regards,{Enter}"}]},
            {"label": "Today's date", "steps": [{"type": "text", "value": "{Date dd/MM/yyyy}"}]},
        ]},
        {"name": "Examples", "colour": "#2e9d6a", "buttons": [
            {"label": "Address", "steps": [{"type": "text",
                                            "value": "123 Example St{Enter}Suburb SA 5000{Enter}Australia"}]},
            {"label": "Pick a greeting", "steps": [{"type": "text", "value": "{List Hi,Hello,Good morning}, "}]},
            {"label": "Fill two fields", "steps": [{"type": "text", "value": "First field{Tab}{Delay 150}Second field"}]},
        ]},
    ],
}

# name → (text inserted into the box, description). Shown in the "Insert command" menu.
COMMANDS = [
    ("New line (Enter)", "{Enter}", "Press Enter / move to a new line"),
    ("Tab", "{Tab}", "Press Tab (next field)"),
    ("Today's date", "{Date dd/MM/yyyy}", "Today's date. Add +1 / -1 for tomorrow / yesterday: {Date +1 dd/MM/yyyy}"),
    ("Current time", "{Time HH:mm}", "Current time. hh:mm tt gives 12-hour with AM/PM"),
    (None, None, None),
    ("Wait (milliseconds)", "{Delay 250}", "Wait 250 ms before continuing"),
    ("Pause (seconds)", "{Pause 5}", "Wait 5 seconds before continuing"),
    ("Choose from a list", "{List One,Two,Three}", "Ask which one to type when the button is pressed. A choice can "
     "press keys too: {List Neck{Enter},Back{Enter}}"),
    ("Choose (with | between)", "{Choose:One|Two|Three}", "Like a list, with | between the choices. Show one thing and "
     "type another with Label=>text: {Choose:Both sides=>bilateral|Left|Right}. A choice can open another list"),
    ("Tick several", "{MultiChoose:One|Two|Three}", "Tick any number; they are typed as “One, Two and Three”"),
    ("Choose from a saved list", "{List:Side}", "Pick from a list made in Edit buttons › Saved lists, so many "
     "buttons can share one list"),
    ("Tick several from a saved list", "{MultiList:Side}", "Tick any number from a saved list"),
    ("Ask me a question", "{Ask What should go here?}", "A box asks the question, then types your answer"),
    ("Pause so I can dictate", "{Wait Dictate now, then click Continue}",
     "Pauses the button with a Continue window. Dictate or type, click Continue, and it carries on"),
    ("Dictate (Quickpad listens)", "{Dictate Speak now, then click Stop}",
     "Quickpad listens through the microphone and types what you said, worked out on this computer. "
     "Set it up once in Settings > Dictation"),
    ("AI note from the clipboard", "{AINote}",
     "AI turns the Plaud summary or transcript on the clipboard into a note in your template, on this computer unless "
     "you chose your own AI provider (Settings > AI note). "
     "You check it before it goes in"),
    ("AI note from dictation", "{AINote dictate}",
     "Talk through the consult; AI writes it up in your template for you to check"),
    (None, None, None),
    ("Paste text", "{Paste Text to insert}", "Paste via the clipboard (fast for long text)"),
    ("Paste a text file", "{PasteFile /path/to/file.txt}", "Paste the contents of a text file"),
    ("Paste from clipboard", "{Clipboard}", "Types whatever is currently on the clipboard right now "
     "(for example a summary you just copied from Plaud or another program)"),
    ("Press any key combo", "{Key ctrl+s}", "Any key or combo, e.g. {Key shift+Return}"),
    (None, None, None),
    ("Switch family", "{Group Examples}", "Switch the panel to another family"),
    ("Workflow: next step", "{NextStep}", "In a workflow, go to the next step once this button has finished"),
    ("Workflow: back a step", "{PreviousStep}", "In a workflow, go back a step once this button has finished"),
    ("Workflow: stay on this step", "{Stay}", "In a workflow, stay on this step after this button"),
    ("Workflow: back to the first step", "{WorkflowStart}", "In a workflow, go back to its first step"),
    ("Start a workflow", "{Workflow Standard visit}", "Start the workflow with this name once this button has finished"),
    ("Open a website", "{Open www.example.com}", "Open a website in the browser"),
    ("Start a program", "{Run notepad.exe}", "Run a program or command"),
    ("Run in a terminal window", "{Terminal df -h /}", "Run a command in a terminal window that stays open so you can read the result"),
    ("Activate a window", "{Activate Untitled - Notepad}", "Switch to the window whose title contains this"),
    (None, None, None),
    ("Move the mouse", "{MouseMove 164,159}", "Move the pointer to screen position x,y"),
    ("Left-click", "{MouseLeft}", "Click the left mouse button"),
    ("Right-click", "{MouseRight}", "Click the right mouse button"),
    (None, None, None),
    ("Save a value", "{Var1=Hello}", "Remember a value for later in this session"),
    ("Type a saved value", "{Var1}", "Type a value saved earlier"),
    ("Type a {", "{LBrace}", "Types {  (a curly bracket on its own would start a command)"),
    ("Type a }", "{RBrace}", "Types }"),
    ("Type a |", "{Pipe}", "Types |  (inside {Choose…}, a plain | separates the choices)"),
    ("Type a comma", "{Comma}", "Types ,  (inside {List…}, a plain comma separates the choices)"),
]

# Commands shown in a submenu of Insert command rather than the menu itself, so it stays short enough for a laptop.
COMMAND_GROUPS = {
    **dict.fromkeys(("{Choose:One|Two|Three}", "{MultiChoose:One|Two|Three}", "{List:Side}", "{MultiList:Side}"),
                    "More ways to choose"),
    **dict.fromkeys(("{LBrace}", "{RBrace}", "{Pipe}", "{Comma}"), "Type a special character"),
    **dict.fromkeys(("{NextStep}", "{PreviousStep}", "{Stay}", "{WorkflowStart}", "{Workflow Standard visit}"),
                    "Workflows"),
}


def T(cmd):
    return [{"type": "text", "value": "{Terminal " + cmd + "}"}]


def R(cmd):
    return [{"type": "text", "value": "{Run " + cmd + "}"}]


# Plain-English computer-help buttons for a non-technical user. No curly braces inside a command: braces are
# Quickpad's own syntax. The Terminal ones open a window that stays open so the result can be read.
ACTIONS_FAMILY = {"name": "Computer help", "colour": "#5f6b7a", "buttons": [
    {"label": "Update this computer", "steps": T(
        'echo "Updating. It will ask for your password: type it and press Enter (nothing shows as you type)."; '
        'sudo apt update && sudo apt upgrade -y && echo && echo "All up to date."')},
    {"label": "How much space is left?", "steps": T(
        'echo "Free space on this computer (look at the Avail column):"; echo; df -h /')},
    {"label": "Is the internet working?", "steps": T(
        'if ping -c 4 google.com; then echo; echo "The internet is working."; '
        'else echo; echo "Cannot reach the internet. Check the Wi-Fi or the cable."; fi')},
    {"label": "Wi-Fi name and address", "steps": T(
        'echo "Wi-Fi network:"; nmcli -t -f active,ssid dev wifi | grep "^yes" | cut -d: -f2; echo; '
        'echo "This computer\'s address:"; ip -4 -br addr | grep -v "^lo"')},
    {"label": "Restart the Wi-Fi", "steps": T(
        'echo "Restarting the network..."; nmcli networking off; sleep 2; nmcli networking on; sleep 5; '
        'echo "Done. Give the Wi-Fi a few seconds to reconnect."')},
    {"label": "Fix stuck printing", "steps": T(
        'echo "Clearing stuck print jobs and restarting printing. It may ask for your password."; '
        'cancel -a; sudo systemctl restart cups; echo; echo "Printing restarted. Try printing again."')},
    {"label": "Force-close a frozen program (then click it)", "steps": R("xkill")},
    {"label": "What is slowing this computer down?", "steps": T(
        'echo "Memory:"; free -h; echo; echo "Programs using the most memory:"; '
        'ps aux --sort=-%mem | head -6 | cut -c1-120')},
    {"label": "Take a screenshot", "steps": R("gnome-screenshot -i")},
    {"label": "Open my Downloads folder", "steps": R("xdg-open ~/Downloads")},
]}


# Programs each Computer help button relies on; a button is only added if they're all installed.
ACTION_NEEDS = {
    "Update this computer": ["apt", "sudo"], "How much space is left?": ["df"], "Is the internet working?": ["ping"],
    "Wi-Fi name and address": ["nmcli", "ip"], "Restart the Wi-Fi": ["nmcli"],
    "Fix stuck printing": ["cancel", "systemctl", "sudo"], "Force-close a frozen program (then click it)": ["xkill"],
    "What is slowing this computer down?": ["free", "ps"], "Take a screenshot": ["gnome-screenshot"],
    "Open my Downloads folder": ["xdg-open"],
}
# Buttons that change the computer ask "Are you sure?" first.
ACTION_CONFIRM = {"Update this computer", "Restart the Wi-Fi", "Fix stuck printing"}


def seed_actions(cfg):
    """Add the Computer help family once, on Debian-based Linux. Deleting it later sticks: it isn't re-added.
    Returns True if the config changed."""
    s = cfg["settings"]
    if s.get("actions_seeded") or not (sys.platform.startswith("linux") and shutil.which("apt")):
        return False
    s["actions_seeded"] = True
    if all(f["name"] != ACTIONS_FAMILY["name"] for f in cfg["families"]):
        fam = copy.deepcopy(ACTIONS_FAMILY)
        fam["buttons"] = [b for b in fam["buttons"] if all(shutil.which(t) for t in ACTION_NEEDS.get(b["label"], []))]
        for b in fam["buttons"]:
            if b["label"] in ACTION_CONFIRM:
                b["confirm"] = True
        if fam["buttons"]:
            cfg["families"].append(fam)
    return True


KEY_ALIASES = {
    "enter": "Return", "return": "Return", "newline": "Return", "tab": "Tab", "esc": "Escape",
    "escape": "Escape", "backspace": "BackSpace", "bs": "BackSpace", "delete": "Delete", "del": "Delete",
    "insert": "Insert", "ins": "Insert", "up": "Up", "down": "Down", "left": "Left", "right": "Right",
    "home": "Home", "end": "End", "pgup": "Prior", "pageup": "Prior", "pgdn": "Next", "pagedown": "Next",
    # Tk reports these keys by their X names, lower-cased by us; X wants the exact capitalisation.
    "prior": "Prior", "next": "Next", "print": "Print", "menu": "Menu", "pause": "Pause",
    "scroll_lock": "Scroll_Lock", "num_lock": "Num_Lock", "caps_lock": "Caps_Lock",
    "space": "space", **{f"f{n}": f"F{n}" for n in range(1, 13)},
}


# ================================================================ helpers

def sh(args, timeout=5, stdin=None):
    try:
        r = subprocess.run([str(a) for a in args], capture_output=True, text=True, timeout=timeout, input=stdin)
        return r.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return ""


MODIFIERS = {
    "ctrl": "ctrl", "control": "ctrl", "shift": "shift",
    "alt": "alt", "option": "alt", "opt": "alt",
    "super": "super", "cmd": "super", "command": "super", "win": "super", "logo": "super", "meta": "super",
}


def parse_combo(combo):
    """'ctrl+shift+t' -> (['ctrl', 'shift'], 't'). Key names are normalised (enter -> Return)."""
    parts = [p for p in combo.split("+") if p]
    if not parts:
        return [], ""
    mods = [MODIFIERS[p.lower()] for p in parts[:-1] if p.lower() in MODIFIERS]
    key = parts[-1]
    return mods, KEY_ALIASES.get(key.lower(), key)


def cursor_buttons(mac=None):
    """The three cursor buttons at the top of the panel: up a line, down a line, and back to just after the last entry.
    They only move the cursor in the other program; nothing is typed. Quickpad can't see where the cursor is in
    another program, so "back to the last entry" is the end of the document, which is where the last entry is when
    notes are added from the top down. On a Mac, Home and End mean the top and bottom of the document, so the
    line start and document end are the Command-arrow keys there."""
    mac = IS_MAC if mac is None else mac
    line_start = "cmd+Left" if mac else "Home"
    doc_end = "cmd+Down" if mac else "ctrl+End"
    return [
        {"label": "Up a line", "mark": "↑", "cursor_nav": True, "steps": [{"type": "key", "value": f"Up {line_start}"}],
         "tip": "Moves the cursor to the start of the line above. Types nothing."},
        {"label": "Down a line", "mark": "↓", "cursor_nav": True,
         "steps": [{"type": "key", "value": f"Down {line_start}"}],
         "tip": "Moves the cursor to the start of the next line. Types nothing."},
        {"label": "Back to end", "mark": "", "cursor_nav": True, "steps": [{"type": "key", "value": doc_end}],
         "tip": "Jumps to the end of the document, just after your last entry. Types nothing."},
    ]


NET_TOKENS = re.compile(r"yyyy|yy|MMMM|MMM|MM|M|dddd|ddd|dd|d|HH|H|hh|h|mm|m|ss|s|tt|'[^']*'")


def net_format(fmt, dt):
    """Format a date with TypeItIn / .NET style patterns (dd/MM/yyyy, HH:mm, hh:mm tt)."""
    def sub(m):
        t = m.group(0)
        if t.startswith("'"):
            return t[1:-1]
        h12 = dt.hour % 12 or 12
        return {
            "yyyy": f"{dt.year:04d}", "yy": f"{dt.year % 100:02d}",
            "MMMM": dt.strftime("%B"), "MMM": dt.strftime("%b"), "MM": f"{dt.month:02d}", "M": str(dt.month),
            "dddd": dt.strftime("%A"), "ddd": dt.strftime("%a"), "dd": f"{dt.day:02d}", "d": str(dt.day),
            "HH": f"{dt.hour:02d}", "H": str(dt.hour), "hh": f"{h12:02d}", "h": str(h12),
            "mm": f"{dt.minute:02d}", "m": str(dt.minute), "ss": f"{dt.second:02d}", "s": str(dt.second),
            "tt": "AM" if dt.hour < 12 else "PM",
        }[t]
    return NET_TOKENS.sub(sub, fmt)


COMMAND_RE = re.compile(r"\{([^{}\n]+)\}")     # innermost {commands} only: for scanning, not for running
MAX_LIST_DEPTH = 8          # a chosen item can open another list, which can open another… up to this deep


# ---- the macro language (docs/SPEC-3.3.md §3). These five functions are exactly scripts/macro_reference.py, which
# tests/fixtures/macro-vectors.json comes from; the Android app follows the same file.
def tokenize(text):
    """Split text into ('text', str) and ('cmd', body) parts. Braces nest, so a command ends at its *matching* }
    and can hold other commands ({List a,{Enter}b}). An unmatched { or } is just text; so is {}. Unknown commands are
    typed as written later."""
    out, buf, i, n = [], [], 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "{":
            depth, j = 1, i + 1
            while j < n and depth:
                if text[j] == "{":
                    depth += 1
                elif text[j] == "}":
                    depth -= 1
                j += 1
            if depth == 0 and j - i > 2:
                if buf:
                    out.append(("text", "".join(buf)))
                    buf = []
                out.append(("cmd", text[i + 1:j - 1].lstrip()))   # trailing spaces matter inside list items
                i = j
                continue
        buf.append(ch)
        i += 1
    if buf:
        out.append(("text", "".join(buf)))
    return out


def split_top(s, sep):
    """Split on `sep` only outside braces, so a comma inside {…} stays part of its item."""
    parts, buf, depth = [], [], 0
    for ch in s:
        if ch == "{":
            depth += 1
        elif ch == "}" and depth:
            depth -= 1
        if ch == sep and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    parts.append("".join(buf))
    return parts


def macro_item(raw):
    """One choice: 'Label=>value' shows Label and runs value; otherwise both are the item. Spaces at the start are
    dropped but not at the end: "FU = " has to type its space."""
    raw = raw.lstrip()
    depth = 0
    for k, ch in enumerate(raw):
        if ch == "{":
            depth += 1
        elif ch == "}" and depth:
            depth -= 1
        elif depth == 0 and raw.startswith("=>", k):
            return {"label": raw[:k].strip(), "value": raw[k + 2:].lstrip()}
    return {"label": raw.strip(), "value": raw}


def parse_choice(body):
    """What kind of chooser a command is: {"kind": "inline", "multi", "title", "items"} for {List …}, {Choose…} and
    {MultiChoose…}; {"kind": "saved", "multi", "name"} for {List:Name} and {MultiList:Name}; None for anything else."""
    body = body.lstrip()
    name, _, rest = body.partition(" ")
    low = name.lower()
    if low.startswith("list:") or low.startswith("multilist:"):
        multi = low.startswith("multi")
        return {"kind": "saved", "multi": multi, "name": body.split(":", 1)[1].strip()}
    if low == "list" and rest.strip():
        items = split_top(rest, ",")
        title = ""
        if items and items[0].strip().lower().startswith("title:"):
            title = items.pop(0).strip()[6:].strip()
        # TypeItIn's Pos:Screen / Pos:Window / Pos:x|y place its list window; they aren't choices.
        items = [x for x in items if x.strip() and not x.strip().lower().startswith("pos:")]
        return {"kind": "inline", "multi": False, "title": title, "items": [macro_item(x) for x in items]}
    if low.startswith("choose") or low.startswith("multichoose"):
        multi = low.startswith("multi")
        head, colon, tail = body.partition(":")
        if not colon:
            return None
        keyword = "multichoose" if multi else "choose"
        prompt = head.strip()[len(keyword):].strip()
        if head.strip().lower() != keyword and not (prompt.startswith('"') and prompt.endswith('"') and len(prompt) >= 2):
            return None
        title = prompt[1:-1] if prompt else ""
        items = split_top(tail, "|")
        return {"kind": "inline", "multi": multi, "title": title, "items": [macro_item(x) for x in items if x.strip()]}
    return None


def join_multi(values):
    """Several ticked values with what goes between them: a / a and b / a, b and c."""
    if not values:
        return []
    if len(values) == 1:
        return values
    seps = [", "] * (len(values) - 2) + [" and "]
    out = []
    for v, s in zip(values, seps + [None]):
        out.append(v)
        if s:
            out.append(s)
    return out


def choice_display(value, limit=90):
    """A choice on one line for the chooser: ⏎ for {Enter}, ⇥ for {Tab}, cut short at about 90 characters."""
    s = value.replace("{Enter}", "⏎").replace("{enter}", "⏎").replace("{Tab}", "⇥").replace("{tab}", "⇥")
    s = " ".join(s.split())
    return s if len(s) <= limit else s[:limit - 1] + "…"


# {LBrace} etc. type the characters that are otherwise Quickpad's own syntax (or split list items).
ESCAPES = {"lbrace": "{", "rbrace": "}", "pipe": "|", "comma": ","}


def rgb(hexcol):
    h = hexcol.lstrip("#")
    try:
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return (59, 111, 212)


def _luminance(hexcol):
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(c) for c in rgb(hexcol))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(hexcol):
    """Black or white, whichever is easier to read on this colour (by the WCAG contrast ratio). The old brightness
    shortcut picked white on orange, green and teal, which is hard to read."""
    lum = _luminance(hexcol)
    return "#000000" if (lum + 0.05) / 0.05 >= 1.05 / (lum + 0.05) else "#ffffff"


def tint(hexcol, amount=0.78):
    r, g, b = (int(c + (255 - c) * amount) for c in rgb(hexcol))
    return f"#{r:02x}{g:02x}{b:02x}"


def shade(hexcol, amount=0.2):
    r, g, b = (int(c * (1 - amount)) for c in rgb(hexcol))
    return f"#{r:02x}{g:02x}{b:02x}"


def setup_style(root):
    """One consistent, flat look on every platform. Returns the background colour to use for plain tk widgets."""
    style = ttk.Style(root)
    if IS_MAC:
        return root.cget("bg")
    if "clam" in style.theme_names():
        style.theme_use("clam")
    root.configure(bg=APP_BG)
    style.configure(".", background=APP_BG, foreground=INK, fieldbackground=CARD, insertcolor=INK)
    style.configure("TButton", padding=(9, 6), background=CARD, foreground=INK, bordercolor=EDGE,
                    lightcolor=CARD, darkcolor=CARD, relief="solid", borderwidth=1)
    style.map("TButton", background=[("pressed", PRESS), ("active", HOVER)], foreground=[("disabled", MUTED)])
    style.configure("Big.TButton", padding=(10, 9), font=(tkfont.nametofont("TkDefaultFont").actual("family"), 11, "bold"))
    style.configure("Cursor.TButton", padding=(4, 5))      # the three cursor buttons under Edit buttons / Settings
    style.configure("TCombobox", padding=6, fieldbackground=CARD, foreground=INK, bordercolor=EDGE, arrowcolor=INK)
    style.map("TCombobox", fieldbackground=[("readonly", CARD)], foreground=[("readonly", INK)])
    style.configure("TEntry", fieldbackground=CARD, foreground=INK, bordercolor=EDGE)
    style.configure("TCheckbutton", background=APP_BG, foreground=INK)
    style.configure("TRadiobutton", background=APP_BG, foreground=INK)
    style.map("TCheckbutton", background=[("active", APP_BG)])
    style.map("TRadiobutton", background=[("active", APP_BG)])
    style.configure("TNotebook", background=APP_BG, bordercolor=EDGE)
    style.configure("TNotebook.Tab", background=CARD, foreground=INK, padding=(10, 5))
    style.map("TNotebook.Tab", background=[("selected", APP_BG)], foreground=[("selected", INK)])
    style.configure("TLabelframe", background=APP_BG, bordercolor=EDGE)
    style.configure("TLabelframe.Label", background=APP_BG, foreground=INK)
    # No rowheight was ever set here, so every Treeview (Editor's family/button tree, the Vocabulary corrections
    # list, the dictation model list) used the clam theme's default row height regardless of the actual font's
    # metrics on the machine it runs on — on a real Linux Mint laptop, real font rendering can need more
    # vertical room than the theme guessed, clipping the bottom of a row's text where Xvfb's default font never
    # showed the gap. Basing it on the font's own linespace, with a little padding, fixes that regardless of DPI
    # or font substitution, and covers bold rows (the family headers here use TkDefaultFont bold) too.
    row_h = tkfont.nametofont("TkDefaultFont").metrics("linespace") + 10
    style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=INK, rowheight=row_h)
    style.map("Treeview", background=[("selected", SOLID)], foreground=[("selected", SOLID_TEXT)])
    style.configure("Vertical.TScrollbar", arrowsize=18, background=SB, troughcolor=SB_TROUGH,
                    bordercolor=SB_EDGE, arrowcolor=INK)
    style.map("Vertical.TScrollbar", background=[("active", SB_ACTIVE)])
    style.configure("TSeparator", background=SB_EDGE)
    # Plain tk widgets (lists, text boxes, menus) follow the theme through the option database.
    for pat, val in (("*Listbox.background", CARD), ("*Listbox.foreground", INK), ("*Listbox.selectBackground", SOLID),
                     ("*Listbox.selectForeground", SOLID_TEXT), ("*Text.background", CARD), ("*Text.foreground", INK),
                     ("*Text.insertBackground", INK), ("*Entry.background", CARD), ("*Entry.foreground", INK),
                     ("*Entry.insertBackground", INK), ("*Spinbox.background", CARD), ("*Spinbox.foreground", INK),
                     ("*TCombobox*Listbox.background", CARD), ("*TCombobox*Listbox.foreground", INK)):
        root.option_add(pat, val, 60)
    return APP_BG


# ---- what a button will type, in plain words (hover preview) and safe display text

_NON_BMP = re.compile("[\U00010000-\U0010ffff️‍]")


def tk_safe(text):
    """Tk 8.6.12 (Linux Mint 21) can crash the whole program drawing colour emoji, so anything shown on screen has
    them swapped for a plain '?'. What gets typed is untouched."""
    return _NON_BMP.sub("?", str(text))


# Plain symbols (none of them are colour emoji) that can go in front of a button's name.
ICONS = ["●", "■", "▲", "◆", "★", "✚", "✓", "✗", "➜", "♪", "⌂", "☰", "⚑", "❖"]


def button_caption(b):
    icon = b.get("icon", "")
    return tk_safe((icon + "  " if icon in ICONS else "") + b.get("label", ""))


def format_datetime(kind, arg, now=None):
    """{Date …} / {Time …}: an optional +N / -N day offset, then a format (see net_format)."""
    fmt, now = arg, now or datetime.datetime.now()
    m = re.match(r"([+-]\d+)\s*(.*)", fmt)
    if m:
        now += datetime.timedelta(days=int(m.group(1)))
        fmt = m.group(2)
    return net_format(fmt or ("dd/MM/yyyy" if kind == "date" else "HH:mm"), now)


def _preview_choice(choice):
    """‹pick: a / b› for a chooser in the hover preview. Items that open more lists show as the label only."""
    if choice["kind"] == "saved":
        return f"‹{'tick from' if choice['multi'] else 'pick from'}: {choice['name']}›"
    labels = [choice_display(it["label"] or it["value"], 40) for it in choice["items"]]
    return f"‹{'tick' if choice['multi'] else 'pick'}: " + " / ".join(labels) + "›"


def _preview_command(body):
    choice = parse_choice(body)
    body = body.strip()
    name, _, arg = body.partition(" ")
    low, arg = name.lower(), arg.strip()
    if choice:
        return _preview_choice(choice)
    if low in ESCAPES and not arg:
        return ESCAPES[low]
    if re.fullmatch(r"(var\w*)\s*=\s*\?(.*)", body, re.I | re.S):
        return ""
    if re.fullmatch(r"(var\w*)\s+list\s+(.*)|(var\w*)\s*[+-]\s*\d+", body, re.I | re.S):
        return ""
    if re.fullmatch(r"(var\w*)\s*=\s*(.*)", body, re.I | re.S):
        return ""
    if low == "shift" and arg and arg.lower() not in KEY_ALIASES:
        return arg.upper()
    if low in ("enter", "return"):
        return "\n" * (int(arg) if arg.isdigit() else 1)
    if low == "tab":
        return "⇥"
    if low in ("date", "time"):
        try:
            return format_datetime(low, arg)
        except Exception:  # noqa: BLE001
            return "‹" + low + "›"
    if low == "ask":
        return "‹you type: " + (arg or "an answer") + "›"
    if low == "wait":
        return "‹pause while you type or dictate›"
    if low == "dictate":
        return "‹what you say›"
    if low == "paste":
        return arg
    if low == "clipboard":
        return "‹whatever is on the clipboard›"
    if low in ("delay", "pause") or (low in WORKFLOW_COMMANDS and not arg) or (low == "workflow" and arg):
        return ""
    return "‹" + low + "›"


def preview_text(steps, limit=420):
    """A short plain-text picture of what a button will type, for the hover tip."""
    out = []
    for st in steps or []:
        kind, val = st.get("type"), st.get("value", "")
        if kind == "text":
            for k, part in tokenize(str(val)):
                out.append(part if k == "text" else _preview_command(part))
        elif kind == "key":
            out.append(f"‹keys: {val}›")
    text = tk_safe("".join(out)).strip("\n")
    lines = text.split("\n")
    if len(lines) > 9:
        text = "\n".join(lines[:9]) + "\n…"
    return text[:limit] + ("…" if len(text) > limit else "") if text else "(nothing to type yet)"


# ---- "What's new" after an update. Newest first. Written for the clinic: plain words, no jargon.
WHATS_NEW = [
    ("3.4.1", [
        "Kubuntu and other KDE Plasma desktops: buttons now type into LibreOffice and other programs on KDE's "
        "default (Wayland) login. The first time a button types, KDE asks whether Quickpad may type for you: choose "
        "Allow, and tick the box to remember it if there is one. If it can't type, Quickpad now says why and what to "
        "do, instead of doing nothing.",
        "Settings › Help › Check my setup now shows your desktop (for example “KDE Plasma (Wayland session)”) and "
        "whether KDE has allowed Quickpad to type.",
        "To keep Quickpad's icon on KDE's taskbar, right-click it and choose Pin to Task Manager.",
        "New buttons under Back up… and Restore…: Up a line, Down a line and Back to end. They move the cursor "
        "in the other program without typing anything.",
    ]),
    ("3.4.0", [
        "The AI note can now be written on this computer, so the consult text never leaves it. To set it up, go to "
        "Settings > AI note and click Set up. It downloads once (about 6 GB, or 2.5 GB for the smaller model on "
        "computers with 8 GB of memory). After that, a note takes about a minute.",
        "If this computer already uses a Claude key, nothing changes: it keeps using Claude until you choose "
        "otherwise in Settings > AI note. You can also use another AI service of your own (anything that works like "
        "OpenAI's). Quickpad asks before it first sends a note anywhere new.",
    ]),
    ("3.3.2", [
        "The panel is a little wider, so the Settings button at the top is no longer cut off on Windows. If yours "
        "was very narrow, it opens wide enough now.",
    ]),
    ("3.3.1", [
        "Quickpad's icon now stays in Mint's panel (and GNOME's or KDE's) when you pin it there, and a click on it "
        "brings the panel to the front even from another workspace or from behind your mail program.",
        "After Quickpad has rolled up into a thin bar, the bar now says “click to open”, and a right-click on it "
        "gives you Settings and Edit buttons straight away.",
    ]),
    ("3.3.0", [
        "Lists can do more, like TypeItIn. A choice in a list can press keys as well as type: picking an item "
        "such as RF = {Enter}W = {Enter}FU =  types each line and presses Enter between them. Your TypeItIn "
        "buttons that do this now work.",
        "A choice can open another list, so one pick can lead to the next (pick the area, then the side). "
        "{Choose:Left|Right|Both sides} works like {List} with | between the choices, and Both sides=>bilateral "
        "shows “Both sides” in the list but types “bilateral”.",
        "Tick several: {MultiChoose:pain|stiffness|weakness} lets you tick any number, typed as “pain, stiffness "
        "and weakness”.",
        "Saved lists: Edit buttons has a new Saved lists tab. Make a list once (Side, Body region…) and use it in "
        "any button with {List:Side}, or {MultiList:Side} to tick several. Change the list and every button using "
        "it changes too; rename it and the buttons are updated for you.",
        "The list window is quicker: press 1–9 to pick, or start typing to narrow the list down, then Enter. "
        "Long choices show on one line. Cancelling stops the whole button, so nothing half-typed goes in.",
        "LibreOffice: if nothing appears when a button types into Writer, go to Settings › Buttons › How text goes "
        "into other programs and choose “Paste it in only for these programs” (LibreOffice is already listed). "
        "Quickpad then pastes the text in and puts your clipboard back afterwards. Quickpad also now checks that "
        "the other window really has the keyboard before typing, and tries a second way if it doesn't.",
        "Settings › Help › Check my setup has a Typing test: click into any window and Quickpad types a test line "
        "there, then says how it went.",
        "Behind the scenes, every button, group and list now has its own permanent label inside the buttons file, "
        "ready for keeping two computers (and later a phone) in step. Nothing changes in how you use it.",
        "Workflows: go through a consult one group at a time. In Edit buttons › Workflows, set out the steps, for "
        "example Symptoms, Objective, Adjustments, Adjustments, Treatment, Plan (a group can come up more than once). "
        "Start it from the bottom of the family list on the panel (Workflows ▸). The panel then shows only that "
        "step's group, with Back, Next, Start and End, and moves on to the next group after each button. Untick Auto "
        "on the bar to move on yourself with Next (or Alt+Right; Alt+Left goes back).",
        "Each button can say what a workflow does after it: Edit buttons › After this button (stay on this step, go "
        "to the next, go back, or go to the first step). Inside a button's text, {NextStep}, {PreviousStep}, "
        "{Stay}, {WorkflowStart} and {Workflow Standard visit} do the same.",
        "Back up… now saves your whole setup (buttons, saved lists, workflows and settings) as one .quickpad file. "
        "Restore… reads it, or an older backup, and asks: Replace everything, or Merge (keep what's here and add "
        "what's in the file; where a button was changed in both, the newer change wins). In Settings › Backup & "
        "data these are Export setup… and Import setup….",
        "Settings › AI note has a Layout choice: Generic SOAP, FOAMING SOAP, or your own instructions. If you "
        "already use the AI note, it stays exactly as it was.",
        "Sync between computers: Settings › Sync. Switch on “Let phones and other computers sync with this "
        "computer” on the front-desk PC, then on another computer choose Sync this computer with another Quickpad "
        "and type the address and pairing code it shows. Buttons added or changed on either one appear on the other "
        "within a few seconds. It all stays on the clinic's own network, never the internet.",
        "If another computer can't connect, the firewall may be blocking it: Settings › Sync says which port to "
        "allow, and Check my setup now has a Sync line.",
    ]),
    ("3.2.0", [
        "Bring your TypeItIn buttons across: Settings > Buttons > Import from TypeItIn. Choose TypeItIn's data "
        "file (datafile.enc, or a backup of it like datafile.enc.250401), tick the groups you want, and they "
        "appear as families. Your current buttons are kept, and a backup is made first.",
        "TypeItIn-style buttons now work as they did there: lists with a title ({List Title: Side,Left,Right}), "
        "questions that remember the answer ({Var1 =?Review in how many weeks?} then {Var1}), and {Shift :} "
        "or {Ctrl c}.",
    ]),
    ("3.1.6", [
        "Edit buttons now has clear Move and Copy buttons under Family: pick the other family, then click Move "
        "(the button leaves this family and goes there) or Copy (it stays here and an exact copy goes there, "
        "without its shortcut key, since two buttons can't share one).",
        "The old way of moving (changing the Family dropdown) is gone, because it wasn't obvious it moved anything. "
        "Right-click a button on the panel still has Move to another family and Copy to another family too.",
    ]),
    ("3.1.5", [
        "Fixed a rare dictation bug: if a custom vocabulary word was set up to remove a word entirely rather "
        "than replace it, and that was the only word in what you said, Quickpad discarded the whole dictation "
        "instead of recognising there just wasn't anything left to type.",
        "Fixed Settings > Vocabulary: editing a correction so its \"heard\" word matched one already in the "
        "list could silently lose one of the two instead of replacing it.",
    ]),
    ("3.1.4", [
        "Fixed the new Copy to another family control in Edit buttons: on smaller screens it was sitting off "
        "the edge of the window where it couldn't be seen at all. It now sits on its own line under Family.",
        "Longer button names in the Edit buttons list are less likely to get cut off, and a row's text should no "
        "longer be clipped at the bottom on any screen.",
    ]),
    ("3.1.3", [
        "The Edit buttons dialog now has its own Copy to another family control, next to the Family dropdown "
        "— no need to find the right-click menu on the panel to copy a button across.",
        "Control-click a button on the panel now opens the same menu as right-click, everywhere. Some touchpads' "
        "two-finger-tap for right-click can misfire and press the button instead of opening the menu; Control-click "
        "always works.",
        "Settings › Vocabulary: the words-it-should-expect box got a scroll bar and a little more room, so a "
        "longer list no longer gets its last line cut off.",
    ]),
    ("3.1.2", [
        "Updates are now checked to make sure they really came from Nick before installing, not just that they "
        "look like a Quickpad file.",
        "If dictation has a problem it can't recover from, there's now a Copy report for Nick button, the same "
        "one-click way Check my setup already works.",
        "The AI note now says it's sending your text to Claude every time, not just the first time.",
    ]),
    ("3.1.1", [
        "Settings > Vocabulary: the whole list of words it should expect is now shown, and there's an Add words box: "
        "type new words separated by commas (like arthrostim, vibrostim) and click Add. They go on the end; nothing "
        "is removed. Put back the standard list now asks first, because it replaces the whole list.",
        "Right-click a button > Copy to another family puts an exact copy of it (everything it types and does) at "
        "the end of the family you pick. The copy has no shortcut key, since two buttons can't share one.",
        "Settings fits smaller laptop screens: the tab names aren't cut off, and a page that doesn't fit gets a "
        "scroll bar instead of hiding its bottom part.",
    ]),
    ("3.1", [
        "New: AI notes. Copy a Plaud summary or transcript, click Clinical notes > FOAMING SOAP note from Plaud (AI), "
        "and Claude writes it up in your FOAMING SOAP layout. Or use FOAMING SOAP note from dictation (AI) and just "
        "talk through the consult. You always see the note to check and change before it goes in. Red flags are "
        "marked FLAG: and anything unclear CHECK:. Set it up once in Settings > AI note (it needs a Claude key).",
        "New: after dictating, Quickpad shows what it heard next to what it will type, so you can check it first. "
        "If it keeps getting a word wrong, click Fix a word: for example, when it hears “arm”, type “leg”. It "
        "remembers from then on. All your corrections are in Settings > Vocabulary.",
        "New: Settings > Time saved shows how much typing Quickpad has saved you today, this week and so far, and "
        "what that adds up to over a month and a year. Tell it how fast you type, or click Measure my typing.",
        "Updates now work on Macs that use Python from python.org without its certificates installed.",
    ]),
    ("3.0", [
        "New: Quickpad can listen and type what you say. The S:, O:, A: and P: dictate buttons in Clinical notes "
        "now use it: click one, speak, click Stop, and the words are typed into the note. It is all worked out on "
        "this computer; recordings are never sent anywhere or kept.",
        "Set it up once in Settings > Dictation (one click; it takes a few minutes and needs the internet). That "
        "page also shows which speech model suits this computer, lets you try the microphone, and has a list of "
        "clinical words it should expect, which you can add to.",
        "Until dictation is set up on a computer, those buttons pause like before, so you can use your usual "
        "dictation and click Continue.",
        "Fixed: after a button was used with its shortcut key (like Ctrl+Alt+1), Ctrl or Alt could stay held down, so "
        "Ctrl+A and Backspace did odd things until you tapped Ctrl. Buttons now wait for you to let go of the "
        "shortcut, and always let go of Ctrl, Shift and Alt when they finish, even if something goes wrong.",
    ]),
    ("2.9", [
        "Fixed: Settings > Buttons > Typing speed (and any other setting) could look like it had no way to "
        "save, and reverted after closing Settings — the Save and Cancel buttons were being pushed off the "
        "bottom of the window. They now always show.",
    ]),
    ("2.8", [
        "New: Insert command > Paste from clipboard, or just type {Clipboard}, types whatever is currently on "
        "the clipboard. Clinical notes > New note + Plaud summary uses it to drop today's header in and paste "
        "a Plaud summary straight into the note.",
        "Clinical notes starter group: the help text now says to edit the wording for each patient before saving.",
    ]),
    ("2.7", [
        "Ask box: a button can now stop and ask you a question, then type your answer. In the editor use "
        "Insert command > Ask me a question.",
        "Pause for dictation: {Wait} pauses the button so you can dictate or type, then click Continue "
        "and it carries on.",
        "Point at a button and wait a moment: a small note shows what it will type.",
        "Find box at the top: type a few letters and only the matching buttons show. Press Enter to use the first one.",
        "Right-click a button to edit it, copy it, or move it.",
        "After a button types, the bottom of the panel says Typed, with an Undo button for a few seconds.",
        "Settings > Buttons > Add starter clinical notes puts in a ready-made set of note buttons to change as you like.",
        "Look: Settings > Window has Dark and High contrast, and each button can have a small symbol in the editor.",
        "Settings > Backup: one click to send backups to a Google Drive, Dropbox or OneDrive folder if this "
        "computer has one.",
    ]),
    ("2.6", [
        "Quickpad now remembers exactly where you left it (it used to creep down a little each time).",
        "Only one copy can run at a time. Starting it again brings the open one to the front.",
        "If an update ever fails to start, the previous version is put back automatically.",
        "Settings > Help > Check my setup shows what is working on one screen.",
    ]),
    ("2.5", [
        "Shortcut keys now work in any program on Linux, not just when Quickpad is in front. Use Ctrl or Alt with "
        "a key (for example Ctrl+Alt+1) or an F key.",
        "The Add keys step checks what you typed, and has a Record a key button so you can just press the key.",
        "The editor window fits on the screen and the step buttons are no longer cut off.",
        "Quickpad rolls up to a slim bar when you are not using it, like TypeItIn.",
    ]),
]


def version_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4])


def notes_since(seen, current=None):
    """The what's-new entries newer than `seen` up to the running version, newest first."""
    current = current or VERSION
    lo, hi = version_tuple(seen), version_tuple(current)
    if not lo or not hi:
        return []
    return [(v, items) for v, items in WHATS_NEW if lo < version_tuple(v) <= hi]


SEEN_PATH = os.path.join(LOCAL_DIR, "seen-version.txt")


def read_seen_version():
    try:
        with open(SEEN_PATH, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def write_seen_version(v=None):
    try:
        os.makedirs(LOCAL_DIR, exist_ok=True)
        with open(SEEN_PATH, "w", encoding="utf-8") as f:
            f.write(v or VERSION)
    except OSError:
        pass


# ---- starter clinical notes. Generic on purpose: this is a clinical record-keeping issue, not an advertising
# one — a note has to describe what actually happened with that patient, so the wording is edited per patient.
STARTER_NOTES_HELP = (
    "The starter notes are a ready-made group (date, side and area lists, SOAP headings, dictation buttons "
    "for S, O, A and P, and a button that drops in a Plaud summary from the clipboard). Customise the wording in Edit "
    "buttons to suit. Edit for each patient before saving — a clinical record has to describe what actually "
    "happened with that patient, not leftover template wording."
)
# v3.1: Claude writes the note in the layout chosen in Settings › AI note. Added to an existing Clinical notes group
# once, by upgrade_to_31(); if they are deleted they stay deleted.
AI_STARTER_BUTTONS = [
    {"label": "AI note from Plaud", "icon": "★", "steps": [{"type": "text", "value":
        "{Date dd/MM/yyyy}{Enter}{AINote}"}]},
    {"label": "AI note from dictation", "icon": "★", "steps": [{"type": "text", "value":
        "{Date dd/MM/yyyy}{Enter}{AINote dictate Talk through the consult, then click Stop}"}]},
]
STARTER_NOTES_FAMILY = {"name": "Clinical notes", "colour": "#1f9bb0", "columns": 1, "size": "", "buttons": [
    {"label": "New note (date, side, area)", "icon": "✚", "steps": [{"type": "text", "value":
        "{Date dd/MM/yyyy}  {List Left,Right,Both sides,Central} {List Neck,Upper back,Lower back,Shoulder,Elbow,"
        "Wrist / hand,Hip,Knee,Ankle / foot,Head / jaw}{Enter}"}]},
    *[copy.deepcopy(b) for b in AI_STARTER_BUTTONS],
    {"label": "New note + Plaud summary", "icon": "➜", "steps": [{"type": "text", "value":
        "{Date dd/MM/yyyy}  {List Left,Right,Both sides,Central} {List Neck,Upper back,Lower back,Shoulder,Elbow,"
        "Wrist / hand,Hip,Knee,Ankle / foot,Head / jaw}{Enter}{Enter}{Clipboard}"}]},
    {"label": "SOAP skeleton", "icon": "☰", "steps": [{"type": "text", "value":
        "S: {Enter}O: {Enter}A: {Enter}P: "}]},
    {"label": "S: dictate", "icon": "♪", "steps": [{"type": "text", "value":
        "S: {Dictate Say what the patient reports, then click Stop}{Enter}"}]},
    {"label": "O: dictate", "icon": "♪", "steps": [{"type": "text", "value":
        "O: {Dictate Say the examination findings, then click Stop}{Enter}"}]},
    {"label": "A: dictate", "icon": "♪", "steps": [{"type": "text", "value":
        "A: {Dictate Say your assessment, then click Stop}{Enter}"}]},
    {"label": "P: dictate", "icon": "♪", "steps": [{"type": "text", "value":
        "P: {Dictate Say the plan, then click Stop}{Enter}"}]},
    {"label": "Side (left / right / both)", "steps": [{"type": "text", "value": "{List Left,Right,Both sides}"}]},
    {"label": "Area", "steps": [{"type": "text", "value":
        "{List Cervical,Thoracic,Lumbar,Sacroiliac,Shoulder,Elbow,Wrist / hand,Hip,Knee,Ankle / foot}"}]},
    {"label": "Pain score", "steps": [{"type": "text", "value": "{List 0,1,2,3,4,5,6,7,8,9,10}/10"}]},
    {"label": "Treatment given today", "steps": [{"type": "text", "value":
        "{Date dd/MM/yyyy}: {Ask What treatment was given?}{Enter}"}]},
    {"label": "Advice / exercises discussed", "steps": [{"type": "text", "value":
        "Advice and exercises discussed: {Ask What was discussed?}{Enter}"}]},
    {"label": "Review", "steps": [{"type": "text", "value":
        "Review in {List 2 days,1 week,2 weeks,4 weeks,as needed}.{Enter}"}]},
]}


# v2.7–2.9 starter dictate buttons, exactly as they were added. Only buttons still carrying this exact text are moved
# over to {Dictate}: anything that has been reworded is left alone.
OLD_STARTER_DICTATE = {
    "S: {Wait Dictate what the patient reports, then click Continue}{Enter}":
        "S: {Dictate Say what the patient reports, then click Stop}{Enter}",
    "O: {Wait Dictate the examination findings, then click Continue}{Enter}":
        "O: {Dictate Say the examination findings, then click Stop}{Enter}",
    "A: {Wait Dictate your assessment, then click Continue}{Enter}":
        "A: {Dictate Say your assessment, then click Stop}{Enter}",
    "P: {Wait Dictate the plan, then click Continue}{Enter}":
        "P: {Dictate Say the plan, then click Stop}{Enter}",
}


def upgrade_starter_dictate(cfg):
    """Move untouched starter dictate buttons from {Wait} to {Dictate}. Safe everywhere: {Dictate} falls back to the
    old pause-and-Continue behaviour on a computer where dictation isn't set up. Returns True if anything changed."""
    changed = False
    for fam in cfg["families"]:
        for b in fam.get("buttons", []):
            for step in b.get("steps", []):
                new = OLD_STARTER_DICTATE.get(step.get("value")) if step.get("type") == "text" else None
                if new:
                    step["value"] = new
                    changed = True
    return changed


def upgrade_to_31(raw):
    """One-time changes for a buttons file from before 3.1 (it has no custom vocabulary list yet): check the words
    before typing becomes the default, and the two AI note buttons join an existing Clinical notes group.
    Works on the raw file, before defaults are filled in. Returns True if anything changed."""
    s = raw.get("settings") if isinstance(raw, dict) else None
    if not isinstance(s, dict) or "dictation_fixes" in s:
        return False
    s["dictation_review"] = True
    s["dictation_fixes"] = []
    for fam in raw.get("families", []):
        if fam.get("name") == STARTER_NOTES_FAMILY["name"] and isinstance(fam.get("buttons"), list):
            if not any("{AINote" in str(st.get("value", "")) for b in fam["buttons"] for st in b.get("steps", [])):
                fam["buttons"][1:1] = copy.deepcopy(AI_STARTER_BUTTONS)
    return True


def add_starter_notes(cfg):
    """Adds the starter family unless one with that name is there already. Returns True if it was added."""
    if any(f.get("name") == STARTER_NOTES_FAMILY["name"] for f in cfg["families"]):
        return False
    cfg["families"].append(copy.deepcopy(STARTER_NOTES_FAMILY))
    return True


# ---- importing buttons from a spreadsheet / text file (name, text[, family])
def import_csv_buttons(path):
    """Read a CSV or tab-separated file into families [{name, buttons}]. Columns: button name, text to type, and
    optionally the family. A header row is skipped. Raises ValueError with a readable reason."""
    import csv
    try:
        with open(path, encoding="utf-8-sig", newline="") as f:
            sample = f.read(4096)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
            except csv.Error:
                dialect = csv.excel
            rows = [r for r in csv.reader(f, dialect) if any(c.strip() for c in r)]
    except (OSError, UnicodeDecodeError) as e:
        raise ValueError(str(e))
    if rows and rows[0] and rows[0][0].strip().lower() in ("name", "label", "button", "button name", "title"):
        rows = rows[1:]
    fams, order = {}, []
    for r in rows:
        if len(r) < 2 or not r[0].strip():
            continue
        fam = (r[2].strip() if len(r) > 2 and r[2].strip() else "Imported")
        if fam not in fams:
            fams[fam] = []
            order.append(fam)
        text = r[1].replace("\\n", "\n")
        fams[fam].append({"label": r[0].strip(), "steps": [{"type": "text", "value": text}]})
    if not order:
        raise ValueError("no rows with a name and some text were found")
    return [{"name": n, "colour": PALETTE[i % len(PALETTE)], "buttons": fams[n]} for i, n in enumerate(order)]


# ---- importing TypeItIn's own data file (datafile.enc / datafile.txt)
# TypeItIn (Wavget, Windows) keeps every group and button in one line-based file. With "Encrypted" on (its default)
# each text line is AES-128-CBC, PKCS#7-padded and written in Base64 with TypeItIn's own alphabet. The key and IV are
# the fixed strings "TypeItIn" and "Init Vector", XOR-folded into 16 bytes (worked out from TypeItIn 4.x). Layout:
#   "TypeItIn DataFile"
#   per group:  name, button count, four settings, a blank line
#   per button: "text colour,button colour" (Delphi TColor), name, tooltip, text to type
# After the groups come TypeItIn's short-phrase list and per-group flags, which Quickpad doesn't use.
TII_HEADER = "TypeItIn DataFile"
TII_ALPHABET = "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
# Commands TypeItIn has that Quickpad doesn't run; buttons using them still import, and the summary names them.
TII_UNSUPPORTED = ("dialog", "winwait", "filelist", "sub", "undo", "altnum", "run", "typeitin-run", "gosub", "if",
                   "goto", "label")


def _aes_tables():
    sbox = [0] * 256
    p = q = 1
    while True:                       # the AES S-box, built from the GF(2^8) inverse
        p = p ^ ((p << 1) & 0xff) ^ (0x1b if p & 0x80 else 0)
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q &= 0xff
        if q & 0x80:
            q ^= 0x09
        x = q ^ ((q << 1 | q >> 7) & 0xff) ^ ((q << 2 | q >> 6) & 0xff) ^ ((q << 3 | q >> 5) & 0xff) ^ ((q << 4 | q >> 4) & 0xff)
        sbox[p] = x ^ 0x63
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


_AES_SBOX, _AES_INV = _aes_tables()


def _xt(a):
    return ((a << 1) ^ 0x1b) & 0xff if a & 0x80 else a << 1


def _gmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a, b = _xt(a), b >> 1
    return r


def _aes128_round_keys(key):
    w = [list(key[i:i + 4]) for i in range(0, 16, 4)]
    rcon = 1
    for i in range(4, 44):
        t = list(w[i - 1])
        if i % 4 == 0:
            t = [_AES_SBOX[b] for b in t[1:] + t[:1]]
            t[0] ^= rcon
            rcon = _xt(rcon)
        w.append([a ^ b for a, b in zip(w[i - 4], t)])
    return [sum(w[r * 4:r * 4 + 4], []) for r in range(11)]


def _aes128_decrypt_block(rk, block):
    s = [a ^ b for a, b in zip(block, rk[10])]
    for r in range(9, -1, -1):
        s = [s[((i // 4 - i % 4) % 4) * 4 + i % 4] for i in range(16)]   # inverse ShiftRows
        s = [_AES_INV[b] for b in s]
        s = [a ^ b for a, b in zip(s, rk[r])]
        if r:
            n = []
            for c in range(4):
                a = s[c * 4:c * 4 + 4]
                n += [_gmul(a[0], 14) ^ _gmul(a[1], 11) ^ _gmul(a[2], 13) ^ _gmul(a[3], 9),
                      _gmul(a[0], 9) ^ _gmul(a[1], 14) ^ _gmul(a[2], 11) ^ _gmul(a[3], 13),
                      _gmul(a[0], 13) ^ _gmul(a[1], 9) ^ _gmul(a[2], 14) ^ _gmul(a[3], 11),
                      _gmul(a[0], 11) ^ _gmul(a[1], 13) ^ _gmul(a[2], 9) ^ _gmul(a[3], 14)]
            s = n
    return bytes(s)


def _tii_fold(text):
    out = bytearray(16)
    for i, c in enumerate(text.encode("latin-1")):
        out[i % 16] ^= c
    return bytes(out)


_TII_KEYS = _aes128_round_keys(_tii_fold("TypeItIn"))
_TII_IV = _tii_fold("Init Vector")


def tii_decrypt(line):
    """One encrypted TypeItIn line to text, or None if it isn't one."""
    line = line.strip().rstrip("=")
    if not line or any(c not in TII_ALPHABET for c in line):
        return None
    v = bits = 0
    data = bytearray()
    for ch in line:
        v = (v << 6 | TII_ALPHABET.index(ch)) & 0xffffff
        bits += 6
        if bits >= 8:
            bits -= 8
            data.append(v >> bits & 0xff)
    if not data or len(data) % 16:
        return None
    out, prev = bytearray(), _TII_IV
    for i in range(0, len(data), 16):
        block = bytes(data[i:i + 16])
        out += bytes(a ^ b for a, b in zip(_aes128_decrypt_block(_TII_KEYS, block), prev))
        prev = block
    pad = out[-1]
    if not 1 <= pad <= 16 or out[-pad:] != bytes([pad]) * pad:
        return None
    raw = bytes(out[:-pad])
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")


def _tii_colour(tcolor, fallback):
    """A Delphi TColor (0x00BBGGRR, or negative for a Windows system colour) as #rrggbb."""
    try:
        v = int(tcolor)
    except ValueError:
        return fallback
    if v < 0 or v > 0xffffff or v in (0xffffff, 0):
        return fallback
    return f"#{v & 0xff:02x}{v >> 8 & 0xff:02x}{v >> 16 & 0xff:02x}"


def typeitin_only(text):
    """The TypeItIn-only command names (lower case) used in a button's text."""
    words = {re.split(r"[\s=,]", c.strip(), maxsplit=1)[0].lower() for c in COMMAND_RE.findall(text)}
    return {"{" + w.replace("typeitin-run", "run") + "}" for w in words & set(TII_UNSUPPORTED)}


def choose_groups(root, fams):
    """Tick-box list of the groups found in a TypeItIn file. Returns the chosen indexes, or None if cancelled."""
    win = tk.Toplevel(root)
    win.title(f"{APP} — Import from TypeItIn")
    win.configure(bg=APP_BG)
    win.transient(root)
    result = {"v": None}
    ttk.Label(win, text="Tick the groups to bring into Quickpad:", padding=(12, 10, 12, 4),
              font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
    outer = ttk.Frame(win, padding=(12, 0))
    outer.pack(fill="both", expand=True)
    canvas = tk.Canvas(outer, highlightthickness=0, height=min(28 * len(fams), 380), width=440, bg=APP_BG)
    sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    inner = ttk.Frame(canvas)
    inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="nw")
    canvas.configure(yscrollcommand=sb.set)
    canvas.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")
    ticks = []
    for i, f in enumerate(fams):
        v = tk.BooleanVar(value=True)
        ticks.append(v)
        n = len(f["buttons"])
        ttk.Checkbutton(inner, text=tk_safe(f"{f['name']}  ({n} button{'s' if n != 1 else ''})"),
                        variable=v).grid(row=i, column=0, sticky="w", pady=2)
    bar = ttk.Frame(win, padding=12)
    bar.pack(fill="x")

    def set_all(on):
        for v in ticks:
            v.set(on)

    def ok():
        result["v"] = [i for i, v in enumerate(ticks) if v.get()]
        win.destroy()
    ttk.Button(bar, text="Add these groups", command=ok).pack(side="right")
    ttk.Button(bar, text="Cancel", command=win.destroy).pack(side="right", padx=6)
    ttk.Button(bar, text="Tick all", command=lambda: set_all(True)).pack(side="left")
    ttk.Button(bar, text="Untick all", command=lambda: set_all(False)).pack(side="left", padx=6)
    win.bind("<Escape>", lambda e: win.destroy())

    def wheel(e):
        canvas.yview_scroll(-1 if (getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0) else 1, "units")
    for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
        win.bind(seq, wheel)        # not bind_all: that would replace the panel's own wheel scrolling
    win.update_idletasks()
    try:
        x = root.winfo_rootx() + max(0, (root.winfo_width() - win.winfo_reqwidth()) // 2)
        win.geometry(f"+{x}+{root.winfo_rooty() + 40}")
    except tk.TclError:
        pass
    win.grab_set()
    win.wait_window()
    return result["v"]


def import_typeitin(path):
    """Read TypeItIn's data file (datafile.enc, encrypted or not, or a dated backup of it) into families like
    import_csv_buttons does. Returns (families, unsupported) where unsupported counts TypeItIn-only commands.
    Raises ValueError with a readable reason."""
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except OSError as e:
        raise ValueError(str(e))
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")
    lines = text.replace("\r\n", "\n").split("\n")
    if not lines or not lines[0].strip():
        raise ValueError("the file is empty")
    if lines[0].strip() == TII_HEADER:
        read = lambda s: s                                   # noqa: E731  saved with encryption off
    elif tii_decrypt(lines[0]) == TII_HEADER:
        def read(s):
            if not s.strip():
                return ""
            text = tii_decrypt(s)
            if text is None:
                raise ValueError("undecryptable line")
            return text
    else:
        raise ValueError("it isn't a TypeItIn data file. In TypeItIn's folder it's called datafile.enc "
                         "(backups are datafile.enc.YYMMDD).")
    fams, unsupported, i = [], {}, 1
    try:
        # The groups end where the next lines stop looking like a group header (name, count, ..., True/False).
        while (i + 6 < len(lines) and lines[i].strip() and lines[i + 1].strip().isdigit()
               and lines[i + 5].strip() in ("True", "False")):
            name = read(lines[i]).strip()
            if not name:
                break
            count = int(lines[i + 1])
            i += 7
            buttons, colours = [], {}
            for _ in range(count):
                cols, label, _tip, body = lines[i], read(lines[i + 1]), read(lines[i + 2]), read(lines[i + 3])
                i += 4
                if not label.strip() and not body.strip():
                    continue
                for cmd in COMMAND_RE.findall(body):
                    word = re.split(r"[\s=,]", cmd.strip(), maxsplit=1)[0].lower()
                    if word in TII_UNSUPPORTED:
                        unsupported[word] = unsupported.get(word, 0) + 1
                # A TypeItIn {Run …} names a Windows program; keep the words but never launch anything.
                body = re.sub(r"\{(\s*)run(\s)", r"{\1TypeItIn-Run\2", body, flags=re.I)
                buttons.append({"label": label.strip() or body.strip()[:40],
                                "steps": [{"type": "text", "value": body}]})
                bc = cols.split(",")[-1].strip()
                colours[bc] = colours.get(bc, 0) + 1
            colour = PALETTE[len(fams) % len(PALETTE)]
            if colours:
                colour = _tii_colour(max(colours, key=colours.get), colour)
            fams.append({"name": name, "colour": colour, "buttons": buttons})
    except (IndexError, ValueError):
        raise ValueError("the file seems to be cut short or damaged partway through. Try an older backup "
                         "(datafile.enc.YYMMDD).")
    if not any(f["buttons"] for f in fams):
        raise ValueError("no buttons were found in it")
    return [f for f in fams if f["buttons"]], unsupported


# ---- cloud folders for automatic backups
def cloud_folders(home=None):
    """(service name, folder) for the Dropbox / Google Drive / OneDrive / etc. folders that exist on this computer."""
    home = home or os.path.expanduser("~")
    found = []
    for name, rel in (("Dropbox", "Dropbox"), ("Google Drive", "Google Drive"), ("Google Drive", "GoogleDrive"),
                      ("Google Drive", "My Drive"), ("Google Drive", "gdrive"), ("OneDrive", "OneDrive"),
                      ("iCloud Drive", "Library/Mobile Documents/com~apple~CloudDocs"), ("MEGA", "MEGA"),
                      ("Nextcloud", "Nextcloud"), ("pCloud", "pCloudDrive"), ("Syncthing", "Sync")):
        p = os.path.join(home, rel)
        if os.path.isdir(p):
            found.append((name, p))
    for base in ("Library/CloudStorage",):     # macOS: GoogleDrive-you@example.com, Dropbox, OneDrive-…
        for p in sorted(glob.glob(os.path.join(home, base, "*"))):
            if os.path.isdir(p):
                kind = os.path.basename(p).split("-")[0]
                found.append((kind or "Cloud", p))
    seen, out = set(), []
    for n, p in found:
        if p not in seen:
            seen.add(p)
            out.append((n, p))
    return out


def cloud_backup_dir(folder):
    return os.path.join(folder, "Quickpad backups")



def describe(step):
    kind, val = step.get("type"), step.get("value", "")
    if kind == "text":
        one = str(val).replace("\n", " ⏎ ")
        return "Type:   " + (one[:70] + "…" if len(one) > 70 else one)
    if kind == "key":
        return "Keys:   " + str(val)
    if kind == "delay":
        return f"Wait:   {val} ms"
    return f"Unknown step: {kind}"


class Abort(Exception):
    pass


# (program, arguments placed before the command). First one installed wins; gnome-terminal is Linux Mint's own.
TERMINALS = [("gnome-terminal", ["--"]), ("x-terminal-emulator", ["-e"]), ("xfce4-terminal", ["-x"]),
             ("konsole", ["-e"]), ("kitty", []), ("alacritty", ["-e"]), ("ghostty", ["-e"]), ("foot", []),
             ("xterm", ["-e"])]


def open_terminal(cmd):
    """Run a shell command in a new terminal window that stays open until Enter is pressed.
    Returns "" on success, or a message saying why it couldn't."""
    try:
        if IS_MAC:   # Terminal's default shell is zsh, so use the portable printf + read (no `read -p`)
            script = 'tell application "Terminal" to do script ' + json.dumps(
                cmd + "; echo; printf 'Finished. Press Enter to close. '; read _")
            subprocess.Popen(["osascript", "-e", script, "-e", 'tell application "Terminal" to activate'])
        elif sys.platform.startswith("win"):   # /c + pause: the window closes once a key is pressed
            subprocess.Popen(["cmd", "/c", "start", "", "cmd", "/c", cmd + " & echo. & pause"])
        else:
            script = cmd + "\necho\nprintf 'Finished. Press Enter to close this window. '\nread _"
            for name, lead in TERMINALS:
                exe = shutil.which(name)
                if exe:
                    subprocess.Popen([exe, *lead, "bash", "-c", script])
                    return ""
            return "No terminal program was found on this computer."
    except OSError as e:
        return f"Couldn't open a terminal: {e}"
    return ""


def read_clipboard(root):
    """Whatever is currently on the system clipboard, or "" if Tk can't read anything there.
    A plain function (not a Panel method) so {Clipboard} and tests can call it directly."""
    try:
        return root.clipboard_get()
    except tk.TclError:
        return ""


# ================================================================ backends

class Backend:
    name = "none"
    poll_interval = 0.25      # 0 = can't track focus
    hide_to_refocus = False   # hide panel so the compositor hands focus back
    refocus_after_prepare = False   # prepare() may put a window of its own up; hand the keyboard back afterwards
    paste_combo = "cmd+v" if IS_MAC else "ctrl+v"

    def problems(self):
        return []

    def prepare(self, notify=None):
        """Called before a button types anything. Returns "" when typing can work, or the reason it can't, in plain
        words for the person at the keyboard (the button then stops and shows it, rather than doing nothing).
        `notify(text)` shows a short note first. Most backends have nothing to ask, so they never block."""
        return ""

    def active(self):
        """(window id, is this Quickpad?)"""
        return None, False

    def own_window(self):
        """The panel's own window id for activate(), or None where the backend can't find it. Used when a second copy
        is started: "bring the one that's open to the front" has to go through the window manager (a workspace
        switch, focus-stealing rules), which a plain Tk lift() can't do."""
        return None

    def activate(self, wid):
        pass

    def activate_title(self, title):
        """Focus a window whose title contains `title`. Returns its id, or None."""
        return None

    def focus_window(self, wid, timeout=2.0):
        """Give `wid` the keyboard and say how that went: "ok", "fallback" (it took a second try), "unconfirmed"
        (it still didn't look like it had it) or "not checked" (this backend can't tell)."""
        self.activate(wid)
        return "not checked"

    def window_name(self, wid):
        return ""

    def window_class(self, wid):
        """Which program a window belongs to (X11's WM_CLASS, Hyprland's class, the process name elsewhere)."""
        return ""

    def get_clipboard(self):
        """The clipboard text, or None to have the panel read it through Tk."""
        return None

    def can_paste(self):
        """Whether Paste mode can work here (it needs a clipboard other programs can see)."""
        return True

    def type_text(self, text, delay_ms):
        pass

    def press(self, combo):
        pass

    def backspace(self, count):
        """Press Backspace `count` times (Undo last). Backends override this to do it in a few big steps."""
        for _ in range(count):
            self.press("BackSpace")

    def mouse_move(self, x, y):
        pass

    def mouse_click(self, button="left"):
        pass

    def set_clipboard(self, text):
        """Return True if handled natively; otherwise the panel uses Tk's clipboard."""
        return False

    def window_setup(self, root):
        pass

    def modifiers_held(self):
        """True while Ctrl / Shift / Alt / Super is down, False if not, None if this backend can't tell."""
        return None

    def wait_for_modifiers_up(self, timeout=1.5):
        """A button fired by a shortcut such as Ctrl+Alt+1 starts while those keys are still held. Give the person a
        moment to let go before typing, so the text isn't typed with Ctrl held and nothing gets pressed back down."""
        deadline = time.time() + timeout
        while self.modifiers_held() and time.time() < deadline:
            time.sleep(0.02)

    def release_modifiers(self):
        """Send a key-up for every modifier that could be down. Runs after every button and every Undo, in a
        `finally`, so a button can never leave Ctrl / Shift / Alt stuck, even if it errors or is cancelled part way."""


@contextlib.contextmanager
def keys_released(backend):
    """Around anything that sends keystrokes: wait for held shortcut keys to be let go first, and whatever happens
    inside (an error, a cancelled list, a keystroke tool killed by a timeout), release every modifier afterwards."""
    backend.wait_for_modifiers_up()
    try:
        yield
    finally:
        try:
            backend.release_modifiers()
        except Exception:  # noqa: BLE001 — never let the safety net hide the real error
            log.exception("couldn't release modifier keys")


class X11Backend(Backend):
    name = "X11 (xdotool)"
    # Every modifier xdotool or the person could have left down. A key-up for a key that isn't down does nothing.
    MOD_KEYSYMS = ("Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Super_L", "Super_R",
                   "ISO_Level3_Shift")
    MOD_MASK = 1 | 4 | 8 | 64          # ShiftMask | ControlMask | Mod1Mask (Alt) | Mod4Mask (Super)

    def __init__(self):
        self._cache = {}
        self._pid = str(os.getpid())
        self._x = self._dpy = None
        self._x_lock = threading.Lock()

    def release_modifiers(self):
        # Why this is needed: `--clearmodifiers` lifts any modifier that is down when xdotool starts, sends its keys,
        # then presses those modifiers back down. When a button is fired by a shortcut (Ctrl+Alt+1), Ctrl and Alt are
        # down at that moment; by the time xdotool presses them back the person has let go, so no key-up ever comes
        # and Ctrl/Alt stay stuck (Ctrl+A and Backspace "stop working" until the key is tapped again).
        sh(["xdotool", "keyup", *self.MOD_KEYSYMS], timeout=5)

    def modifiers_held(self):
        with self._x_lock:
            if self._dpy is None:
                if self._x is False:
                    return None
                lib = ctypes.util.find_library("X11")
                try:
                    self._x = ctypes.CDLL(lib) if lib else False
                except OSError:
                    self._x = False
                if not self._x:
                    return None
                self._x.XOpenDisplay.restype = ctypes.c_void_p
                self._x.XOpenDisplay.argtypes = [ctypes.c_char_p]
                self._x.XDefaultRootWindow.restype = ctypes.c_ulong
                self._x.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
                self._x.XQueryPointer.argtypes = [ctypes.c_void_p, ctypes.c_ulong] + [ctypes.c_void_p] * 7
                self._dpy = self._x.XOpenDisplay(None)
                if not self._dpy:
                    self._x = False
                    return None
            root, child = ctypes.c_ulong(), ctypes.c_ulong()
            rx, ry, wx, wy = (ctypes.c_int() for _ in range(4))
            mask = ctypes.c_uint()
            self._x.XQueryPointer(self._dpy, self._x.XDefaultRootWindow(self._dpy), ctypes.byref(root),
                                  ctypes.byref(child), ctypes.byref(rx), ctypes.byref(ry), ctypes.byref(wx),
                                  ctypes.byref(wy), ctypes.byref(mask))
            return bool(mask.value & self.MOD_MASK)

    def problems(self):
        if shutil.which("xdotool") is None:
            return ["xdotool isn't installed, so buttons can't type yet.\n\nInstall it, e.g.:  sudo apt install xdotool"]
        return []

    def active(self):
        wid = sh(["xdotool", "getactivewindow"])
        if not wid:
            return None, False
        if wid not in self._cache:
            if len(self._cache) > 512:
                self._cache.clear()
            self._cache[wid] = (sh(["xdotool", "getwindowpid", wid]) == self._pid
                                or sh(["xdotool", "getwindowname", wid]).startswith(APP))
        return wid, self._cache[wid]

    def activate(self, wid):
        sh(["xdotool", "windowactivate", "--sync", wid])

    def own_window(self):
        # The panel is the one window of this process titled exactly APP (dialogs are "Thing – Quickpad"). Searching
        # by title finds the window the window manager actually manages; Tk's winfo_id is an inner window that
        # _NET_ACTIVE_WINDOW wouldn't act on.
        ids = sh(["xdotool", "search", "--pid", self._pid, "--name", f"^{re.escape(APP)}$"]).split()
        return ids[0] if ids else None

    def focus_window(self, wid, timeout=2.0):
        # A user's report (Linux Mint, Cinnamon): nothing typed into LibreOffice Writer. xdotool types into Writer fine on
        # a plain X display, so the suspect is the hand-back: Cinnamon can ignore windowactivate's request and leave the
        # keyboard with Quickpad. So check, and if it didn't move, ask the older way (focus + raise) and check again.
        # Every wait is bounded, so a window manager that never answers can't hang the button.
        wid = str(wid)
        sh(["xdotool", "windowactivate", "--sync", wid], timeout=timeout)
        if sh(["xdotool", "getactivewindow"]) == wid:
            return "ok"
        sh(["xdotool", "windowfocus", "--sync", wid], timeout=timeout)
        sh(["xdotool", "windowraise", wid], timeout=timeout)
        deadline = time.time() + 0.6
        while True:
            if sh(["xdotool", "getactivewindow"]) == wid:
                return "fallback"
            if time.time() > deadline:
                return "unconfirmed"
            time.sleep(0.05)

    def window_name(self, wid):
        return sh(["xdotool", "getwindowname", wid])

    def window_class(self, wid):
        # xprop is on every Mint; xdotool only learnt getwindowclassname after the version Mint ships.
        if shutil.which("xprop"):
            found = re.findall(r'"([^"]*)"', sh(["xprop", "-id", wid, "WM_CLASS"]))
            if found:
                return found[-1]
        return sh(["xdotool", "getwindowclassname", wid])

    def activate_title(self, title):
        ids = sh(["xdotool", "search", "--onlyvisible", "--name", re.escape(title)]).split()
        if ids:
            self.activate(ids[0])
            return ids[0]
        return None

    def type_text(self, text, delay_ms):
        # Type line by line and press Return between, so new lines work in every app.
        for i, line in enumerate(text.split("\n")):
            if i:
                self.press("Return")
            if line:
                sh(["xdotool", "type", "--clearmodifiers", "--delay", delay_ms, "--", line], timeout=120)

    def press(self, combo):
        mods, key = parse_combo(combo)
        if key:
            sh(["xdotool", "key", "--clearmodifiers", "+".join(mods + [key])], timeout=10)

    def backspace(self, count):
        while count > 0:
            n = min(count, 100)
            sh(["xdotool", "key", "--clearmodifiers", "--delay", 4] + ["BackSpace"] * n, timeout=30)
            count -= n

    def mouse_move(self, x, y):
        sh(["xdotool", "mousemove", x, y])

    def mouse_click(self, button="left"):
        sh(["xdotool", "click", {"left": 1, "middle": 2, "right": 3}[button]])


class WtypeMixin:
    WT_MODS = {"ctrl": "ctrl", "shift": "shift", "alt": "alt", "super": "logo"}

    def type_text(self, text, delay_ms):
        for i, line in enumerate(text.split("\n")):
            if i:
                sh(["wtype", "-k", "Return"])
            if line:
                sh(["wtype", "-d", delay_ms, "-"], stdin=line, timeout=120)

    def backspace(self, count):
        while count > 0:
            n = min(count, 100)
            sh(["wtype"] + ["-k", "BackSpace"] * n, timeout=30)
            count -= n

    def press(self, combo):
        mods, key = parse_combo(combo)
        if not key:
            return
        args = ["wtype"]
        for m in mods:
            args += ["-M", self.WT_MODS[m]]
        args += ["-k", key]
        for m in reversed(mods):
            args += ["-m", self.WT_MODS[m]]
        sh(args)

    def set_clipboard(self, text):
        if shutil.which("wl-copy"):
            sh(["wl-copy"], stdin=text)
            return True
        return False

    def get_clipboard(self):
        if shutil.which("wl-paste"):
            try:
                r = subprocess.run(["wl-paste", "--no-newline"], capture_output=True, text=True, timeout=3)
                return r.stdout if r.returncode == 0 else ""
            except (OSError, subprocess.TimeoutExpired):
                return ""
        return None

    def can_paste(self):
        return bool(shutil.which("wl-copy"))

    def mouse_click(self, button="left"):
        if shutil.which("ydotool"):
            sh(["ydotool", "click", {"left": "0xC0", "right": "0xC1", "middle": "0xC2"}[button]])


class HyprlandBackend(WtypeMixin, Backend):
    name = "Hyprland (hyprctl + wtype)"

    def problems(self):
        missing = [t for t in ("wtype", "hyprctl") if shutil.which(t) is None]
        if missing:
            return [f"Missing: {', '.join(missing)}.\n\nInstall with:  sudo pacman -S --needed wtype"]
        return []

    def active(self):
        try:
            d = json.loads(sh(["hyprctl", "activewindow", "-j"]) or "{}")
        except json.JSONDecodeError:
            return None, False
        addr = d.get("address")
        if not addr:
            return None, False
        ours = d.get("pid") == os.getpid() or str(d.get("title", "")).startswith(APP)
        return addr, ours

    def activate(self, wid):
        sh(["hyprctl", "dispatch", "focuswindow", f"address:{wid}"])

    def focus_window(self, wid, timeout=2.0):
        self.activate(wid)
        deadline = time.time() + min(timeout, 0.6)
        while True:
            if self.active()[0] == wid:
                return "ok"
            if time.time() > deadline:
                return "unconfirmed"
            time.sleep(0.05)

    def _client(self, wid):
        try:
            clients = json.loads(sh(["hyprctl", "clients", "-j"]) or "[]")
        except json.JSONDecodeError:
            return {}
        return next((c for c in clients if c.get("address") == wid), {})

    def window_name(self, wid):
        return str(self._client(wid).get("title", ""))

    def window_class(self, wid):
        return str(self._client(wid).get("class", ""))

    def activate_title(self, title):
        try:
            clients = json.loads(sh(["hyprctl", "clients", "-j"]) or "[]")
        except json.JSONDecodeError:
            return None
        t = title.lower()
        for c in clients:
            if t in str(c.get("title", "")).lower() or t in str(c.get("class", "")).lower():
                self.activate(c["address"])
                return c["address"]
        return None

    def mouse_move(self, x, y):
        sh(["hyprctl", "dispatch", "movecursor", x, y])

    def window_setup(self, root):
        try:
            root.attributes("-type", "utility")
        except tk.TclError:
            pass


class WaylandBackend(WtypeMixin, Backend):
    name = "Wayland (wtype)"
    poll_interval = 0
    hide_to_refocus = True

    def problems(self):
        if shutil.which("wtype") is None:
            return ["wtype isn't installed, so buttons can't type yet.\n\n"
                    "Install it from your package manager. GNOME on Wayland doesn't support wtype; "
                    "log in with an X11 session there instead."]
        return []


# ---- KDE Plasma on Wayland. wtype needs the virtual-keyboard protocol, which KDE's compositor (KWin) doesn't offer,
# and xdotool only reaches X11 windows, so neither can type into a native-Wayland LibreOffice. What KDE does offer is
# the desktop portal's RemoteDesktop interface (KDE Connect uses it): ask once, KDE shows an Allow / Reject window and
# can remember the answer, then key presses can be sent. Chosen over ydotool because that needs a root-owned
# daemon, a udev rule and a log-out to take effect, which isn't something to ask a clinician to set up.

KDE_X11_WAY = ("Another way: log out, and on the login screen choose “Plasma (X11)” before you sign in. If it isn't "
               "in the list, open Konsole and type:\n    sudo apt install plasma-session-x11")
KDE_NO_GI = ("Quickpad can't type into other programs yet, because one small piece is missing from this computer.\n\n"
             "Open Konsole and type:\n    sudo apt install python3-gi\nthen close Quickpad and open it again.\n\n"
             + KDE_X11_WAY)
KDE_NO_PORTAL = ("Quickpad can't type into other programs because KDE's permission service "
                 "(xdg-desktop-portal-kde) isn't running.\n\nOpen Konsole and type:\n"
                 "    sudo apt install xdg-desktop-portal-kde\nthen log out and back in.\n\n" + KDE_X11_WAY)
KDE_NO_KEYBOARD = ("KDE won't let Quickpad type for you on this computer, so buttons can't type into other "
                   "programs.\n\n" + KDE_X11_WAY)
KDE_ASK_FIRST = ("KDE is about to ask whether Quickpad may type for you.\n\nPlease choose Allow. If there's a box "
                 "to remember your answer, tick it. Without it, buttons can't type into other programs.")
KDE_REFUSED = ("KDE didn't give Quickpad permission to type, so nothing was typed.\n\nClick the button again and "
               "choose Allow when KDE asks.\n\n" + KDE_X11_WAY)


def kde_failed(why):
    return (f"KDE stopped Quickpad from typing, so nothing was typed.\n\nClick the button again. If it still "
            f"doesn't work, close Quickpad and open it again.\n\n(For Nick: {why})\n\n" + KDE_X11_WAY)


class PortalError(Exception):
    """Something went wrong talking to KDE's permission service. The message says what, for the log and for Nick."""


class PortalRefused(PortalError):
    """The person said no in KDE's Allow / Reject window."""


class PortalNoKeyboard(PortalError):
    """The session was made, but KDE didn't hand over the keyboard."""


class PortalMissing(PortalError):
    """python3-gi (the way Quickpad talks to the portal) isn't on this computer."""


# Linux input key codes (linux/input-event-codes.h) for a US keyboard. The portal's NotifyKeyboardKeycode takes these.
_EVDEV_LETTERS = {**dict(zip("qwertyuiop", range(16, 26))), **dict(zip("asdfghjkl", range(30, 39))),
                  **dict(zip("zxcvbnm", range(44, 51)))}
_EVDEV_PLAIN = {**_EVDEV_LETTERS, **dict(zip("1234567890", range(2, 12))), "-": 12, "=": 13, "[": 26, "]": 27,
                ";": 39, "'": 40, "`": 41, "\\": 43, ",": 51, ".": 52, "/": 53, " ": 57, "\t": 15, "\n": 28}
_EVDEV_SHIFTED = {**{c.upper(): k for c, k in _EVDEV_LETTERS.items()}, **dict(zip("!@#$%^&*()", range(2, 12))),
                  "_": 12, "+": 13, "{": 26, "}": 27, ":": 39, '"': 40, "~": 41, "|": 43, "<": 51, ">": 52, "?": 53}
EVDEV_CHARS = {**{c: (k, False) for c, k in _EVDEV_PLAIN.items()}, **{c: (k, True) for c, k in _EVDEV_SHIFTED.items()}}
EVDEV_NAMES = {
    "return": 28, "tab": 15, "escape": 1, "backspace": 14, "delete": 111, "insert": 110, "home": 102, "end": 107,
    "up": 103, "down": 108, "left": 105, "right": 106, "prior": 104, "next": 109, "space": 57, "print": 99,
    "pause": 119, "scroll_lock": 70, "num_lock": 69, "caps_lock": 58, "menu": 127,
    **{f"f{n}": 58 + n for n in range(1, 11)}, "f11": 87, "f12": 88,
}
# The punctuation names a Press keys step accepts (COMMON_KEYS), as the character they stand for.
KEYSYM_CHARS = {"period": ".", "comma": ",", "minus": "-", "plus": "+", "slash": "/", "backslash": "\\",
                "semicolon": ";", "apostrophe": "'", "grave": "`", "equal": "=", "bracketleft": "[",
                "bracketright": "]"}
EVDEV_MODIFIERS = {"ctrl": 29, "shift": 42, "alt": 56, "super": 125}
EVDEV_ALL_MODIFIERS = (29, 97, 42, 54, 56, 100, 125, 126)      # left and right Ctrl, Shift, Alt (AltGr), Super


def keysym_for(ch):
    """The X keysym for a character: Latin-1 and ASCII are their own code, everything else is 0x01000000 + code point."""
    cp = ord(ch)
    return cp if cp < 0x100 else 0x01000000 + cp


def kde_text_events(text, by_position):
    """What it takes to type `text`: ("key", evdev code, needs shift) where the character has a key on a US keyboard
    and the layout is known to be one, otherwise ("sym", keysym), which KDE turns into whatever keys make it."""
    out = []
    for ch in text:
        if ch == "\r":
            continue
        # Return and Tab are in the same place on every layout, so they never need the layout to be known.
        hit = EVDEV_CHARS.get(ch) if by_position or ch in "\n\t" else None
        if hit:
            out.append(("key", hit[0], hit[1]))
        elif ch.isprintable():
            out.append(("sym", keysym_for(ch)))
    return out


US_LIKE_LAYOUTS = ("us", "au", "nz")       # key positions identical to a US keyboard for everything in EVDEV_CHARS


def _read_kde_layouts(path):
    cp = configparser.RawConfigParser(strict=False)
    try:
        cp.read(path, encoding="utf-8")
        if not cp.has_section("Layout") or cp.get("Layout", "Use", fallback="true").strip().lower() != "true":
            return []
        layouts = [x.strip() for x in cp.get("Layout", "LayoutList", fallback="").split(",") if x.strip()]
        variants = [x.strip() for x in cp.get("Layout", "VariantList", fallback="").split(",")]
    except (configparser.Error, OSError, UnicodeDecodeError):
        return []
    variants += [""] * (len(layouts) - len(variants))
    return list(zip(layouts, variants))


def _read_system_layouts(path):
    found = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                m = re.match(r'\s*(XKBLAYOUT|XKBVARIANT)\s*=\s*"?([^"\n]*)"?', line)
                if m:
                    found[m.group(1)] = m.group(2).strip()
    except (OSError, UnicodeDecodeError):
        return []
    layouts = [x.strip() for x in found.get("XKBLAYOUT", "").split(",") if x.strip()]
    variants = [x.strip() for x in found.get("XKBVARIANT", "").split(",")]
    variants += [""] * (len(layouts) - len(variants))
    return list(zip(layouts, variants))


def layout_is_us_like(kxkbrc=None, etc_keyboard=None):
    """True if every keyboard layout set up here is a plain US-style one, False if any isn't, None if it can't be told.
    Read from KDE's own settings first, then the system's. Used to decide whether letters can be typed by key
    position (what a US or Australian keyboard has), which doesn't depend on anything KWin does with keysyms."""
    kxkbrc = kxkbrc or os.path.expanduser("~/.config/kxkbrc")
    etc_keyboard = etc_keyboard or "/etc/default/keyboard"
    pairs = _read_kde_layouts(kxkbrc) or _read_system_layouts(etc_keyboard)
    if not pairs:
        return None
    return all(l in US_LIKE_LAYOUTS and v in ("", "basic") for l, v in pairs)


KDE_STATE_PATH = os.path.join(LOCAL_DIR, "kde-input.json")      # per computer: the answer KDE was asked to remember


class PortalKeyboard:
    """One RemoteDesktop session for the keyboard, made the first time a button needs it and kept while Quickpad runs.
    `transport` (GioPortal in real life) does the D-Bus calls; everything about what to ask, what to remember and
    when to try again is here, so it can be tested without a desktop."""
    KEYBOARD = 1
    PERSIST_UNTIL_REVOKED = 2

    def __init__(self, transport_factory, state_path, layout):
        self.factory, self.state_path, self.layout = transport_factory, state_path, layout
        self.lock = threading.RLock()
        self.transport = None
        self.session = None
        self.state = "idle"          # idle, ready, refused or failed: for Check my setup
        self.error = ""
        self.asked = False
        self._layout = "unread"

    # ---- what KDE was told last time
    def saved_token(self):
        try:
            with open(self.state_path, encoding="utf-8") as f:
                tok = json.load(f).get("restore_token")
            return tok if isinstance(tok, str) and tok else None
        except (OSError, ValueError, AttributeError):
            return None

    def save_token(self, token):
        try:
            if token:
                os.makedirs(os.path.dirname(self.state_path) or ".", exist_ok=True)
                tmp = self.state_path + ".tmp"
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump({"restore_token": token}, f)
                os.replace(tmp, self.state_path)
            elif os.path.exists(self.state_path):
                os.remove(self.state_path)      # a used token is dead; don't offer it again
        except OSError:
            log.exception("couldn't save KDE's permission token")

    # ---- talking to KDE
    def _transport(self):
        if self.transport is None:
            try:
                self.transport = self.factory()
            except (ImportError, ValueError) as e:
                raise PortalMissing(str(e)) from e
        return self.transport

    def check(self):
        """Why typing can't work here at all, in plain words, or "". Never raises KDE's permission window."""
        try:
            return self._transport().check()
        except PortalMissing:
            return KDE_NO_GI
        except PortalError as e:
            return kde_failed(str(e))

    def _layout_answer(self):
        """True: every layout here is US-style. False: one is known not to be. None: it couldn't be told."""
        if self._layout == "unread":
            try:
                self._layout = self.layout()
            except Exception:  # noqa: BLE001 — an unreadable layout is "couldn't tell"
                self._layout = None
        return self._layout

    def by_position(self):
        """Letters can go in as key presses at their US positions: only when the layout is known to be US-style.
        Anything else types by character, which KDE maps through whatever layout is in use."""
        return self._layout_answer() is True

    def known_non_us(self):
        """The layout is known not to be US-style, so a key's position says nothing about its letter. Shortcuts then
        go by character. Not the same as "couldn't tell": see KdeWaylandBackend.press."""
        return self._layout_answer() is False

    def _open(self):
        t = self._transport()
        session = t.create_session()
        try:
            t.select_devices(session, self.KEYBOARD, self.PERSIST_UNTIL_REVOKED, self.saved_token())
            got = t.start(session)
            if not (got.get("devices") or 0) & self.KEYBOARD:
                raise PortalNoKeyboard("KDE did not grant the keyboard")
        except Exception:
            try:
                t.close(session)
            except Exception:  # noqa: BLE001
                pass
            raise
        self.save_token(got.get("restore_token"))
        self.session, self.state, self.error = session, "ready", ""

    def _drop(self):
        session, self.session = self.session, None
        if session and self.transport:
            try:
                self.transport.close(session)
            except Exception:  # noqa: BLE001
                pass

    def prepare(self, notify=None):
        with self.lock:
            if self.session:
                return ""
            problem = self.check()
            if problem:
                self.state, self.error = "failed", problem
                return problem
            if notify and not self.asked and not self.saved_token():
                self.asked = True
                notify(KDE_ASK_FIRST)
            try:
                self._open()
            except PortalRefused:
                self.state = "refused"
                return KDE_REFUSED
            except PortalNoKeyboard:
                self.state, self.error = "failed", KDE_NO_KEYBOARD
                return KDE_NO_KEYBOARD
            except PortalMissing:
                self.state, self.error = "failed", KDE_NO_GI
                return KDE_NO_GI
            except PortalError as e:
                log.warning("KDE portal: %s", e)
                self.state = "failed"
                self.error = kde_failed(str(e))
                return self.error
            return ""

    def send(self, kind, value, pressed):
        """One key event ("code" = Linux key code, "sym" = keysym). A session that has gone away is replaced once."""
        with self.lock:
            for attempt in (1, 2):
                had_session = bool(self.session)
                try:
                    if not self.session:
                        self._open()
                    t = self.transport
                    (t.notify_keycode if kind == "code" else t.notify_keysym)(self.session, value, pressed)
                    return
                except PortalError:
                    self._drop()
                    if attempt == 2 or not had_session:      # a "no" from the person isn't asked a second time
                        self.state = "failed"
                        raise

    def release_all(self):
        """A key-up for every modifier, to the session if there is one (it never starts one just for this)."""
        with self.lock:
            if not self.session:
                return
            for code in EVDEV_ALL_MODIFIERS:
                try:
                    self.transport.notify_keycode(self.session, code, False)
                except PortalError:
                    return


class GioPortal:
    """The D-Bus side of PortalKeyboard, through PyGObject (python3-gi, which Ubuntu and Kubuntu already have).
    Importing this class's module-level names needs nothing; making one needs `gi`, and raises ImportError if it's
    missing so the caller can say so. A portal "Request" answers later, in a Response signal on a path we can work out
    in advance from our own connection name and a token, so we listen first and then call."""
    NAME = "org.freedesktop.portal.Desktop"
    PATH = "/org/freedesktop/portal/desktop"
    RD = "org.freedesktop.portal.RemoteDesktop"

    def __init__(self, timeout=90.0):
        from gi.repository import Gio, GLib       # ImportError / ValueError when python3-gi isn't usable
        self.Gio, self.GLib, self.timeout = Gio, GLib, timeout
        try:
            self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except GLib.Error as e:
            raise PortalError(f"couldn't reach the desktop's message service: {e.message}") from e

    def _call(self, iface, method, params, path=None, reply_type=None, timeout_ms=10000):
        try:
            return self.bus.call_sync(self.NAME, path or self.PATH, iface, method, params, reply_type,
                                      self.Gio.DBusCallFlags.NONE, timeout_ms, None)
        except self.GLib.Error as e:
            raise PortalError(e.message) from e

    def _property(self, name):
        got = self._call("org.freedesktop.DBus.Properties", "Get", self.GLib.Variant("(ss)", (self.RD, name)))
        return got.unpack()[0]

    def check(self):
        try:
            self._property("version")
        except PortalError:
            return KDE_NO_PORTAL
        try:
            if not int(self._property("AvailableDeviceTypes")) & PortalKeyboard.KEYBOARD:
                return KDE_NO_KEYBOARD
        except (PortalError, TypeError, ValueError):
            pass                  # can't tell: let the real request answer
        return ""

    def _request(self, method, build):
        """Call a portal method that answers with a Response signal. Returns (response code, results dict)."""
        token = "quickpad" + secrets.token_hex(6)
        sender = self.bus.get_unique_name().lstrip(":").replace(".", "_")
        path = f"{self.PATH}/request/{sender}/{token}"
        box = []
        ctx = self.GLib.MainContext.new()
        ctx.push_thread_default()
        try:
            sub = self.bus.signal_subscribe(
                self.NAME, "org.freedesktop.portal.Request", "Response", path, None, self.Gio.DBusSignalFlags.NONE,
                lambda conn, sender_name, obj, iface, sig, params, *rest: box.append(params.unpack()))
            try:
                self._call(self.RD, method, build(token))
                deadline = time.time() + self.timeout
                while not box:
                    if not ctx.iteration(False):
                        if time.time() > deadline:
                            raise PortalError("KDE didn't answer in time")
                        time.sleep(0.02)
            finally:
                self.bus.signal_unsubscribe(sub)
        finally:
            ctx.pop_thread_default()
        return box[0]

    def _variant(self, kind, value):
        return self.GLib.Variant(kind, value)

    def create_session(self):
        V = self._variant
        code, res = self._request("CreateSession", lambda tok: V("(a{sv})", ({
            "handle_token": V("s", tok), "session_handle_token": V("s", "quickpad" + secrets.token_hex(6))},)))
        if code != 0 or "session_handle" not in res:
            raise PortalError(f"KDE would not start a remote-control session (answer {code})")
        return str(res["session_handle"])

    def select_devices(self, session, types, persist_mode, restore_token):
        V = self._variant

        def build(tok):
            opts = {"handle_token": V("s", tok), "types": V("u", types), "persist_mode": V("u", persist_mode)}
            if restore_token:
                opts["restore_token"] = V("s", restore_token)
            return V("(oa{sv})", (session, opts))
        code, _ = self._request("SelectDevices", build)
        if code != 0:
            raise PortalError(f"KDE would not take the device request (answer {code})")

    def start(self, session):
        V = self._variant
        code, res = self._request("Start", lambda tok: V("(osa{sv})", (session, "", {"handle_token": V("s", tok)})))
        if code == 1:
            raise PortalRefused("the person chose Reject")
        if code != 0:
            raise PortalError(f"KDE would not start remote control (answer {code})")
        return {"devices": int(res.get("devices", 0)), "restore_token": res.get("restore_token")}

    def _notify(self, method, session, value, pressed):
        self._call(self.RD, method, self._variant("(oa{sv}iu)", (session, {}, int(value), 1 if pressed else 0)),
                   timeout_ms=5000)

    def notify_keycode(self, session, code, pressed):
        self._notify("NotifyKeyboardKeycode", session, code, pressed)

    def notify_keysym(self, session, sym, pressed):
        self._notify("NotifyKeyboardKeysym", session, sym, pressed)

    def close(self, session):
        self._call("org.freedesktop.portal.Session", "Close", None, path=session, timeout_ms=2000)


class KdeWaylandBackend(Backend):
    name = "KDE Plasma on Wayland (desktop portal)"
    paste_combo = "ctrl+v"
    poll_interval = 0            # KDE won't tell a program which other window has the keyboard
    hide_to_refocus = True       # so step the panel aside and KDE hands the keyboard back to where it was
    refocus_after_prepare = True     # KDE's Allow window takes the keyboard while it is up

    def __init__(self, transport_factory=None, state_path=None, layout=None):
        self.keyboard = PortalKeyboard(transport_factory or GioPortal, state_path or KDE_STATE_PATH,
                                       layout or layout_is_us_like)
        self._x11 = None

    # ---- is it going to work, and if not, why
    def problems(self):
        problem = self.keyboard.check()
        return [problem] if problem else []

    def prepare(self, notify=None):
        return self.keyboard.prepare(notify)

    def status(self):
        """(OK / WARN / BAD, plain words) for Check my setup."""
        k = self.keyboard
        how = ("Letters go in as key presses at their key positions (a US or Australian keyboard)."
               if k.by_position() else "Letters go in by character, so any keyboard layout works.")
        problem = k.check()
        if problem:
            return BAD, problem
        if k.state == "refused":
            return BAD, KDE_REFUSED
        if k.state == "failed" and k.error:
            return BAD, k.error
        if k.session:
            return OK, "working: KDE has allowed Quickpad to type, through its remote-control permission. " + how
        return WARN, ("not checked yet. KDE will ask your permission the first time a button types: choose Allow. "
                      + how)

    # ---- typing
    def type_text(self, text, delay_ms):
        k = self.keyboard
        pause = max(0.0, float(delay_ms or 0)) / 1000
        for ev in kde_text_events(text, k.by_position()):
            if ev[0] == "key":
                self._chord([EVDEV_MODIFIERS["shift"]] if ev[2] else [], ev[1])
            else:
                with k.lock:
                    k.send("sym", ev[1], True)
                    k.send("sym", ev[1], False)
            if pause:
                time.sleep(pause)

    def _chord(self, modifiers, code):
        """Modifiers down, the key, modifiers up: one unbroken step under the lock, and the modifiers always come
        back up, even if the key itself fails (the stuck-Ctrl bug, see HANDOFF.md)."""
        k = self.keyboard
        with k.lock:
            held = []
            try:
                for m in modifiers:
                    k.send("code", m, True)
                    held.append(m)
                k.send("code", code, True)
                k.send("code", code, False)
            finally:
                for m in reversed(held):
                    try:
                        k.send("code", m, False)
                    except PortalError:
                        log.exception("couldn't let go of a modifier key")

    def _chord_sym(self, modifiers, sym):
        """Like _chord, for a key sent by character: modifiers go down by key code, the character is pressed and
        released, and the modifiers always come back up."""
        k = self.keyboard
        with k.lock:
            held = []
            try:
                for m in modifiers:
                    k.send("code", m, True)
                    held.append(m)
                k.send("sym", sym, True)
                k.send("sym", sym, False)
            finally:
                for m in reversed(held):
                    try:
                        k.send("code", m, False)
                    except PortalError:
                        log.exception("couldn't let go of a modifier key")

    def press(self, combo):
        mods, key = parse_combo(combo)
        if not key:
            return
        held = [EVDEV_MODIFIERS[m] for m in mods]
        name = key.lower()
        code = EVDEV_NAMES.get(name)
        if code is not None:           # Return, F5, the arrows, Menu…: the same place on every layout
            self._chord(held, code)
            return
        ch = KEYSYM_CHARS.get(name) or (key if len(key) == 1 else "")
        if not ch:
            log.warning("Quickpad doesn't know the key “%s”, so it was not pressed", key)
            return
        if self.keyboard.known_non_us():
            # A key's position says nothing about its letter here (key 30 is "q" on AZERTY): go by character.
            self._chord_sym(held, keysym_for(ch))
            return
        hit = EVDEV_CHARS.get(ch) or EVDEV_CHARS.get(ch.lower())
        if hit:
            if hit[1] and EVDEV_MODIFIERS["shift"] not in held:
                held.append(EVDEV_MODIFIERS["shift"])
            self._chord(held, hit[0])
        else:                          # a character with no key on a US keyboard: by character, modifiers kept
            self._chord_sym(held, keysym_for(ch))

    def backspace(self, count):
        for _ in range(count):
            self._chord([], EVDEV_NAMES["backspace"])

    def release_modifiers(self):
        self.keyboard.release_all()

    # ---- the panel's own window is an X11 window (Tk), so the usual X11 way of raising it still works
    def _xwin(self):
        if self._x11 is None and shutil.which("xdotool") and os.environ.get("DISPLAY"):
            self._x11 = X11Backend()
        return self._x11

    def own_window(self):
        x = self._xwin()
        return x.own_window() if x else None

    def activate(self, wid):
        x = self._xwin()
        if x:
            x.activate(wid)


class MacBackend(Backend):
    name = "macOS (System Events)"
    poll_interval = 0.5
    KEY_CODES = {
        "return": 36, "enter": 36, "tab": 48, "space": 49, "escape": 53, "esc": 53,
        "backspace": 51, "delete": 117, "up": 126, "down": 125, "left": 123, "right": 124,
        "home": 115, "end": 119, "pageup": 116, "page_up": 116, "prior": 116,
        "pagedown": 121, "page_down": 121, "next": 121,
        "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96, "f6": 97, "f7": 98, "f8": 100,
        "f9": 101, "f10": 109, "f11": 103, "f12": 111,
    }
    MAC_MODS = {"ctrl": "control down", "shift": "shift down", "alt": "option down", "super": "command down"}

    @staticmethod
    def osa(script):
        return sh(["osascript", "-e", script], timeout=10)

    @staticmethod
    def esc(s):
        return s.replace("\\", "\\\\").replace('"', '\\"')

    def active(self):
        pid = self.osa('tell application "System Events" to get unix id of first process whose frontmost is true')
        if not pid:
            return None, False
        return pid, pid == str(os.getpid())

    def activate(self, wid):
        self.osa(f'tell application "System Events" to set frontmost of (first process whose unix id is {wid}) to true')

    def activate_title(self, title):
        pid = self.osa('tell application "System Events" to get unix id of first process whose '
                       f'(name contains "{self.esc(title)}") and (background only is false)')
        if pid:
            self.activate(pid)
            return pid
        return None

    def type_text(self, text, delay_ms):
        for i, line in enumerate(text.split("\n")):
            if i:
                self.osa('tell application "System Events" to key code 36')
            if line:
                self.osa(f'tell application "System Events" to keystroke "{self.esc(line)}"')

    def press(self, combo):
        mods, key = parse_combo(combo)
        if not key:
            return
        using = f" using {{{', '.join(self.MAC_MODS[m] for m in mods)}}}" if mods else ""
        code = self.KEY_CODES.get(key.lower())
        action = f"key code {code}" if code is not None else f'keystroke "{self.esc(key.lower())}"'
        self.osa(f'tell application "System Events" to {action}{using}')

    def set_clipboard(self, text):
        sh(["pbcopy"], stdin=text)
        return True

    def get_clipboard(self):
        try:
            return subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3).stdout
        except (OSError, subprocess.TimeoutExpired):
            return ""

    def window_class(self, wid):
        # The app's name ("soffice" for LibreOffice). One osascript call per button (they take a moment), so the
        # window title isn't asked for separately: on a Mac the log shows the app name only.
        return self.osa(f'tell application "System Events" to get name of first process whose unix id is {wid}')

    def mouse_move(self, x, y):
        if shutil.which("cliclick"):
            sh(["cliclick", f"m:{x},{y}"])

    def mouse_click(self, button="left"):
        if shutil.which("cliclick"):
            sh(["cliclick", {"left": "c:.", "right": "rc:."}.get(button, "c:.")])


class WindowsBackend(Backend):
    name = "Windows (SendInput)"
    VK = {
        "return": 0x0D, "enter": 0x0D, "tab": 0x09, "space": 0x20, "escape": 0x1B, "esc": 0x1B,
        "backspace": 0x08, "delete": 0x2E, "insert": 0x2D, "up": 0x26, "down": 0x28, "left": 0x25,
        "right": 0x27, "home": 0x24, "end": 0x23, "pageup": 0x21, "page_up": 0x21, "prior": 0x21,
        "pagedown": 0x22, "page_down": 0x22, "next": 0x22,
        **{f"f{n}": 0x6F + n for n in range(1, 13)},
    }
    MOD_VK = {"ctrl": 0x11, "shift": 0x10, "alt": 0x12, "super": 0x5B}

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ctypes, self.wt = ctypes, wintypes
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                        ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

        class HARDWAREINPUT(ctypes.Structure):
            _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

        class _U(ctypes.Union):
            _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT), ("hi", HARDWAREINPUT)]

        class INPUT(ctypes.Structure):
            _anonymous_ = ("u",)
            _fields_ = [("type", wintypes.DWORD), ("u", _U)]

        self.KEYBDINPUT, self.MOUSEINPUT, self.INPUT = KEYBDINPUT, MOUSEINPUT, INPUT
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.VkKeyScanW.restype = ctypes.c_short

    def _ki(self, vk=0, scan=0, flags=0):
        i = self.INPUT(type=1)
        i.ki = self.KEYBDINPUT(vk, scan, flags, 0, 0)
        return i

    def _send(self, inputs):
        arr = (self.INPUT * len(inputs))(*inputs)
        self.user32.SendInput(len(inputs), arr, self.ctypes.sizeof(self.INPUT))

    def active(self):
        hwnd = self.user32.GetForegroundWindow()
        if not hwnd:
            return None, False
        pid = self.wt.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd, self.ctypes.byref(pid))
        return hwnd, pid.value == os.getpid()

    def activate(self, wid):
        if self.user32.IsIconic(wid):
            self.user32.ShowWindow(wid, 9)  # SW_RESTORE
        self.user32.SetForegroundWindow(wid)

    def focus_window(self, wid, timeout=2.0):
        self.activate(wid)
        deadline = time.time() + min(timeout, 0.6)
        while True:
            if self.user32.GetForegroundWindow() == wid:
                return "ok"
            if time.time() > deadline:
                return "unconfirmed"
            time.sleep(0.05)

    def window_name(self, wid):
        n = self.user32.GetWindowTextLengthW(wid)
        buf = self.ctypes.create_unicode_buffer(n + 1)
        self.user32.GetWindowTextW(wid, buf, n + 1)
        return buf.value

    def window_class(self, wid):
        """The program's file name (soffice.bin for LibreOffice), which says more than the window class."""
        pid = self.wt.DWORD()
        self.user32.GetWindowThreadProcessId(wid, self.ctypes.byref(pid))
        k32 = self.ctypes.WinDLL("kernel32", use_last_error=True)
        k32.OpenProcess.restype = self.wt.HANDLE
        h = k32.OpenProcess(0x1000, False, pid.value)       # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf, size = self.ctypes.create_unicode_buffer(520), self.wt.DWORD(520)
            if k32.QueryFullProcessImageNameW(h, 0, buf, self.ctypes.byref(size)):
                return os.path.basename(buf.value)
            return ""
        finally:
            k32.CloseHandle(h)

    def activate_title(self, title):
        found = []
        t = title.lower()
        PROC = self.ctypes.WINFUNCTYPE(self.wt.BOOL, self.wt.HWND, self.wt.LPARAM)

        def cb(hwnd, _):
            if self.user32.IsWindowVisible(hwnd):
                n = self.user32.GetWindowTextLengthW(hwnd)
                if n:
                    buf = self.ctypes.create_unicode_buffer(n + 1)
                    self.user32.GetWindowTextW(hwnd, buf, n + 1)
                    if t in buf.value.lower():
                        found.append(hwnd)
                        return False
            return True
        self.user32.EnumWindows(PROC(cb), 0)
        if found:
            self.activate(found[0])
            return found[0]
        return None

    def type_text(self, text, delay_ms):
        KEYUP, UNICODE = 0x2, 0x4
        for ch in text.replace("\r\n", "\n"):
            if ch == "\n":
                self._send([self._ki(0x0D), self._ki(0x0D, flags=KEYUP)])
            else:
                data = ch.encode("utf-16-le")
                for k in range(0, len(data), 2):
                    unit = int.from_bytes(data[k:k + 2], "little")
                    self._send([self._ki(0, unit, UNICODE), self._ki(0, unit, UNICODE | KEYUP)])
            if delay_ms:
                time.sleep(delay_ms / 1000)

    def press(self, combo):
        mods, key = parse_combo(combo)
        if not key:
            return
        vk = self.VK.get(key.lower())
        if vk is None and len(key) == 1:
            vk = self.user32.VkKeyScanW(ord(key)) & 0xFF
        if vk is None:
            return
        mvks = [self.MOD_VK[m] for m in mods]
        seq = [self._ki(m) for m in mvks] + [self._ki(vk), self._ki(vk, flags=0x2)]
        seq += [self._ki(m, flags=0x2) for m in reversed(mvks)]
        self._send(seq)

    # Left/right Shift, Ctrl, Alt and Windows keys.
    SIDED_MODS = (0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0x5B, 0x5C)

    def modifiers_held(self):
        return any(self.user32.GetAsyncKeyState(vk) & 0x8000 for vk in self.SIDED_MODS)

    def release_modifiers(self):
        # Only keys Windows says are down: a stray Windows-key up is best not sent. SendInput can drop part of a
        # sequence (e.g. when the target window is elevated), which is what could leave one down.
        down = [vk for vk in self.SIDED_MODS if self.user32.GetAsyncKeyState(vk) & 0x8000]
        if down:
            self._send([self._ki(vk, flags=0x2) for vk in down])

    def mouse_move(self, x, y):
        self.user32.SetCursorPos(int(x), int(y))

    def mouse_click(self, button="left"):
        down, up = {"left": (0x2, 0x4), "right": (0x8, 0x10), "middle": (0x20, 0x40)}[button]
        for flag in (down, up):
            i = self.INPUT(type=0)
            i.mi = self.MOUSEINPUT(0, 0, 0, flag, 0, 0)
            self._send([i])


def pick_backend():
    if IS_MAC:
        return MacBackend()
    if sys.platform.startswith("win"):
        return WindowsBackend()
    if os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
        return HyprlandBackend()
    if os.environ.get("XDG_SESSION_TYPE") == "wayland" or (os.environ.get("WAYLAND_DISPLAY") and not os.environ.get("DISPLAY")):
        # KDE's compositor has no virtual-keyboard protocol, so wtype can't type there (see KdeWaylandBackend).
        return KdeWaylandBackend() if is_kde() else WaylandBackend()
    return X11Backend()


def desktop_names(env=None):
    """The desktop(s) named in XDG_CURRENT_DESKTOP, upper-cased: "KDE", "UBUNTU:GNOME" -> ["UBUNTU", "GNOME"]."""
    raw = (env if env is not None else os.environ).get("XDG_CURRENT_DESKTOP", "")
    return [x.strip().upper() for x in re.split(r"[:;]", raw) if x.strip()]


def is_kde(env=None):
    return "KDE" in desktop_names(env)


DESKTOP_WORDS = {"KDE": "KDE Plasma", "GNOME": "GNOME", "X-CINNAMON": "Cinnamon", "CINNAMON": "Cinnamon",
                 "XFCE": "Xfce", "X-XFCE": "Xfce", "MATE": "MATE", "LXQT": "LXQt", "HYPRLAND": "Hyprland",
                 "SWAY": "Sway", "UNITY": "Unity", "BUDGIE": "Budgie", "COSMIC": "COSMIC"}
SESSION_WORDS = {"wayland": "Wayland session", "x11": "X11 session"}


def desktop_label(env=None):
    """The "Desktop" line of Check my setup, in words: "KDE Plasma (Wayland session)". The session matters most: a
    Wayland session is why typing needs a different route from the one Linux Mint uses."""
    env = env if env is not None else os.environ
    names = desktop_names(env)
    desktop = next((DESKTOP_WORDS[n] for n in names if n in DESKTOP_WORDS), "") or env.get("XDG_CURRENT_DESKTOP", "")
    session = env.get("XDG_SESSION_TYPE", "") or ("windows" if sys.platform.startswith("win")
                                                  else "mac" if IS_MAC else "unknown")
    return f"{desktop or 'unknown'} ({SESSION_WORDS.get(session.lower(), session)})"


def window_info(backend, wid):
    """(title, class) of a window, as far as the backend can tell; ("", "") when it can't."""
    try:
        return (str(getattr(backend, "window_name", lambda w: "")(wid) or ""),
                str(getattr(backend, "window_class", lambda w: "")(wid) or ""))
    except Exception:  # noqa: BLE001 — only used for the log and the paste choice
        return "", ""


def app_name(title):
    """Just the program's part of a window title ("Untitled 1 - LibreOffice Writer" → LibreOffice Writer), for the
    log. The rest of a title is often a document or patient name, which must never be written to the log."""
    for sep in (" — ", " – ", " - "):
        if sep in title:
            return "“" + title.rsplit(sep, 1)[1].strip()[:60] + "”"
    return "a window (title not logged)" if title else "an unnamed window"


def class_matches(pattern, wclass):
    """Is this window class on the paste list? The list is a pattern such as libreoffice|soffice (any part matching,
    capitals ignored); if it isn't a valid pattern, each |-separated name is looked for as plain text."""
    if not wclass or not (pattern or "").strip():
        return False
    try:
        return re.search(pattern, wclass, re.I) is not None
    except re.error:
        return any(p.strip().lower() in wclass.lower() for p in pattern.split("|") if p.strip())


def choose_insert_method(settings, wclass, backend):
    """("type" or "paste", why) for a button about to go into a window of class `wclass` (SPEC-3.3 §7)."""
    mode = (settings or {}).get("insert_method", "type")
    can = getattr(backend, "can_paste", lambda: True)()
    if mode == "paste":
        return ("paste", "Paste is chosen in Settings") if can else ("type", "Paste isn't possible on this computer")
    if mode == "auto":
        if class_matches((settings or {}).get("paste_programs", DEFAULT_PASTE_PROGRAMS), wclass):
            return ("paste", "Auto: this program is on the paste list") if can else \
                   ("type", "Auto: Paste isn't possible on this computer")
        return "type", "Auto: this program isn't on the paste list"
    return "type", "Type is chosen in Settings"


class FocusTracker(threading.Thread):
    """Remembers the last active window that isn't Quickpad, so buttons type into it."""

    def __init__(self, backend):
        super().__init__(daemon=True)
        self.backend = backend
        self.last = None

    def run(self):
        if self.backend.poll_interval <= 0:
            return
        while True:
            try:
                wid, ours = self.backend.active()
            except Exception:
                wid, ours = None, False
            if wid and not ours:
                self.last = wid
            time.sleep(self.backend.poll_interval)


# ================================================================ running a button

class Runner:
    """Runs a button's steps on a worker thread. UI work (lists, clipboard, family switch) is sent to the Tk thread."""
    depth, method, method_why, saved_clip, focus = 0, "type", "", None, "not needed"     # see __init__
    ready = False
    wf_override = None

    def __init__(self, panel, target, delay_ms):
        self.panel = panel
        self.backend = panel.backend
        self.target = target
        self.delay = delay_ms
        self.typed = 0            # characters put into the other program, so "Undo last" knows how many to remove
        self.undoable = True      # False once something happens that Backspace can't take back
        self.stats = new_run_stats()   # for Settings > Time saved
        self.last_heard = None    # (heard, typed, changes) of a dictation typed without checking, for "Fix a word"
        self.method = "type"      # how text goes in: "type" (keystrokes) or "paste" (clipboard + Ctrl+V); see run()
        self.focus = "not needed"         # how handing the keyboard back to the other program went (for the log)
        self.saved_clip = None    # the clipboard as it was before Paste mode borrowed it; put back when the run ends
        self.depth = 0            # how many chosen list items deep the text being run is (see run_text)
        self.wf_override = None   # {NextStep}, {Stay}, {Workflow name}…: what the workflow does once this button is done
        self.ready = False        # the backend has said typing can work (see ensure_ready)

    @property
    def settings(self):
        return (getattr(self.panel, "cfg", None) or {}).get("settings", {})

    def type(self, text, counted=True):
        if text:
            self.ensure_ready()
        if self.method == "paste" and text:
            self.paste_text(text)
        else:
            self.backend.type_text(text, self.delay)
        self.typed += len(text)
        if counted:
            self.stats["words"] += count_words(text)

    def press(self, combo, count=1):
        """Press a key; only Enter counts as text that Undo can remove."""
        self.ensure_ready()
        self.stats["actions"] += count
        for _ in range(count):
            self.backend.press(combo)
        if combo.lower() in ("return", "enter"):
            self.typed += count
        else:
            self.undoable = False

    def ui(self, fn):
        done, box = threading.Event(), {}
        self.panel.ui_queue.put((fn, box, done))
        done.wait()
        if "e" in box:
            raise box["e"]
        return box.get("v")

    def over_panel(self, show):
        """Run `show` (a window to put in front of the person) on the Tk thread with the panel visible. On the
        Wayland setups where the panel steps aside while a button types, a dialog belonging to it goes away with
        it, and the button would wait for a click nobody can make. The panel steps aside again afterwards."""
        def go():
            root = getattr(self.panel, "root", None)
            hidden = False
            try:
                if root is not None and root.state() in ("iconic", "withdrawn"):
                    root.deiconify()
                    hidden = True
            except tk.TclError:
                pass
            try:
                return show()
            finally:
                if hidden:
                    try:
                        root.iconify()
                    except tk.TclError:
                        pass
        return self.ui(go)

    def stop(self, message):
        """Stop the whole button, saying why."""
        self.over_panel(lambda: messagebox.showwarning(APP, message, parent=self.panel.root))
        raise Abort(message)

    def check_ready(self):
        """Before anything is typed: can this computer type into other programs at all? If not, say why in plain
        words and stop the button. A button that silently does nothing is the worst answer."""
        prepare = getattr(self.backend, "prepare", None)
        if not prepare:
            return

        def note(text):
            self.over_panel(lambda: messagebox.showinfo(APP, text, parent=self.panel.root))
            time.sleep(0.5)          # the panel is tucked away again: let the desktop hand the keyboard back
        problem = prepare(note)
        if problem:
            self.stop(problem)

    def ensure_ready(self):
        """Ask the backend whether typing can work, once, just before the first key is sent. A button that only
        runs a program, waits or sets a variable never sends a key, so it never asks KDE for the keyboard and a
        refused permission doesn't stop it."""
        if self.ready:
            return
        self.check_ready()          # stops the button, saying why, if typing can't work
        self.ready = True
        if getattr(self.backend, "refocus_after_prepare", False):
            self.refocus()          # KDE's own window (if it appeared) had the keyboard: give it back

    def refocus(self):
        """Hand the keyboard back to the program being typed into, and check that it really got it."""
        if self.target:
            focus = getattr(self.backend, "focus_window", None)
            outcome = focus(self.target) if focus else (self.backend.activate(self.target) or "not checked")
            if self.focus in ("not needed", "ok"):      # keep the first problem for the log, not a later success
                self.focus = outcome
            time.sleep(0.12)

    # ---- Paste mode (Settings › Buttons › How text goes in): for programs that drop typed keystrokes
    def read_clip(self):
        got = getattr(self.backend, "get_clipboard", lambda: None)()
        return got if got is not None else (self.ui(self.panel.get_clipboard) or "")

    def put_clip(self, text):
        if not self.backend.set_clipboard(text):
            self.ui(lambda: self.panel.set_clipboard(text))

    def original_clipboard(self):
        """What was on the clipboard before this button, even if Paste mode has borrowed it since."""
        return self.saved_clip if self.saved_clip is not None else self.read_clip()

    def paste_text(self, text):
        if self.saved_clip is None:
            self.saved_clip = self.read_clip()
        self.put_clip(text)
        time.sleep(0.08)
        self.backend.press(self.backend.paste_combo)
        time.sleep(0.15)          # let the program take it before the clipboard changes again

    def restore_clipboard(self):
        if self.saved_clip is not None:
            old, self.saved_clip = self.saved_clip, None
            time.sleep(0.4)       # some programs read a paste a moment after Ctrl+V
            try:
                self.put_clip(old)
            except Exception:  # noqa: BLE001 — never let this hide what the button itself did
                log.exception("couldn't put the clipboard back")

    def run(self, steps):
        info = window_info(self.backend, self.target) if self.target else ("", "")
        self.method, self.method_why = choose_insert_method(self.settings, info[1], self.backend)
        outcome = "error"
        try:
            with keys_released(self.backend):
                self.refocus()
                for s in steps:
                    kind, val = s.get("type"), s.get("value", "")
                    if kind == "text" and val:
                        self.run_text(str(val))
                    elif kind == "key":
                        for combo in str(val).split():
                            self.press(combo)
                    elif kind == "delay":
                        self.sleep_ms(val)
            outcome = "finished"
        except Abort:
            outcome = "stopped"
            raise
        finally:
            self.restore_clipboard()
            # Never the text typed (it can be clinical), and only the program's name from the window title: the rest
            # of a title is often a document or patient name.
            log.info("Button run: into %s [%s], focus %s, inserted by %s (%s), %s", app_name(info[0]),
                     info[1] or "class unknown", self.focus, self.method, self.method_why, outcome)

    @staticmethod
    def sleep_ms(val):
        try:
            time.sleep(max(0.0, float(val)) / 1000)
        except (TypeError, ValueError):
            pass

    def run_text(self, text, depth=0):
        """Run one piece of macro text. `depth` counts lists opened from inside chosen items."""
        if depth > MAX_LIST_DEPTH:
            self.stop("This button was stopped: its lists are nested too deep (more than 8 lists open inside each "
                      "other). Check that no saved list picks from itself, directly or through another list.")
        outer, self.depth = self.depth, depth
        try:
            for kind, part in tokenize(text):
                if kind == "text":
                    self.type(part)
                elif not self.command(part):
                    self.type("{" + part + "}")
        finally:
            self.depth = outer

    def choose(self, choice):
        """Show a chooser for a parsed {List…}/{Choose…}/{List:Name}. Returns the chosen items (one, or the ticked ones
        for Multi…), or raises Abort if it was cancelled."""
        if choice["kind"] == "saved":
            lst = find_saved_list(getattr(self.panel, "cfg", None), choice["name"])
            if lst is None:
                self.stop(f"This button uses a saved list called “{choice['name']}”, but there isn't one with that "
                          "name. Check the name in Edit buttons › Saved lists.")
            items = [{"label": str(it.get("label", "")), "value": str(it.get("value", it.get("label", "")))}
                     for it in lst.get("items", [])]
            title = lst.get("name", "")
            if not items:
                self.stop(f"The saved list “{title}” has nothing in it yet. Add its choices in Edit buttons › "
                          "Saved lists.")
        else:
            items, title = choice["items"], choice["title"]
            if not items:
                raise Abort()
        labels = [it["label"] or choice_display(it["value"]) for it in items]
        root = getattr(self.panel, "root", None)
        if choice["multi"]:
            picked = self.ui(lambda: choose_many(root, labels, title))
            if picked is None:
                raise Abort()
            self.refocus()
            return [items[i] for i in picked]
        picked = self.ui(lambda: choose_from_list(root, labels, *([title] if title else [])))
        if picked is None:
            raise Abort()
        self.refocus()
        return [items[labels.index(picked)] if picked in labels else {"label": picked, "value": picked}]

    def command(self, body):
        """Run one {command}. Returns False if it isn't a command (so it gets typed literally)."""
        raw, body, depth = body, body.strip(), self.depth
        name, _, arg = body.partition(" ")
        low, arg = name.lower(), arg.strip()
        vars_ = self.panel.vars

        # TypeItIn: {Var1 =?Question|Default} asks and remembers the answer without typing it
        m = re.fullmatch(r"(var\w*)\s*=\s*\?(.*)", body, re.I | re.S)
        if m:
            prompt, _, default = m.group(2).partition("|")
            answer = self.ui(lambda: ask_text(self.panel.root, prompt.strip() or "Type a value:", default.strip()))
            if answer is None:
                raise Abort()
            self.refocus()
            vars_[m.group(1).lower()] = answer
            return True
        # TypeItIn: {Var1 List Title: …,a,b} picks from a list and remembers the choice without typing it
        # (when the chosen item has commands in it, the item's text is what's remembered, not run)
        m = re.fullmatch(r"(var\w*)\s+(list\s+.*)", raw, re.I | re.S)
        if m:
            choice = parse_choice(m.group(2))
            if choice is None:
                return False
            vars_[m.group(1).lower()] = self.choose(choice)[0]["value"]
            return True
        # TypeItIn counters: {Var +1}, {Var1 -2}
        m = re.fullmatch(r"(var\w*)\s*([+-])\s*(\d+)", body, re.I)
        if m:
            try:
                cur = int(vars_.get(m.group(1).lower(), "0") or 0)
            except ValueError:
                cur = 0
            vars_[m.group(1).lower()] = str(cur + int(m.group(3)) * (1 if m.group(2) == "+" else -1))
            return True

        # {Var1=Hello} / {Var1}
        m = re.fullmatch(r"(var\w*)\s*=\s*(.*)", body, re.I | re.S)
        if m:
            vars_[m.group(1).lower()] = m.group(2)
            return True
        if low in vars_ and not arg:
            self.type(vars_[low])
            return True

        # Workflow commands (SPEC-3.3 §3.4): nothing happens now; once the whole button has finished, the workflow
        # moves (the last one in the button wins, over the button's own "After this button" choice).
        if low in WORKFLOW_COMMANDS and not arg:
            self.wf_override = WORKFLOW_COMMANDS[low]
            return True
        if low == "workflow" and arg:
            self.wf_override = ("start", arg)
            return True

        # Choosers: {List a,b}, {List Title: T,a,b}, {Choose:a|b}, {MultiChoose:a|b}, {List:Saved}, {MultiList:Saved}.
        # Whatever is chosen runs as a macro itself, so an item can press {Enter} or open another list.
        choice = parse_choice(raw)
        if choice:
            chosen = self.choose(choice)
            if choice["multi"]:
                for k, part in enumerate(join_multi([it["value"] for it in chosen])):
                    if k % 2:
                        self.type(part)                  # the ", " and " and " between ticked items
                    else:
                        self.run_text(part, depth + 1)
            else:
                self.run_text(chosen[0]["value"], depth + 1)
            return True
        if low in ESCAPES and not arg:
            self.type(ESCAPES[low])
            return True

        # Plain keys, optionally repeated: {Tab}, {Enter 2}. {Pause 2} waits (below); the Pause key is {Key pause}.
        if low in KEY_ALIASES and low != "pause":
            count = int(arg) if arg.isdigit() else 1
            self.press(KEY_ALIASES[low], max(1, min(count, 100)))
            return True

        if low == "key" and arg:
            for combo in arg.split():
                self.press(combo)
        elif low in ("shift", "ctrl", "control", "alt") and arg:
            # TypeItIn: {Shift :} {Shift A} {Ctrl c} {Alt F4}. Shifted characters are simply typed.
            mod = "ctrl" if low == "control" else low
            if arg.lower() in KEY_ALIASES:
                self.press(f"{mod}+{KEY_ALIASES[arg.lower()]}")
            elif mod == "shift":
                self.type(arg.upper())
            else:
                self.press(f"{mod}+{arg.lower()}")
        elif low in ("date", "time"):
            self.type(format_datetime(low, arg))
        elif low == "delay":
            self.sleep_ms(arg or 250)
        elif low == "pause":
            try:
                time.sleep(max(0.0, float(arg or 1)))
            except ValueError:
                pass
        elif low == "ask":
            answer = self.ui(lambda: ask_text(self.panel.root, arg or "Type your answer:"))
            if answer is None:
                raise Abort()
            self.refocus()
            if answer:
                self.type(answer)
        elif low == "wait":
            self.undoable = False        # whatever the user types or dictates during the pause isn't tracked
            box = self.ui(lambda: WaitBox(self.panel, arg))
            self.refocus()
            box.done.wait()
            if not box.result:
                raise Abort()
            self.target = self.panel.tracker.last or self.target   # they may have clicked into another window
            self.refocus()
        elif low == "dictate":
            self.dictate(arg)
        elif low == "ainote":
            self.ai_note(arg)
        elif low == "group":
            self.ui(lambda: self.panel.select_family(arg))
        elif low == "open":
            self.undoable = False
            # Only allow URL schemes that are safe to hand to the browser/OS handler; a
            # malicious button could otherwise pass javascript: or data: URIs.
            parsed = urllib.parse.urlparse(arg)
            scheme = parsed.scheme.lower()
            if scheme and scheme not in ("http", "https", "mailto", "file"):
                self.ui(lambda: messagebox.showerror(
                    APP, f"Refusing to open a '{scheme}' URL; only http, https, mailto and file are allowed."))
                raise Abort()
            url = arg if scheme else "https://" + arg
            webbrowser.open(url)
        elif low == "run":
            self.undoable = False
            # Never use shell=True: arg is user-configurable button text, so a shell
            # would let a button run arbitrary shell pipelines. Split the command into
            # an argv list and exec it directly with shell=False.
            try:
                parts = shlex.split(arg)
                if parts:
                    subprocess.Popen(parts, shell=False)
            except (OSError, ValueError):
                pass
        elif low == "terminal" and arg:
            self.undoable = False
            problem = open_terminal(arg)
            if problem:
                self.ui(lambda: messagebox.showerror(APP, problem))
                raise Abort()
        elif low in ("paste", "pastefile"):
            self.ensure_ready()          # before the clipboard is borrowed
            content = arg
            if low == "pastefile":
                try:
                    with open(os.path.expanduser(arg), encoding="utf-8", errors="replace") as f:
                        content = f.read()
                except OSError:
                    self.ui(lambda: messagebox.showerror(APP, f"Couldn't open {arg}"))
                    raise Abort()
            if not self.backend.set_clipboard(content):
                self.ui(lambda: self.panel.set_clipboard(content))
            time.sleep(0.15)
            self.backend.press(self.backend.paste_combo)
            self.typed += len(content)
            self.stats["words"] += count_words(content)
            time.sleep(0.1)
        elif low == "clipboard":
            self.ensure_ready()
            content = self.original_clipboard()
            if not content:
                self.ui(lambda: messagebox.showerror(APP, "The clipboard is empty, so there's nothing to paste."))
                raise Abort()
            if self.saved_clip is not None:
                self.put_clip(content)           # Paste mode borrowed the clipboard for this button's own text
                time.sleep(0.08)
            self.backend.press(self.backend.paste_combo)
            self.typed += len(content)
            self.stats["words"] += count_words(content)
            time.sleep(0.1)
        elif low == "activate":
            self.undoable = False
            wid = self.backend.activate_title(arg)
            if wid:
                self.target = wid
                time.sleep(0.15)
        elif low == "mousemove":
            self.undoable = False
            nums = re.findall(r"-?\d+", arg)
            if len(nums) >= 2:
                self.backend.mouse_move(int(nums[0]), int(nums[1]))
        elif low in ("mouseleft", "mouseright", "mousemiddle", "click"):
            self.undoable = False
            self.backend.mouse_click({"mouseright": "right", "mousemiddle": "middle"}.get(low, "left"))
        else:
            return False
        return True

    def dictate(self, message):
        """{Dictate}: listen, then type the words. Where dictation isn't set up on this computer (or the buttons are
        shared with one where it is) it behaves like {Wait}, so the button still works with any other dictation."""
        settings = (getattr(self.panel, "cfg", None) or {}).get("settings", {})
        ready, why = dictation_state(settings)
        if not ready:
            self.undoable = False
            box = self.ui(lambda: WaitBox(self.panel, f"{why} For now, dictate or type as usual, then click Continue."))
            self.refocus()
            box.done.wait()
            if not box.result:
                raise Abort()
            self.target = self.panel.tracker.last or self.target
            self.refocus()
            return
        box = self.ui(lambda: DictateBox(self.panel, message, settings))
        self.refocus()               # the box doesn't take the keyboard, but make sure the note still has it
        box.done.wait()
        if not box.result:
            raise Abort()
        self.refocus()               # clicking Stop made the box active for a moment
        time.sleep(0.1)
        self.type(box.text, counted=False)
        self.stats["dictations"] += 1
        self.stats["dictated_words"] += count_words(box.text)
        self.stats["dictated_seconds"] += box.seconds
        if not settings.get("dictation_review"):
            self.last_heard = (box.heard, box.text, box.changes)


    def ai_note(self, arg):
        """{AINote}: turn the Plaud summary on the clipboard (or, with {AINote dictate}, what you say now) into a
        note written by AI (on this computer unless the person chose their own provider), show it to check and edit,
        then paste it in. Never typed without being checked."""
        panel = self.panel
        settings = panel.cfg["settings"]
        provider = read_ai_provider()
        host = ai_host(provider)
        if host is None:
            ready, why = local_ai_state(provider)
        elif provider["engine"] == "anthropic":
            ready, why = bool(read_claude_key()), ("The AI note needs a Claude key on this computer first. Add one in "
                                                   "Settings > AI note.")
        else:
            ready, _url, why = check_openai_url(provider.get("openai_url"))
            why = f"{why} (Settings > AI note)"
        if not ready:
            self.ui(lambda: messagebox.showinfo(APP, why, parent=panel.root))
            raise Abort()
        if host is not None and not self.ui(lambda: ai_consent_ok(panel, host)):
            raise Abort()
        self.ensure_ready()          # before the note is written, so a refused permission doesn't waste it
        self.undoable = False
        if arg.lower().startswith("dictate"):
            ready, why = dictation_state(settings)
            if not ready:
                self.ui(lambda: messagebox.showinfo(APP, why, parent=panel.root))
                raise Abort()
            talk = dict(settings, dictation_review=False, dictation_max_seconds=max(
                300, int(settings.get("dictation_max_seconds") or 180)))
            box = self.ui(lambda: DictateBox(panel, arg[len("dictate"):].strip() or
                                             "Talk through the consult. Click Stop when you've finished.",
                                             talk, stop_text="Stop and write the note  ▶"))
            box.done.wait()
            if not box.result:
                raise Abort()
            source = box.text
            self.stats["ai_seconds"] += box.seconds      # talking time, taken off the time saved
        else:
            source = self.original_clipboard() or ""
            if not source.strip():
                self.ui(lambda: messagebox.showinfo(APP, "The clipboard is empty. Copy the Plaud summary or "
                                                         "transcript first, then click the button again.",
                                                    parent=panel.root))
                raise Abort()
        note_box = self.ui(lambda: AINoteBox(panel, source, settings))
        note_box.done.wait()
        if not note_box.result:
            raise Abort()
        note = note_box.text
        self.refocus()
        time.sleep(0.1)
        if not self.backend.set_clipboard(note):
            self.ui(lambda: panel.set_clipboard(note))
        time.sleep(0.15)
        self.backend.press(self.backend.paste_combo)
        self.typed += len(note)
        self.stats["ai_notes"] += 1
        self.stats["ai_words"] += count_words(note)
        time.sleep(0.1)


def ai_consent_hosts():
    """The hosts this computer's user agreed to send consult text to. A 3.3 file holds just a date: that agreement
    was to Claude's text, so it counts for Claude only."""
    try:
        with open(AI_CONSENT_PATH, encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return set()
    try:
        data = json.loads(text)
    except ValueError:
        data = None
    if isinstance(data, dict):
        return {h for h in data.get("hosts", []) if isinstance(h, str)}
    return {CLAUDE_HOST}


def ai_consent_given(host=CLAUDE_HOST):
    return host in ai_consent_hosts()


def set_ai_consent(on, host=CLAUDE_HOST):
    """Kept in a file on this computer, never in the buttons file: that can be shared between computers through a
    cloud folder, and each computer's user has to see the disclosure and agree for themselves. Off clears every
    host."""
    if not on:
        _quiet_remove(AI_CONSENT_PATH)
        return
    hosts = sorted(ai_consent_hosts() | {host})
    os.makedirs(os.path.dirname(AI_CONSENT_PATH), exist_ok=True)
    with open(AI_CONSENT_PATH, "w", encoding="utf-8") as f:
        json.dump({"hosts": hosts, "when": time.strftime("%Y-%m-%d %H:%M")}, f)


def ai_consent_ok(panel, host=CLAUDE_HOST):
    """Ask once per computer and host before the first note sent there: consult text leaving the computer."""
    if ai_consent_given(host):
        return True
    if not messagebox.askyesno(APP, ai_consent_text(host), parent=panel.root, icon="warning"):
        return False
    try:
        set_ai_consent(True, host)
    except OSError:
        pass                     # agreed for this time; asked again next time
    return True


def ai_consent_text(host):
    if host == CLAUDE_HOST:
        return AI_CONSENT_TEXT
    return (f"This sends the consult text (the Plaud summary you copied, or what you dictate) over the internet to "
            f"{host}, the AI provider set up in Settings > AI note. Unless that's a server in the clinic, it is "
            "probably processed overseas, under that provider's own terms.\n\n"
            "Only use it if the clinic's privacy policy and patients' consent cover sending notes there. Leave out "
            "names and other identifying details where you can. Writing notes on this computer instead keeps "
            "everything here.\n\n"
            "The note is always shown to you to check before it goes into the record.\n\n"
            f"Send AI notes to {host} from this computer?")


AI_CONSENT_TEXT = (
    "The AI note sends the consult text (the Plaud summary you copied, or what you dictate) over the internet to "
    "Anthropic's Claude, which processes it overseas. Anthropic doesn't use it to train its AI, and keeps it only for "
    "a limited time for safety checks.\n\n"
    "Only use it if the clinic's privacy policy and patients' consent cover sending notes to an overseas service "
    "(the same as for Plaud). Leave out names and other identifying details where you can.\n\n"
    "The note is always shown to you to check before it goes into the record.\n\n"
    "Turn on AI notes for this computer?")


class AINoteBox(tk.Toplevel):
    """Writes the note with Claude on a background thread, then shows it to check and edit. `done` is set at the end;
    `result` True means paste `text`."""

    def __init__(self, panel, source, settings):
        super().__init__(panel.root)
        self.panel, self.source, self.settings = panel, source, settings
        self.done, self.result, self.text = threading.Event(), False, ""
        self.title(f"{APP} — AI note")
        self.attributes("-topmost", True)
        self.configure(bg=APP_BG)
        self.minsize(420, 260)
        self.status = tk.Label(self, text="", anchor="w", justify="left", wraplength=460, bg=APP_BG, fg=MUTED,
                               padx=14, pady=10, font=("TkDefaultFont", 11))
        self.status.pack(fill="x")
        self.bar = ttk.Progressbar(self, mode="indeterminate", length=440)
        self.edit = tk.Text(self, width=60, height=16, wrap="word", font=("TkDefaultFont", 11), undo=True)
        row = ttk.Frame(self, padding=(14, 6, 14, 12))
        row.pack(side="bottom", fill="x")
        self.go = ttk.Button(row, text="Paste it in  ▶", style="Big.TButton", command=self.accept)
        self.go.pack(side="left", fill="x", expand=True)
        self.again = ttk.Button(row, text="Write it again", command=self.start)
        self.again.pack(side="left", padx=(8, 0))
        ttk.Button(row, text="Cancel", command=self.cancel).pack(side="left", padx=(8, 0))
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Control-Return>", lambda e: self.go.invoke())
        self.update_idletasks()
        self.geometry(place_beside(self, panel.root))
        self.start()

    def start(self):
        self.edit.pack_forget()
        self.bar.pack(fill="x", padx=14, pady=(0, 8))
        self.bar.start(15)
        self.go.state(["disabled"])
        self.again.state(["disabled"])
        host = ai_host(read_ai_provider())
        self.waiting = ("Writing the note on this computer (nothing leaves it). This can take a minute…"
                        if host is None else f"Sending this text to {host}, over the internet, to write the note…")
        self.writing, self.started = True, time.monotonic()
        self.tick()
        settings, source = dict(self.settings), self.source

        def work():
            try:
                note = ai_write_note(source, settings)
                self.panel.post(lambda: self.show(note))
            except AIError as e:
                msg = str(e)
                self.panel.post(lambda: self.fail(msg))
            except Exception as e:  # noqa: BLE001
                log.exception("AI note failed")
                msg = f"Something went wrong: {e}"
                self.panel.post(lambda: self.fail(msg))
        threading.Thread(target=work, daemon=True).start()

    def alive(self):
        return not self.done.is_set() and self.winfo_exists()

    def tick(self):
        """Count the seconds while it writes: on this computer a note can take a minute or more."""
        if not self.writing or not self.alive():
            return
        seconds = int(time.monotonic() - self.started)
        self.status.config(text=self.waiting + (f"  {seconds} s" if seconds else ""), fg=MUTED)
        self.after(1000, self.tick)

    def show(self, note):
        self.writing = False
        if not self.alive():
            return
        self.bar.stop()
        self.bar.pack_forget()
        self.status.config(text="Check the note against what happened, and change anything that's wrong or missing. "
                                "Then click Paste it in.", fg=INK)
        self.edit.delete("1.0", "end")
        self.edit.insert("1.0", note)
        for tag, colour in (("flag", "#ffd6d6"), ("check", "#fff1b8")):
            self.edit.tag_configure(tag, background=colour)
        for line_no, line in enumerate(note.splitlines(), 1):
            if line.startswith(("FLAG:", "CHECK:")):
                self.edit.tag_add("flag" if line.startswith("FLAG") else "check", f"{line_no}.0", f"{line_no}.end")
        self.edit.pack(fill="both", expand=True, padx=14, pady=(0, 4))
        self.update_idletasks()
        self.geometry(place_beside(self, self.panel.root))     # it grew: keep it all on the screen
        self.go.state(["!disabled"])
        self.again.state(["!disabled"])
        self.lift()
        self.focus_force()
        self.edit.focus_set()

    def fail(self, message):
        self.writing = False
        if not self.alive():
            return
        self.bar.stop()
        self.bar.pack_forget()
        self.status.config(text=message, fg="#b3261e")
        self.again.state(["!disabled"])

    def accept(self):
        text = self.edit.get("1.0", "end-1c").strip()
        if text:
            self.finish(True, text)

    def cancel(self):
        self.finish(False)

    def finish(self, ok, text=""):
        if self.done.is_set():
            return
        self.result, self.text = ok, text
        self.done.set()
        try:
            self.destroy()
        except tk.TclError:
            pass


def split_list(arg):
    """{List …} items read the 3.2 way (split on every comma, everything trimmed), and the TypeItIn-style title if
    the first item is "Title: …". Returns (title, choices). Buttons now use parse_choice, which keeps {…} inside a
    choice together; this stays for anything that still calls it."""
    items = [c.strip() for c in arg.split(",")]
    title = ""
    if items and items[0].lower().startswith("title:"):
        title = items.pop(0)[6:].strip()
    # TypeItIn's Pos:Screen / Pos:Window / Pos:x|y place its list window; they aren't choices.
    return title, [c for c in items if c and not c.lower().startswith("pos:")]


def _chooser_window(root, title):
    win = tk.Toplevel(root)
    win.title(f"{APP} — Choose")
    win.attributes("-topmost", True)
    win.configure(bg=APP_BG)
    ttk.Label(win, text=tk_safe(title) or "Choose one to type:", padding=(10, 8, 10, 4),
              font=("TkDefaultFont", 11, "bold") if title else None).pack(anchor="w")
    return win


def _show_chooser(root, win, focus):
    """Put a chooser by the mouse pointer, in front, with the keyboard, and wait for it to close."""
    win.update_idletasks()
    x, y = win.winfo_pointerxy()
    win.geometry(f"+{max(0, x - 40)}+{max(0, y - 20)}")
    win.deiconify()
    win.lift()
    win.focus_force()
    focus.focus_set()
    try:
        win.grab_set()
    except tk.TclError:
        pass
    root.wait_window(win)


def choose_from_list(root, choices, title=""):
    """Modal chooser for {List …}, {Choose …} and {List:Name}. Returns the chosen string (one of `choices`), or None
    if cancelled. Long choices show on one line (⏎ = Enter). Keys: ↑ ↓ and Enter, 1–9 pick straight away, typing
    letters narrows the list down, Esc cancels. The first choice starts selected."""
    if not choices:
        return None
    win = _chooser_window(root, title)
    result = {"v": None}
    typed = tk.StringVar()
    find = ttk.Entry(win, textvariable=typed, font=("TkDefaultFont", 11))
    find.pack(fill="x", padx=10, pady=(0, 4))
    hint = ttk.Label(win, text="Type to narrow the list, or press 1–9", foreground=MUTED, padding=(10, 0))
    hint.pack(anchor="w")
    lb = tk.Listbox(win, height=min(len(choices), 12), width=min(90, max(24, *(len(choice_display(c)) for c in choices))),
                    activestyle="dotbox", exportselection=False, font=("TkDefaultFont", 11))
    lb.pack(fill="both", expand=True, padx=10, pady=(4, 0))
    shown = []                                   # indexes into choices, in the order they're listed now

    def refill(*_):
        words = typed.get().strip().lower()
        shown[:] = [i for i, c in enumerate(choices) if not words or words in c.lower()
                    or words in choice_display(c).lower()]
        lb.delete(0, "end")
        for n, i in enumerate(shown):
            lb.insert("end", tk_safe((f"{n + 1}.  " if n < 9 else "     ") + choice_display(choices[i])))
        if shown:
            lb.selection_set(0)
            lb.activate(0)
    typed.trace_add("write", refill)
    refill()

    def pick(_=None):
        sel = lb.curselection()
        if sel and sel[0] < len(shown):
            result["v"] = choices[shown[sel[0]]]
            win.destroy()
        return "break"

    def step(d):
        if not shown:
            return "break"
        sel = lb.curselection()
        i = max(0, min(len(shown) - 1, (sel[0] if sel else 0) + d))
        lb.selection_clear(0, "end")
        lb.selection_set(i)
        lb.activate(i)
        lb.see(i)
        return "break"

    def key(e):
        if e.char and e.char in "123456789" and int(e.char) <= len(shown):
            lb.selection_clear(0, "end")
            lb.selection_set(int(e.char) - 1)
            return pick()
        return None
    btns = ttk.Frame(win, padding=10)
    btns.pack(fill="x")
    ttk.Button(btns, text="Type it", command=pick).pack(side="right")
    ttk.Button(btns, text="Cancel", command=win.destroy).pack(side="right", padx=6)
    lb.bind("<Double-Button-1>", pick)
    for w in (find, lb):
        w.bind("<Key>", key)
        w.bind("<Up>", lambda e: step(-1))
        w.bind("<Down>", lambda e: step(1))
        w.bind("<Return>", pick)
        w.bind("<KP_Enter>", pick)
    win.bind("<Escape>", lambda e: win.destroy())
    _show_chooser(root, win, find)
    return result["v"]


def choose_many(root, choices, title=""):
    """Tick-box chooser for {MultiChoose …} and {MultiList:Name}. Returns the indexes ticked, in list order ([] if
    none were ticked and OK was pressed), or None if cancelled. 1–9 tick or untick a choice; Enter = OK."""
    if not choices:
        return None
    win = _chooser_window(root, title or "Tick the ones to type:")
    result = {"v": None}
    frame = ttk.Frame(win, padding=(10, 0))
    frame.pack(fill="both", expand=True)
    ticks = []
    for n, c in enumerate(choices):
        v = tk.BooleanVar(value=False)
        ticks.append(v)
        ttk.Checkbutton(frame, text=tk_safe((f"{n + 1}.  " if n < 9 else "     ") + choice_display(c)),
                        variable=v).pack(anchor="w", pady=1)

    def ok(_=None):
        result["v"] = [i for i, v in enumerate(ticks) if v.get()]
        win.destroy()
        return "break"

    def key(e):
        if e.char and e.char in "123456789" and int(e.char) <= len(ticks):
            v = ticks[int(e.char) - 1]
            v.set(not v.get())
            return "break"
        return None
    btns = ttk.Frame(win, padding=10)
    btns.pack(fill="x")
    go = ttk.Button(btns, text="Type these", command=ok)
    go.pack(side="right")
    ttk.Button(btns, text="Cancel", command=win.destroy).pack(side="right", padx=6)
    ttk.Label(btns, text="1–9 tick,  Enter = type,  Esc = cancel", foreground=MUTED).pack(side="left")
    win.bind("<Key>", key)
    win.bind("<Return>", ok)
    win.bind("<KP_Enter>", ok)
    win.bind("<Escape>", lambda e: win.destroy())
    _show_chooser(root, win, go)
    return result["v"]


def ask_text(root, prompt, default=""):
    """Modal question for {Ask …}. Returns what was typed (may be empty), or None if cancelled."""
    win = tk.Toplevel(root)
    win.title(f"{APP} — Question")
    win.attributes("-topmost", True)
    result = {"v": None}
    ttk.Label(win, text=tk_safe(prompt), padding=(12, 10, 12, 4), wraplength=420, justify="left",
              font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
    var = tk.StringVar(value=default)
    entry = ttk.Entry(win, textvariable=var, width=52, font=("TkDefaultFont", 12))
    entry.pack(fill="x", padx=12, pady=(0, 4))

    def ok(_=None):
        result["v"] = var.get()
        win.destroy()
    btns = ttk.Frame(win, padding=12)
    btns.pack(fill="x")
    ttk.Button(btns, text="Type it", command=ok).pack(side="right")
    ttk.Button(btns, text="Cancel", command=win.destroy).pack(side="right", padx=6)
    ttk.Label(btns, text="Enter = type it,  Esc = cancel", foreground=MUTED).pack(side="left")
    entry.bind("<Return>", ok)
    win.bind("<Escape>", lambda e: win.destroy())
    win.update_idletasks()
    x, y = win.winfo_pointerxy()
    win.geometry(f"+{max(0, x - 60)}+{max(0, y - 40)}")
    win.deiconify()
    win.lift()
    win.focus_force()
    entry.focus_set()
    try:
        win.grab_set()
    except tk.TclError:
        pass
    root.wait_window(win)
    return result["v"]


def place_beside(win, root):
    """Next to the panel, on whichever side has room, so a little window doesn't sit on what is being typed into."""
    w, h = win.winfo_reqwidth(), win.winfo_reqheight()
    sw, sh_ = win.winfo_screenwidth(), win.winfo_screenheight()
    rx, ry, rw = root.winfo_rootx(), root.winfo_rooty(), root.winfo_width()
    x = rx + rw + 10 if rx + rw + 10 + w <= sw else max(0, rx - w - 10)
    return f"+{x}+{max(0, min(ry + 60, sh_ - h - 40))}"


class WaitBox(tk.Toplevel):
    """The little floating "Continue" window for {Wait}. It does not grab the keyboard, so dictation keeps going
    into the other program. `done` is set (and `result` says Continue vs Cancel) when the user answers."""

    def __init__(self, panel, message=""):
        super().__init__(panel.root)
        self.done, self.result = threading.Event(), False
        self.title(f"{APP} — waiting for you")
        self.attributes("-topmost", True)
        self.configure(bg=APP_BG)
        self.resizable(False, False)
        ttk.Label(self, text=tk_safe(message or "Type or dictate now. Click Continue when you're finished."),
                  wraplength=300, justify="left", padding=(14, 12, 14, 6), font=("TkDefaultFont", 11)).pack(anchor="w")
        row = ttk.Frame(self, padding=(14, 4, 14, 12))
        row.pack(fill="x")
        self.go = ttk.Button(row, text="Continue  ▶", style="Big.TButton", command=lambda: self.finish(True))
        self.go.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Cancel", command=lambda: self.finish(False)).pack(side="left", padx=(8, 0))
        self.protocol("WM_DELETE_WINDOW", lambda: self.finish(False))
        self.update_idletasks()
        self.geometry(place_beside(self, panel.root))

    def finish(self, ok):
        if self.done.is_set():
            return
        self.result = ok
        self.done.set()
        try:
            self.destroy()
        except tk.TclError:
            pass


# ================================================================ dictation
# {Dictate}: Quickpad listens and types what was said, worked out on this computer (nothing is sent anywhere, and the
# recording is never written to disk). The speech engine is whisper.cpp through the pywhispercpp package. It lives in
# its own Python environment in the per-computer folder, so Quickpad itself still needs nothing beyond standard Python
# and updates of quickpad.py never touch it. Each dictation runs in a separate worker process (the script below) that
# records, transcribes and reports back as JSON lines, so a crash in the engine can't take the panel down with it.

DICTATION_DIR = os.path.join(LOCAL_DIR, "dictation")
DICTATION_ENV = os.path.join(DICTATION_DIR, "env")
DICTATION_MODELS = os.path.join(DICTATION_DIR, "models")
DICTATION_MARKER = os.path.join(DICTATION_ENV, "quickpad-ready.json")
DICTATION_WORKER = os.path.join(DICTATION_DIR, "worker.py")
DICTATION_LOG = os.path.join(DICTATION_DIR, "dictation.log")
DICTATION_OFFERED_PATH = os.path.join(LOCAL_DIR, "dictation-offered.txt")   # asked once whether to set it up
# Tried together on clinical phrases (2026-09-27, macOS arm64 and Ubuntu 24.04). Pinned, so what a clinic laptop installs
# can't change underneath him before it has been tried.
DICTATION_PACKAGES = ["pywhispercpp==1.5.1", "sounddevice==0.5.6", "numpy"]
MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-{}.bin"
MIN_CLIP_SECONDS = 0.6    # shorter than this, whisper invents a word ("you") rather than returning nothing
SILENT_PEAK = 0.002       # loudest sample below this = the microphone is muted or unplugged, not someone talking quietly

# Measured on a 29 s clinical dictation: `cpu` = seconds on 4 CPU threads with no graphics chip (the Linux/Windows
# case), `apple` = seconds on an Apple M1, which uses its graphics chip. Every model got sacroiliac, myofascial and
# levator scapulae right once given the clinical word list; tiny garbled them without it.
WHISPER_MODELS = [
    {"key": "tiny.en-q5_1", "name": "Tiny", "bytes": 32166155, "cpu": 3.1, "apple": 0.3, "accuracy": "Fair",
     "sha256": "c77c5766f1cef09b6b7d47f21b546cbddd4157886b3b5d6d4f709e91e66c7c2b",
     "note": "The quickest, but more likely to mishear clinical words. Only worth it on a very slow computer."},
    {"key": "base.en-q5_1", "name": "Base", "bytes": 59721011, "cpu": 4.0, "apple": 0.5, "accuracy": "Good",
     "sha256": "4baf70dd0d7c4247ba2b81fafd9c01005ac77c2f9ef064e00dcf195d0e2fdd2f",
     "note": "Quick, and gets most clinical words right. The best fit for most laptops."},
    {"key": "small.en-q5_1", "name": "Small", "bytes": 190098681, "cpu": 9.9, "apple": 1.4, "accuracy": "Very good",
     "sha256": "bfdff4894dcb76bbf647d56263ea2a96645423f1669176f4844a1bf8e478ad30",
     "note": "Better with rare terms and long sentences. About two and a half times slower than Base."},
    {"key": "medium.en-q5_0", "name": "Medium", "bytes": 539225533, "cpu": 25.8, "apple": 2.4, "accuracy": "Excellent",
     "sha256": "76733e26ad8fe1c7a5bf7531a9d41917b2adc0f20f2e4f5531688a8c6cd88eb0",
     "note": "Very accurate, but only quick on a Mac with an M chip. Slow on other computers."},
    {"key": "large-v3-turbo-q5_0", "name": "Large (turbo)", "bytes": 574041195, "cpu": 38.6, "apple": 2.4,
     "accuracy": "Best", "sha256": "394221709cd5ad1f40c46e6031ca61bce88931e6e088c188294c6d5a55ffa7e2",
     "note": "The most accurate. Quick on a Mac with an M chip; far too slow for other computers."},
]


def model_info(key):
    return next((m for m in WHISPER_MODELS if m["key"] == key), None)


def model_path(key):
    return os.path.join(DICTATION_MODELS, f"ggml-{key}.bin")


def model_downloaded(key):
    m = model_info(key)
    try:
        return bool(m) and os.path.getsize(model_path(key)) == m["bytes"]
    except OSError:
        return False


_machine = {}


def machine_info():
    """What this computer has, for suggesting a model: {ram_gb, cores, arch, system, cpu}. Standard library only;
    anything that can't be read is left as None / "" rather than guessed."""
    if _machine:
        return dict(_machine)
    info = {"ram_gb": None, "cores": os.cpu_count() or 1, "arch": platform.machine().lower(), "system": sys.platform,
            "cpu": ""}
    try:
        if sys.platform.startswith("linux"):
            with open("/proc/meminfo", encoding="utf-8") as f:
                kb = next((int(line.split()[1]) for line in f if line.startswith("MemTotal:")), 0)
            info["ram_gb"] = round(kb / 1024 ** 2, 1) or None
            with open("/proc/cpuinfo", encoding="utf-8", errors="replace") as f:
                info["cpu"] = next((line.split(":", 1)[1].strip() for line in f if line.startswith("model name")), "")
        elif IS_MAC:
            mem = sh(["sysctl", "-n", "hw.memsize"])
            info["ram_gb"] = round(int(mem) / 1024 ** 3, 1) if mem.isdigit() else None
            info["cpu"] = sh(["sysctl", "-n", "machdep.cpu.brand_string"])
        elif sys.platform.startswith("win"):
            class MemoryStatus(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            ms = MemoryStatus()
            ms.dwLength = ctypes.sizeof(ms)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms)):
                info["ram_gb"] = round(ms.ullTotalPhys / 1024 ** 3, 1)
            info["cpu"] = platform.processor()
    except (OSError, ValueError, AttributeError, StopIteration):
        pass
    _machine.update(info)
    return dict(info)


def apple_chip(info):
    return info.get("system") == "darwin" and info.get("arch") in ("arm64", "aarch64")


def suggest_model(info):
    """(model key, reason) for this computer. Linux and Windows laptops work it out on the processor alone, where
    each step up costs about two and a half times the wait, so they stay on Base unless the machine is clearly
    strong. Macs with an M chip use their graphics chip and can run the big models quickly."""
    ram = info.get("ram_gb") or 4
    cores = info.get("cores") or 2
    if apple_chip(info):
        if ram >= 16:
            return "large-v3-turbo-q5_0", "a Mac with an M chip and 16 GB or more runs the most accurate model in a few seconds"
        if ram >= 8:
            return "small.en-q5_1", "a Mac with an M chip handles the Small model quickly"
        return "base.en-q5_1", "it is quick on a Mac with less memory"
    if ram >= 16 and cores >= 8:
        return "small.en-q5_1", "this computer has plenty of memory and processor power for the more accurate Small model"
    if ram < 2:
        return "tiny.en-q5_1", "this computer has very little memory"
    return "base.en-q5_1", "it is the smallest model that reliably gets clinical words right, and quick on a laptop"


def dictation_threads(info=None):
    n = (info or machine_info()).get("cores") or 2
    return max(1, min(8, n - 1 if n > 4 else n))       # leave a core free so the rest of the computer stays responsive


def estimate_wait(m, info):
    """Rough seconds to work out 30 s of speech on this computer, for the model list."""
    if apple_chip(info):
        return m["apple"]
    # Measured on 4 fast threads; an ordinary laptop core is slower, and fewer threads is slower again.
    return m["cpu"] * 1.5 * (4 / max(1, dictation_threads(info))) ** 0.7


def describe_wait(seconds):
    return "under a second" if seconds < 1 else f"about {round(seconds)} s" if seconds < 90 else f"about {round(seconds / 60)} min"


def describe_machine(info):
    bits = [f"{info['ram_gb']:g} GB memory" if info.get("ram_gb") else "memory unknown",
            f"{info.get('cores') or '?'} processor threads"]
    chip = "Apple M chip" if apple_chip(info) else (info.get("cpu") or info.get("arch") or "")
    return "This computer: " + ", ".join(bits) + (f" ({' '.join(chip.split())})" if chip else "") + "."


def chosen_model(settings):
    key = (settings or {}).get("dictation_model") or ""
    return key if model_info(key) else suggest_model(machine_info())[0]


# Whisper marks non-speech as [BLANK_AUDIO], [ Silence ], (music), *coughs* and so on. None of that belongs in a note.
_NOT_SPEECH = re.compile(r"\[[^\]]*\]|\((?:[^)]*\b(?:music|silence|blank|inaudible|noise|laugh\w*|cough\w*|applause|"
                         r"static|beep\w*|breath\w*|sigh\w*)\b[^)]*)\)|\*[^*\n]*\*", re.I)


def clean_transcript(text):
    """Whisper's words, minus sound labels and stray whitespace. '' if nothing real was said."""
    text = re.sub(r"\s+", " ", _NOT_SPEECH.sub(" ", text or "")).strip()
    return "" if re.fullmatch(r"[\s.,!?…-]*", text) else text


# ---- custom vocabulary: "when it hears X, write Y". Kept in the shared buttons file so it follows the user between PCs.
def clean_fixes(raw):
    """[{"heard", "write"}] with blanks, duplicates of `heard` and oversize entries dropped. Accepts [heard, write]
    pairs too (hand-edited files)."""
    out, seen = [], set()
    for item in raw if isinstance(raw, list) else []:
        if isinstance(item, dict):
            heard, write = item.get("heard", ""), item.get("write", "")
        elif isinstance(item, (list, tuple)) and len(item) == 2:
            heard, write = item
        else:
            continue
        heard, write = " ".join(str(heard).split())[:80], " ".join(str(write).split())[:120]
        if heard and heard.lower() not in seen:
            seen.add(heard.lower())
            out.append({"heard": heard, "write": write})
    return out[:500]


def _match_case(found, write):
    """Keep a capital the speech model gave (start of a sentence) unless the correction has its own capitals."""
    if write and found[:1].isupper() and write[:1].islower() and write == write.lower():
        return write[0].upper() + write[1:]
    return write


def apply_corrections(text, fixes):
    """(corrected text, [(heard, written), ...]). Whole words or phrases only, any capitalisation, longest phrase first,
    so "arm" never touches "harm" or "armchair" and "left arm" beats "arm"."""
    fixes = clean_fixes(fixes)
    if not text or not fixes:
        return text, []
    by_key = {f["heard"].lower(): f["write"] for f in fixes}
    parts = sorted(by_key, key=len, reverse=True)
    pattern = re.compile(r"(?<!\w)(" + "|".join(r"\s+".join(map(re.escape, p.split())) for p in parts) + r")(?!\w)",
                         re.I)
    changes = []

    def swap(m):
        found = m.group(0)
        write = _match_case(found, by_key[" ".join(found.split()).lower()])
        changes.append((found, write))
        return write
    out = pattern.sub(swap, text)
    return re.sub(r"  +", " ", out).strip() if changes else text, changes


def listening_prompt(settings):
    """The context handed to the speech model: the "words to expect" plus every word a correction writes, so the
    model is nudged towards them in the first place."""
    s = settings or {}
    words = (s.get("dictation_words") or "").strip()
    extra = []
    for f in clean_fixes(s.get("dictation_fixes")):
        w = f["write"]
        if w and w.lower() not in words.lower() and w.lower() not in (e.lower() for e in extra):
            extra.append(w)
    if extra:
        words = (words.rstrip(".") + ", " if words else "Terms: ") + ", ".join(extra) + "."
    return words[:1000]


def level_percent(rms):
    """Microphone loudness (RMS, 0–1) as 0–100 on a decibel scale: -60 dB (a quiet room) to -10 dB (loud speech)."""
    import math
    if not rms or rms <= 0:
        return 0
    return int(max(0, min(100, (20 * math.log10(rms) + 60) * 2)))


def _no_window():
    """subprocess options so a helper started from pythonw on Windows doesn't flash a black console window."""
    return {"creationflags": 0x08000000} if sys.platform.startswith("win") else {}


def dictation_python():
    return os.path.join(DICTATION_ENV, "Scripts", "python.exe") if sys.platform.startswith("win") \
        else os.path.join(DICTATION_ENV, "bin", "python")


def find_system_python():
    """A real, usable Python 3 interpreter on this computer - not sys.executable, which in a frozen build is the
    Quickpad binary itself, not a general-purpose interpreter. Checked in rough order of how likely each is to
    actually work (a Homebrew/python.org install over whatever a bare `python3` on PATH happens to resolve to).
    Returns '' if none of them exist."""
    candidates = []
    if sys.platform.startswith("win"):
        candidates += [shutil.which("python"), shutil.which("python3")]
        launcher = shutil.which("py")
        if launcher:
            try:
                r = subprocess.run([launcher, "-3", "-c", "import sys; print(sys.executable)"],
                                   capture_output=True, text=True, timeout=10, **_no_window())
                if r.returncode == 0 and r.stdout.strip():
                    candidates.append(r.stdout.strip())
            except (OSError, subprocess.TimeoutExpired):
                pass
    elif IS_MAC:
        candidates += ["/opt/homebrew/bin/python3", "/usr/local/bin/python3",
                       "/Library/Frameworks/Python.framework/Versions/Current/bin/python3",
                       shutil.which("python3"), "/usr/bin/python3"]
    else:
        candidates += [shutil.which("python3"), "/usr/bin/python3"]
    for c in candidates:
        if c and c != sys.executable and os.path.exists(c):
            return c
    return ""


def base_python():
    """The Python to build the dictation environment from: normally the one running Quickpad (python.exe, not
    pythonw.exe, on Windows, so pip's messages can be read) - except in a frozen build, where sys.executable IS
    the Quickpad binary, not a real interpreter, so a system Python has to be found some other way. '' if none can
    be found (a frozen build with no Python installed anywhere)."""
    if getattr(sys, "frozen", False):
        return find_system_python()
    exe = sys.executable
    if sys.platform.startswith("win") and os.path.basename(exe).lower() == "pythonw.exe":
        console = os.path.join(os.path.dirname(exe), "python.exe")
        exe = console if os.path.exists(console) else exe
    return exe


def engine_status():
    """(installed, detail). Reads the marker written by a successful setup; cheap enough to call before every
    dictation. A Python upgrade on the computer breaks the environment, so the version it was built on is checked."""
    try:
        with open(DICTATION_MARKER, encoding="utf-8") as f:
            marker = json.load(f)
    except (OSError, ValueError):
        return False, "Dictation isn't set up on this computer yet."
    if not os.path.exists(dictation_python()):
        return False, "Dictation needs setting up again (its files are missing)."
    if marker.get("python") != platform.python_version().rsplit(".", 1)[0]:
        return False, "This computer's Python was updated, so dictation needs setting up again."
    return True, marker.get("recorder") or ""


def dictation_state(settings):
    """(ready, reason). Ready = engine installed and the chosen model downloaded."""
    ok, detail = engine_status()
    if not ok:
        return False, detail
    key = chosen_model(settings)
    if not model_downloaded(key):
        return False, f"The {model_info(key)['name']} speech model isn't downloaded on this computer yet."
    return True, ""


class DictationError(Exception):
    """Something the person can act on, in plain words."""


class Cancelled(Exception):
    pass


def _download_ssl():
    """The system's trusted certificates, plus certifi's from the dictation environment when it has them. Python from
    python.org on a Mac has no certificates until its "Install Certificates" step is run, and every download there
    failed with CERTIFICATE_VERIFY_FAILED without this. (certifi comes with the engine, as a dependency of it.)"""
    import ssl
    ctx = ssl.create_default_context()
    for bundle in glob.glob(os.path.join(DICTATION_ENV, "**", "certifi", "cacert.pem"), recursive=True)[:1]:
        try:
            ctx.load_verify_locations(bundle)
        except (OSError, ssl.SSLError):
            pass
    return ctx


def download_model(key, progress=None, cancelled=None):
    """Fetch one model into DICTATION_MODELS and check it against its known SHA-256 before keeping it, so a damaged or
    substituted file is never used. progress(done, total) is called from this (background) thread."""
    m = model_info(key)
    if not m:
        raise DictationError(f"Unknown model {key!r}.")
    if model_downloaded(key):
        return model_path(key)
    os.makedirs(DICTATION_MODELS, exist_ok=True)
    part = model_path(key) + ".part"
    digest, done = hashlib.sha256(), 0
    req = urllib.request.Request(MODEL_URL.format(key), headers={"User-Agent": f"{APP}/{VERSION}"})
    try:
        # Hugging Face redirects to its download servers; the SHA-256 check below is what makes that safe.
        with urllib.request.urlopen(req, timeout=30, context=_download_ssl()) as r, open(part, "wb") as out:
            while True:
                if cancelled and cancelled():
                    raise Cancelled()
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                if progress:
                    progress(done, m["bytes"])
    except Cancelled:
        _quiet_remove(part)
        raise
    except (urllib.error.URLError, OSError) as e:
        _quiet_remove(part)
        raise DictationError(f"Couldn't download the {m['name']} model. Check the internet connection and try again. ({e})")
    if done != m["bytes"] or digest.hexdigest() != m["sha256"]:
        _quiet_remove(part)
        raise DictationError(f"The {m['name']} model didn't download correctly (it doesn't match the known file), "
                             "so it wasn't kept. Try again.")
    os.replace(part, model_path(key))
    return model_path(key)


def write_worker():
    """Put the worker script where the dictation environment can run it (only rewritten when it has changed)."""
    os.makedirs(DICTATION_DIR, exist_ok=True)
    try:
        with open(DICTATION_WORKER, encoding="utf-8") as f:
            if f.read() == DICTATION_WORKER_SOURCE:
                return DICTATION_WORKER
    except OSError:
        pass
    tmp = DICTATION_WORKER + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(DICTATION_WORKER_SOURCE)
    os.replace(tmp, DICTATION_WORKER)
    return DICTATION_WORKER


def _open_dictation_log():
    os.makedirs(DICTATION_DIR, exist_ok=True)
    try:
        if os.path.getsize(DICTATION_LOG) > 1_000_000:
            os.replace(DICTATION_LOG, DICTATION_LOG + ".old")
    except OSError:
        pass
    return open(DICTATION_LOG, "a", encoding="utf-8", errors="replace")


def setup_dictation(model_key, say=print, progress=None, cancelled=None):
    """Build the dictation environment, install the engine into it, check it, then download the model. Takes a few
    minutes the first time. say(line) gets plain-English progress. Raises DictationError with what to do next."""
    def run(cmd, what, timeout=900):
        with _open_dictation_log() as logf:
            logf.write(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} $ {' '.join(cmd)}\n")
            logf.flush()
            try:
                r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                   errors="replace", timeout=timeout, **_no_window())
            except subprocess.TimeoutExpired:
                raise DictationError(f"{what} took too long and was stopped. Check the internet connection and try again.")
            except OSError as e:
                raise DictationError(f"{what} couldn't start: {e}")
            logf.write(r.stdout)
        if cancelled and cancelled():
            raise Cancelled()
        return r

    py = base_python()
    if not py:
        raise DictationError("Dictation needs Python 3 installed on this computer. Get it free from python.org, "
                              "then click Set up again.")
    os.makedirs(DICTATION_DIR, exist_ok=True)
    _quiet_remove(DICTATION_MARKER)
    say("Making a private space for the dictation engine…")
    r = run([py, "-m", "venv", "--clear", DICTATION_ENV], "Making the dictation space", timeout=300)
    if r.returncode != 0 or not os.path.exists(dictation_python()):
        if "ensurepip" in r.stdout or "venv" in r.stdout:
            hint = ("Linux needs one extra package first. Open a terminal, run\n  sudo apt install python3-venv\n"
                    "then click Set up again.") if sys.platform.startswith("linux") else "Reinstall Python, then try again."
            raise DictationError("Python on this computer can't make the private space dictation needs. " + hint)
        raise DictationError(f"Couldn't make the dictation space (see {DICTATION_LOG}).")
    say("Downloading and installing the speech engine (about 40 MB)…")
    r = run([dictation_python(), "-m", "pip", "install", "--disable-pip-version-check", "--no-input",
             "--prefer-binary", *DICTATION_PACKAGES], "Installing the speech engine")
    if r.returncode != 0:
        lines = [x for x in r.stdout.splitlines() if x.strip()]
        why = next((x for x in reversed(lines) if x.startswith("ERROR")), lines[-1] if lines else "")
        if "cmake" in r.stdout.lower() or "compiler" in r.stdout.lower():
            why = ("there's no ready-made engine for this computer, and building one needs developer tools "
                   "(Xcode Command Line Tools and cmake on a Mac)")
        raise DictationError(f"Couldn't install the speech engine: {why}\n\nThe full details are in {DICTATION_LOG}.")
    say("Checking the engine works…")
    write_worker()
    r = run([dictation_python(), DICTATION_WORKER, "check"], "Checking the engine", timeout=120)
    event = _last_event(r.stdout)
    if event.get("event") != "check":
        raise DictationError("The speech engine installed but won't start: " + (event.get("message") or
                             f"see {DICTATION_LOG}"))
    recorder = event.get("recorder") or ""
    if not recorder:
        say("Note: no way to use the microphone was found. " + (event.get("note") or ""))
    with open(DICTATION_MARKER, "w", encoding="utf-8") as f:
        json.dump({"python": platform.python_version().rsplit(".", 1)[0], "packages": DICTATION_PACKAGES,
                   "recorder": recorder, "when": time.strftime("%Y-%m-%d %H:%M")}, f)
    m = model_info(model_key)
    if model_downloaded(model_key):
        say(f"The {m['name']} speech model is already here.")
    else:
        say(f"Downloading the {m['name']} speech model ({m['bytes'] // 1_000_000} MB)…")
        download_model(model_key, progress, cancelled)
    say("Dictation is ready." + ("" if recorder else " It can't hear anything until a microphone works, though."))
    return recorder


def _last_event(output):
    for line in reversed((output or "").splitlines()):
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if isinstance(ev, dict):
            return ev
    return {}


class DictationWorker:
    """One run of the worker process. Its JSON events are handed to on_event(dict) on the Tk thread via panel.post.
    Always ends with exactly one of result / error / cancelled."""

    def __init__(self, panel, mode, on_event, settings, extra=()):
        self.panel, self.on_event, self.ended = panel, on_event, False
        s = settings or {}
        try:
            seconds = max(10, min(600, int(s.get("dictation_max_seconds", 180))))
        except (TypeError, ValueError):
            seconds = 180
        cmd = [dictation_python(), write_worker(), mode, "--model", model_path(chosen_model(s)),
               "--threads", str(dictation_threads()), "--prompt", listening_prompt({"dictation_words": DEFAULT_DICTATION_WORDS, **s}),
               "--device", s.get("dictation_device", "") or "", "--max-seconds", str(seconds),
               "--min-seconds", str(MIN_CLIP_SECONDS), "--silent-peak", str(SILENT_PEAK), *extra]
        self.logf = _open_dictation_log()
        self.logf.write(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} worker {mode} ({chosen_model(s)})\n")
        self.logf.flush()
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.logf,
                                         text=True, encoding="utf-8", errors="replace", bufsize=1, **_no_window())
        except OSError:
            self.logf.close()
            raise
        threading.Thread(target=self.read, daemon=True).start()

    def read(self):
        for line in self.proc.stdout:
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            if isinstance(ev, dict):
                self.deliver(ev)
        rc = self.proc.wait()
        self.logf.close()
        self.deliver({"event": "error", "code": "crashed",
                      "message": f"The dictation engine stopped unexpectedly (code {rc})."})

    def deliver(self, ev):
        if self.ended:
            return
        if ev.get("event") in ("result", "error", "cancelled", "devices", "check"):
            self.ended = True
        self.panel.post(lambda: self.on_event(ev))

    def send(self, cmd):
        try:
            self.proc.stdin.write(cmd + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def stop(self):
        self.send("stop")

    def cancel(self):
        self.send("cancel")
        threading.Timer(3, self.kill).start()

    def kill(self):
        if self.proc.poll() is None:
            try:
                self.proc.kill()
            except OSError:
                pass


DICTATION_MESSAGES = {
    "short": "That was too short to make out. Click Try again, and speak for at least a second before clicking Stop.",
    "silent": "The microphone didn't pick up any sound. Check it is plugged in and not muted, then try again. "
              "(Settings > Dictation > Test the microphone helps.)",
    "microphone": "Couldn't use the microphone.",
}


def dictation_message(ev):
    base = DICTATION_MESSAGES.get(ev.get("code"), "")
    detail = (ev.get("message") or "").strip()
    if ev.get("code") in ("short", "silent"):
        return base
    text = " ".join(x for x in (base, detail) if x) or "Dictation didn't work."
    if ev.get("code") in ("crashed", "failed"):
        text += " If it keeps happening, Settings > Dictation > Set up again repairs it."
    if IS_MAC and ev.get("code") == "microphone":
        text += " On a Mac, check System Settings > Privacy & Security > Microphone lets Quickpad listen."
    elif sys.platform.startswith("win") and ev.get("code") == "microphone":
        text += " On Windows, check Settings > Privacy > Microphone lets desktop apps use it."
    return text


class DictateBox(tk.Toplevel):
    """The floating window for {Dictate}. It starts listening straight away, shows how loud the microphone is, and when
    Stop is clicked works out the words. Like WaitBox it never grabs the keyboard, so the program being typed into
    keeps its place. `done` is set when it's over: `result` True means type `text`. on_done(text) is the alternative
    for callers on the Tk thread (the microphone test)."""

    def __init__(self, panel, message="", settings=None, on_done=None, stop_text="Stop and type  ▶"):
        super().__init__(panel.root)
        self.panel, self.on_done, self.stop_text = panel, on_done, stop_text
        self.settings = settings if settings is not None else panel.cfg["settings"]
        self.done, self.result, self.text, self.worker = threading.Event(), False, "", None
        self.heard, self.changes, self.seconds = "", [], 0      # what the model heard, corrections made, time talking
        self.title(f"{APP} — listening")
        self.attributes("-topmost", True)
        self.configure(bg=APP_BG)
        self.resizable(False, False)
        ttk.Label(self, text=tk_safe(message or "Speak now. Click Stop when you've finished."), wraplength=320,
                  justify="left", padding=(14, 12, 14, 4), font=("TkDefaultFont", 11)).pack(anchor="w")
        self.status = tk.Label(self, text="", anchor="w", justify="left", wraplength=320, bg=APP_BG, fg=MUTED)
        self.status.pack(fill="x", padx=14)
        self.meter = ttk.Progressbar(self, maximum=100, length=320, mode="determinate")
        self.meter.pack(fill="x", padx=14, pady=(4, 6))
        # "What it heard" (shown when checking the words before typing): the model's own words, with anything the
        # custom vocabulary changed highlighted, above the box of words that will be typed.
        self.heard_lbl = ttk.Label(self, text="It heard:", foreground=MUTED, padding=(14, 2, 14, 0))
        self.heard_box = tk.Text(self, width=44, height=3, wrap="word", font=("TkDefaultFont", 10), relief="flat",
                                 bg=APP_BG, fg=MUTED, cursor="arrow", takefocus=0)
        self.heard_box.tag_configure("fixed", background="#fff1b8", foreground=INK)
        self.edit_lbl = ttk.Label(self, text="It will type (change anything that's wrong):", foreground=MUTED,
                                  padding=(14, 4, 14, 0))
        self.edit = tk.Text(self, width=44, height=6, wrap="word", font=("TkDefaultFont", 11), undo=True)
        self.edit.tag_configure("fixed", background="#dcf5e3")
        row = ttk.Frame(self, padding=(14, 4, 14, 12))
        row.pack(side="bottom", fill="x")
        self.go = ttk.Button(row, style="Big.TButton")
        self.go.pack(side="left", fill="x", expand=True)
        self.teach_btn = ttk.Button(row, text="Fix a word…", command=self.teach)
        self.report_btn = ttk.Button(row, text="Copy report for Nick", command=self.copy_report)
        ttk.Button(row, text="Cancel", command=self.cancel).pack(side="right", padx=(8, 0))
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.update_idletasks()
        self.geometry(place_beside(self, panel.root))
        self.begin()

    def say(self, text, colour=None):
        self.status.config(text=text, fg=colour or MUTED)

    def begin(self):
        for w in (self.heard_lbl, self.heard_box, self.edit_lbl, self.edit, self.teach_btn, self.report_btn):
            w.pack_forget()
        self.meter.pack(fill="x", padx=14, pady=(4, 6))
        self.meter.config(mode="determinate", value=0)
        self.go.config(text=self.stop_text, command=self.stop)
        self.go.state(["!disabled"])
        self.say("Starting the microphone…")
        try:
            self.worker = DictationWorker(self.panel, "dictate", self.on_event, self.settings)
        except OSError as e:
            self.fail({"code": "failed", "message": f"Couldn't start the dictation engine: {e}"})

    def on_event(self, ev):
        if self.done.is_set() or not self.winfo_exists():
            return
        kind = ev.get("event")
        if kind == "recording":
            self.say("● Listening…", "#b3261e")
        elif kind == "level":
            self.meter.config(value=level_percent(ev.get("level")))
            secs = int(ev.get("seconds") or 0)
            self.seconds = max(self.seconds, float(ev.get("seconds") or 0))
            self.say(f"● Listening…  {secs // 60}:{secs % 60:02d}", "#b3261e")
        elif kind == "working":
            self.go.state(["disabled"])
            self.meter.config(mode="indeterminate")
            self.meter.start(15)
            self.say("Working out the words…")
        elif kind == "note":
            log.info("dictation: %s", ev.get("message"))
        elif kind == "result":
            self.got(clean_transcript(ev.get("text", "")))
        elif kind == "error":
            # Only the code goes to quickpad.log: `message` can be a bare exception str from the worker, which in
            # principle could echo back a fragment of the decoded speech. The full text still reaches the person in
            # the dialog (dictation_message(ev) below) and, if they choose to copy it, the support report — never
            # written to disk on its own.
            log.warning("dictation failed: %s", ev.get("code"))
            self.fail(ev)

    def stop(self):
        if self.worker:
            self.worker.stop()
        self.go.state(["disabled"])
        self.say("Finishing…")

    def got(self, text):
        self.meter.stop()
        self.meter.config(mode="determinate", value=0)
        if not text:
            self.fail({"code": "empty", "message": "Didn't catch any words. Try again, a little closer to the microphone."})
            return
        self.heard = text
        fixed, self.changes = apply_corrections(text, self.settings.get("dictation_fixes"))
        remember_heard(self.panel, text, fixed, self.changes)
        if self.settings.get("dictation_review") and not self.on_done:
            self.say("Check the words, correct anything that's wrong, then click Type it.")
            self.meter.pack_forget()
            self.show_heard(fixed)
            self.go.config(text="Type it  ▶", command=lambda: self.finish(True, self.edit.get("1.0", "end-1c").strip()))
            self.go.state(["!disabled"])
            self.teach_btn.pack(side="left", padx=(8, 0))
            self.bind("<Control-Return>", lambda e: self.go.invoke())
            self.lift()
            self.focus_force()
            self.edit.focus_set()
        else:
            self.finish(True, fixed)

    def show_heard(self, typed):
        """Fill the two boxes: what the model heard (changed words marked) and what will be typed."""
        self.heard_box.config(state="normal")
        self.heard_box.delete("1.0", "end")
        self.heard_box.insert("1.0", self.heard)
        self.edit.delete("1.0", "end")
        self.edit.insert("1.0", typed)
        for found, write in self.changes:
            mark_words(self.heard_box, found, "fixed")
            if write:
                mark_words(self.edit, write, "fixed")
        self.heard_box.config(state="disabled", height=min(4, max(1, len(self.heard) // 44 + 1)))
        for w, opts in ((self.heard_lbl, {}), (self.heard_box, {"padx": 14}), (self.edit_lbl, {}),
                        (self.edit, {"padx": 14, "pady": (2, 6)})):
            w.pack(fill="x" if w is not self.edit else "both", **opts)
        self.update_idletasks()
        self.geometry(place_beside(self, self.panel.root))     # it grew: keep it all on the screen

    def teach(self):
        """Add a "when it hears X, write Y" correction from here, then apply it to these words straight away."""
        try:
            chosen = self.edit.get("sel.first", "sel.last")
        except tk.TclError:
            try:
                chosen = self.heard_box.get("sel.first", "sel.last")
            except tk.TclError:
                chosen = ""
        added = teach_word(self, self.panel, chosen.strip())
        if added:
            current = self.edit.get("1.0", "end-1c")
            fixed, more = apply_corrections(current, [added])
            self.changes += more
            self.show_heard(fixed)

    def fail(self, ev):
        self.meter.stop()
        self.meter.config(mode="determinate", value=0)
        self.say(dictation_message(ev), "#b3261e")
        self.go.config(text="Try again", command=self.begin)
        self.go.state(["!disabled"])
        if ev.get("code") in ("crashed", "failed"):
            self._report_problem = dictation_message(ev)
            self.report_btn.pack(side="right", padx=(8, 0))
        else:
            self.report_btn.pack_forget()

    def copy_report(self):
        """One click instead of finding and relaying DICTATION_LOG's path: same 'copy a report' pattern as
        Check my setup, so a crash is as easy to hand to Nick as any other problem."""
        self.panel.set_clipboard(support_report(self.panel, problem=getattr(self, "_report_problem", "")))
        messagebox.showinfo(APP, "Copied. Paste it into an email or message to Nick.", parent=self)

    def cancel(self):
        if self.worker and not self.worker.ended:
            self.worker.cancel()
        self.finish(False)

    def finish(self, ok, text=""):
        if self.done.is_set():
            return
        # `ok` alone decides success/failure: a correction can legitimately turn real speech into empty
        # text (e.g. a vocabulary rule that drops a filler word), and that must still count as a completed
        # dictation — not get treated the same as Cancel, which would also skip recording usage stats.
        self.result, self.text = ok, text
        self.done.set()
        try:
            self.destroy()
        except tk.TclError:
            pass
        if self.on_done:
            self.on_done(self.text if self.result else None)


HEARD_KEEP = 20      # recent dictations kept for Settings > Vocabulary; in memory only, never written to disk


def remember_heard(panel, heard, typed, changes):
    """Keep this session's recent dictations (what it heard and what it typed) so words can be fixed afterwards.
    Only in memory: clinical words are never written to disk by Quickpad."""
    recent = getattr(panel, "heard_recent", None)
    if recent is None:
        recent = panel.heard_recent = []
    recent.insert(0, {"at": time.strftime("%H:%M"), "heard": heard, "typed": typed, "changes": list(changes)})
    del recent[HEARD_KEEP:]


def mark_words(text_widget, phrase, tag):
    """Highlight every whole-word occurrence of `phrase` in a Text widget."""
    if not phrase:
        return
    start = "1.0"
    while True:
        count = tk.IntVar()
        pos = text_widget.search(r"\y" + re.escape(phrase).replace(r"\ ", r"\s+") + r"\y", start, "end",   # Tcl: \y = edge of a word
                                 regexp=True, nocase=True, count=count)
        if not pos or not count.get():
            return
        end = f"{pos}+{count.get()}c"
        text_widget.tag_add(tag, pos, end)
        start = end


class TeachDialog(tk.Toplevel):
    """"When it hears ___, write ___." Modal; `result` is {"heard", "write"} or None."""

    def __init__(self, parent, heard="", write=""):
        super().__init__(parent)
        self.result = None
        self.title(f"{APP} — fix a word")
        self.attributes("-topmost", True)
        self.transient(parent)
        f = ttk.Frame(self, padding=14)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        ttk.Label(f, text="Teach Quickpad a word. From now on, whenever it hears the first one it types the second.",
                  wraplength=360, justify="left").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        ttk.Label(f, text="When it hears").grid(row=1, column=0, sticky="w")
        self.heard = ttk.Entry(f, width=30)
        self.heard.insert(0, heard)
        self.heard.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=2)
        ttk.Label(f, text="Type instead").grid(row=2, column=0, sticky="w")
        self.write = ttk.Entry(f, width=30)
        self.write.insert(0, write)
        self.write.grid(row=2, column=1, sticky="ew", padx=(8, 0), pady=2)
        ttk.Label(f, text="Example: when it hears “arm”, type “leg”. Leave Type instead empty to drop the word "
                          "(like “um”).", foreground=MUTED, wraplength=360, justify="left").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        row = ttk.Frame(f)
        row.grid(row=4, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(row, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(row, text="Save", command=self.ok).pack(side="right", padx=6)
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.update_idletasks()
        self.geometry(place_beside(self, parent))
        (self.write if heard else self.heard).focus_set()
        self.grab_set()

    def ok(self):
        heard, write = " ".join(self.heard.get().split()), " ".join(self.write.get().split())
        if not heard:
            messagebox.showinfo(APP, "Type the word it hears by mistake in the first box.", parent=self)
            return
        if heard.lower() == write.lower():
            messagebox.showinfo(APP, "Those are the same word, so there's nothing to change.", parent=self)
            return
        self.result = {"heard": heard, "write": write}
        self.destroy()


def add_fix(settings, fix):
    """Put a correction into the settings (replacing one for the same heard word). Returns the new list."""
    fixes = [f for f in clean_fixes(settings.get("dictation_fixes")) if f["heard"].lower() != fix["heard"].lower()]
    fixes.append(fix)
    settings["dictation_fixes"] = clean_fixes(fixes)
    return settings["dictation_fixes"]


def teach_word(parent, panel, heard=""):
    """Ask for a correction and save it into the buttons file straight away. Returns it, or None."""
    dlg = TeachDialog(parent, heard)
    parent.wait_window(dlg)
    if not dlg.result:
        return None
    add_fix(panel.cfg["settings"], dlg.result)
    if getattr(panel, "cfg_ok", True):
        try:
            save_config(panel.cfg)
        except OSError as e:
            messagebox.showwarning(APP, f"The correction works for now, but couldn't be saved:\n{e}", parent=parent)
    return dlg.result


# ---- Time saved: counts only (words, key presses, seconds), never what was typed. One file per computer.
USAGE_PATH = os.path.join(LOCAL_DIR, "usage.json")
USAGE_FIELDS = ("runs", "words", "actions", "dictations", "dictated_words", "dictated_seconds", "ai_notes", "ai_words",
                "ai_seconds")
SECONDS_PER_ACTION = 1.5     # finding and pressing a key or shortcut by hand (Tab, Enter, Ctrl+S…)
_usage_lock = threading.Lock()


def new_run_stats():
    return {k: 0 for k in USAGE_FIELDS if k != "runs"}


def count_words(text):
    return len(re.findall(r"[^\W_]+(?:['’][^\W_]+)*", text or ""))


def load_usage(path=None):
    try:
        with open(path or USAGE_PATH, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("days"), dict):
            data.setdefault("buttons", {})
            return data
    except (OSError, ValueError):
        pass
    return {"days": {}, "buttons": {}}


def record_usage(label, stats, when=None, path=None):
    """Add one button run to today's totals. Never raises: a full disk mustn't stop a button working."""
    day = (when or datetime.date.today()).isoformat()
    try:
        with _usage_lock:
            data = load_usage(path)
            d = data["days"].setdefault(day, {})
            d["runs"] = d.get("runs", 0) + 1
            for k, v in (stats or {}).items():
                if k in USAGE_FIELDS and isinstance(v, (int, float)):
                    d[k] = round(d.get(k, 0) + v, 1)
            b = data["buttons"]
            b[label] = b.get(label, 0) + 1
            if len(b) > 300:
                for name in sorted(b, key=b.get)[:len(b) - 300]:
                    del b[name]
            for old in sorted(data["days"])[:-800]:
                del data["days"][old]
            os.makedirs(os.path.dirname(path or USAGE_PATH), exist_ok=True)
            tmp = (path or USAGE_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, path or USAGE_PATH)
    except (OSError, ValueError, TypeError):
        log.warning("couldn't record usage", exc_info=True)


def saved_seconds(day, wpm):
    """Seconds this day's work would have taken by hand, minus the time spent talking for dictation."""
    wpm = max(5, min(200, float(wpm or 40)))
    typing = day.get("words", 0) / wpm * 60
    dictation = max(0.0, day.get("dictated_words", 0) / wpm * 60 - day.get("dictated_seconds", 0))
    ai = max(0.0, day.get("ai_words", 0) / wpm * 60 - day.get("ai_seconds", 0))     # talking the consult through
    return typing + dictation + ai + day.get("actions", 0) * SECONDS_PER_ACTION


def time_saved_summary(usage, settings, today=None):
    """Totals so far and a forecast from the last four weeks' average working day."""
    today = today or datetime.date.today()
    s = settings or {}
    wpm = s.get("typing_wpm") or 40
    days_pw = max(1, min(7, int(s.get("clinic_days") or 5)))
    weeks_py = max(1, min(52, int(s.get("weeks_per_year") or 48)))
    days = usage.get("days", {})

    def total(since=None):
        return sum(saved_seconds(d, wpm) for k, d in days.items() if since is None or k >= since.isoformat())
    recent = [k for k, d in days.items() if k >= (today - datetime.timedelta(days=27)).isoformat() and d.get("runs")]
    per_day = total(today - datetime.timedelta(days=27)) / len(recent) if recent else 0.0
    week = per_day * days_pw
    counts = {k: sum(d.get(k, 0) for d in days.values()) for k in USAGE_FIELDS}
    return {"today": total(today), "week_so_far": total(today - datetime.timedelta(days=today.weekday())),
            "all_time": total(), "per_day": per_day, "per_week": week, "per_month": week * 52 / 12,
            "per_year": week * weeks_py, "days_used": len(recent), "all_days_used": sum(1 for d in days.values() if d.get("runs")),
            "counts": counts, "wpm": wpm, "top": sorted(usage.get("buttons", {}).items(), key=lambda kv: -kv[1])[:5]}


def describe_duration(seconds):
    """Friendly: '40 sec', '12 min', '3.5 hours', '1 hour 20 min'."""
    seconds = max(0, seconds)
    if seconds < 60:
        return f"{round(seconds)} sec"
    minutes = seconds / 60
    if minutes < 60:
        return f"{round(minutes)} min"
    hours, mins = int(minutes // 60), int(round(minutes % 60))
    if mins == 60:
        hours, mins = hours + 1, 0
    if hours >= 10:
        return f"{round(minutes / 60)} hours"
    return f"{hours} hour{'s' if hours != 1 else ''}" + (f" {mins} min" if mins else "")


def typing_speed(target, typed, seconds):
    """Words per minute for the typing check: correct characters / 5 per minute (the usual 'net' measure)."""
    if seconds <= 0 or not typed:
        return 0
    right = sum(1 for a, b in zip(target, typed) if a == b)
    return max(0, round(right / 5 / (seconds / 60)))


# ---- AI note (Claude). Off until a key is added in Settings > AI note. The key stays on this computer only.
CLAUDE_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_KEY_PATH = os.path.join(LOCAL_DIR, "claude-key.txt")
AI_CONSENT_PATH = os.path.join(LOCAL_DIR, "ai-consent.txt")   # exists = this computer's user agreed to the disclosure
# (model id, name in Settings, what it's like). Opus 5 is the default: the most careful with clinical shorthand.
CLAUDE_MODELS = [
    ("claude-opus-5", "Claude Opus 5 (most careful, recommended)", "About 10–20 seconds a note; under 5 cents."),
    ("claude-sonnet-5", "Claude Sonnet 5 (quicker)", "About 5–10 seconds a note; about 2 cents."),
    ("claude-haiku-4-5", "Claude Haiku 4.5 (quickest)", "A few seconds a note; about 1 cent. Less careful."),
]
# The note layouts offered in Settings › AI note. A plain SOAP note is the default for a new install.
GENERIC_SOAP_INSTRUCTIONS = """You write concise clinical notes for a health practitioner in SOAP format.

STRUCTURE (one section per letter, letter then colon):
S: Subjective - what the patient reports: the problem, how it has changed since last time, what makes it better or worse, how it affects daily life, and what they want from treatment. e.g. Low back pain 40% better, sitting easier, still stiff mornings
O: Objective - examination findings and measurements. e.g. Lumbar flexion improved, R QL tight, SLR R 60°
A: Assessment - the practitioner's assessment and the treatment given today, in the order performed. e.g. Improving mechanical LBP. Lumbar mobilisation, soft tissue R QL
P: Plan - what happens next: home advice or exercises, review date, referrals. e.g. Continue home exercises, review 1 week

STYLE: concise clinical shorthand, no narrative paragraphs; a routine follow-up should be about one or two lines per letter. Common clinical abbreviations are fine (R, L, BL, ROM, SLR, NAD, Hx, Rx, ↑ improved/increased, ↓ reduced). Keep the order treatment was given in. Use Australian spelling.

EXAMPLE:
S: LBP ↓ 50%, sitting easier, sleep better. Goal: return to tennis
O: Flex ↑, R QL T, SLR R 60°
A: Improving mechanical LBP. Lx mob, Tx mob, STM QL
P: Continue 2/wk, start core ex next visit"""

# The FOAMING SOAP system: background (FOAMING) kept apart from this visit (SOAP), condensed for the AI. Offered as a
# layout in Settings › AI note.
FOAMING_SOAP_INSTRUCTIONS = """You write chiropractic clinical notes using the FOAMING SOAP system.

STRUCTURE (one line per letter, letter then colon):
FOAMING (background / context / the patient as a person)
F: Family - partner, children (name, age, sport), who lives with them. e.g. W: Sarah RN, D: Emma 12 gymnastics
O: Occupation - type of work and its physical demands (lifting, sitting, driving, overhead, shift work). e.g. Electrician heavy lifting/crawling
A: Activities / interests - sport, hobbies, caring roles. e.g. Golf 2x/wk, gardening
M: Medical - relevant history and meds only. e.g. T2DM, HTN, OA knees, Meds: Endone PRN
I: Imaging - findings with dates. e.g. MRI Lx 3/24 L4/5 disc protrusion
N: Neuro / ortho tests - meaningful findings only. e.g. SLR +R 45°, ↓ AJ R, UE neuro NAD
G: Goals - the patient's functional goals. e.g. Sleep thru night, return golf, avoid surg

SOAP (this visit)
S: Subjective - what the patient reports: change, aggravators, function, flare-ups. e.g. LBP ↓ 40%, sitting easier
O: Objective - examination findings. e.g. Flex ↑, R QL T, SLR improved
A: Adjustments / treatment - in the order performed, joined with " > ". e.g. Lx drop > Tx mob > Cx activator, STM QL, laser L4/5, cryo 5m
P: Plan - next step. e.g. Continue 3/wk, review 2/52, GP referral if worsening

ABBREVIATIONS (use them; don't expand them):
Family: H husband, W wife, D daughter, S son, GD granddaughter, GS grandson, MIL/FIL mother/father-in-law, BF, GF.
General: P pain, S stiffness, T tight, BL bilateral, ↑ increased/improved, ↓ decreased/reduced, R right, L left, PRN, Hx, PMHx, Meds, NAD, WNL.
Spinal/MSK: LBP, NP neck pain, HA headache, Lx lumbar, Tx thoracic, Cx cervical, SIJ, QL, DDD, OA, OP osteoporosis, STM soft tissue massage, Mob mobilisation, Ex exercise, RTW.
Neuro: UE, LE, SLR, AJ ankle jerk, KJ knee jerk, CN, Wk weakness, N/T numbness/tingling.
Medical: T2DM, HTN, COPD, CKD, IBS, GERD, AF, CVA, TIA, CA. Surgical: THR, TKR, CABG. Imaging: MRI, CT, XR, DEXA.

STYLE: concise clinical shorthand, no narrative paragraphs; a routine follow-up should be about one line per SOAP letter. Keep the treatment order. Capture goals and occupational demands whenever mentioned. Keep background (FOAMING) separate from this visit (SOAP).

EXAMPLE:
F: W: Julie teacher, D: Ava 10 gymnastics
O: Electrician repetitive lifting/crawling
A: Golf, gym
M: HTN, OA knees
I: MRI Lx 2/25 L4/5 protrusion + mild stenosis
N: SLR +R 50°, ↓ AJ R
G: Avoid surg, return golf

S: LBP + R leg P ↓ 50%, sitting easier, sleep better
O: Flex ↑, less spasm, SLR improved
A: Lx drop > Tx mob > Cx activator, NSSD P8 25m, laser L4/5, cryo 5m
P: Continue 3/wk, progress core ex next visit"""

# Added after the clinic's instructions whatever they say: the safety rules for anything going into a clinical record.
AI_NOTE_RULES = """
RULES FOR THIS NOTE:
- Use only what is in the consult text. Never invent or assume findings, measurements, test results, treatments, dates or history. If a line has nothing in the text, leave that line out.
- If the text mentions any of: worsening neuro signs, new trauma, new imaging, medication changes, bowel/bladder symptoms, progressive weakness, falls, or surgery discussions, add a final line starting "FLAG:" naming it.
- If the text is unclear about something that matters clinically, add a final line starting "CHECK:" saying what to confirm.
- Output only the note itself as plain text: no preamble, no headings other than the letters, no markdown, no bold."""

AI_NOTE_SAMPLE = ("Made-up example consult for testing (not a real patient). Sam is back for her third visit. Lower back "
                  "is about half as bad as last week and she's sitting through work meetings now. She's an accountant, "
                  "long computer hours. Plays tennis on weekends and wants to get back to it. Still a bit of pain down "
                  "the right leg in the mornings. Flexion better, right QL still tight, straight leg raise right about 60 "
                  "degrees. I did lumbar drop, thoracic mobs and soft tissue on the QL, then laser. Keep going twice a "
                  "week and we'll start core work next time.")


class AIError(Exception):
    pass


def read_claude_key():
    try:
        with open(CLAUDE_KEY_PATH, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def write_claude_key(key):
    _write_secret(CLAUDE_KEY_PATH, key)


def _read_secret(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def _write_secret(path, text):
    """Save (or with '' remove) a key, readable only by this user."""
    text = text.strip()
    if not text:
        _quiet_remove(path)
        return
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fd = os.open(path + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(path + ".tmp", path)


# key → (name in Settings, built-in instructions). "custom" uses the instructions typed in Settings (ai_instructions).
AI_LAYOUTS = {
    "soap": ("Generic SOAP", GENERIC_SOAP_INSTRUCTIONS),
    "foaming": ("FOAMING SOAP", FOAMING_SOAP_INSTRUCTIONS),
    "custom": ("Custom (my own instructions)", ""),
}


def ai_instructions(settings):
    """The layout instructions Claude is given: the chosen built-in layout, or the custom text. A buttons file from
    before 3.3 has no `ai_layout` yet and keeps what it did then (its own text, else FOAMING SOAP) until load_config
    adds the key for it (upgrade_ai_layout)."""
    s = settings or {}
    custom = (s.get("ai_instructions") or "").strip()
    layout = s.get("ai_layout")
    if layout == "custom":
        return custom or GENERIC_SOAP_INSTRUCTIONS
    if layout in AI_LAYOUTS:
        return AI_LAYOUTS[layout][1]
    if layout is None:
        return custom or FOAMING_SOAP_INSTRUCTIONS
    return GENERIC_SOAP_INSTRUCTIONS


def upgrade_ai_layout(raw):
    """A buttons file from before 3.3 has no note layout setting. Until then the AI note used FOAMING SOAP unless its
    own instructions had been typed in, so that choice is written in explicitly and nothing changes for an existing
    install; only new installs start on Generic SOAP. Works on the raw file, before defaults are filled in. Returns
    True if it changed anything."""
    s = raw.get("settings") if isinstance(raw, dict) else None
    if not isinstance(s, dict) or "ai_layout" in s:
        return False
    s["ai_layout"] = "custom" if str(s.get("ai_instructions") or "").strip() else "foaming"
    return True


def ai_system_prompt(settings):
    return ai_instructions(settings) + "\n" + AI_NOTE_RULES


def consult_message(source):
    return "Write the note from this consult text:\n\n<consult>\n" + source.strip() + "\n</consult>"


def claude_request(source, settings, key):
    """The Messages API request (url, headers, body) that turns consult text into a note."""
    model = (settings or {}).get("ai_model") or DEFAULT_CLAUDE_MODEL
    if model not in [m[0] for m in CLAUDE_MODELS]:
        model = DEFAULT_CLAUDE_MODEL
    body = {"model": model, "max_tokens": 4000, "system": ai_system_prompt(settings),
            "messages": [{"role": "user", "content": consult_message(source)}]}
    headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    if not model.startswith("claude-haiku"):
        body["output_config"] = {"effort": "medium"}          # plenty for reformatting; keeps the wait short
    if model == "claude-opus-5":
        # If Opus declines a request, the API retries it on another model within the same call.
        body["fallbacks"] = "default"
        headers["anthropic-beta"] = "server-side-fallback-2026-07-01"
    return CLAUDE_URL, headers, body


def tidy_note(text):
    """Leave out letter lines with nothing after them ("M:"), as the rules ask; small models write them anyway."""
    return "\n".join(line for line in text.splitlines() if not re.fullmatch(r"\s*[A-Z]{1,2}:\s*", line)).strip()


def parse_claude_reply(reply):
    """The note text from a Messages API reply, or AIError with a plain-English reason."""
    if not isinstance(reply, dict) or not isinstance(reply.get("content", []), list):
        raise AIError("Claude sent back something unreadable. Try again.")
    if reply.get("stop_reason") == "refusal":
        raise AIError("Claude declined to write this note. Try again, or write it by hand.")
    text = "\n".join(str(b.get("text", "")) for b in reply.get("content", [])
                     if isinstance(b, dict) and b.get("type") == "text").strip()
    if reply.get("stop_reason") != "max_tokens":
        text = tidy_note(text)                 # a cut-off note is shown as it stopped
    if not text:
        raise AIError("Claude sent back an empty note. Try again.")
    if reply.get("stop_reason") == "max_tokens":
        text += "\n[The note was cut off because it was very long. Check the end.]"
    return text


def claude_error(code, detail):
    if code == 401:
        return "Claude didn't accept the key. Check it in Settings > AI note (it starts with sk-ant-)."
    if code == 403:
        return "That key isn't allowed to use Claude. Check the key's account in the Anthropic console."
    if code == 429:
        return "Claude is busy or the account's limit was reached. Wait a minute and try again."
    if code == 400 and "credit" in detail.lower():
        return "The Anthropic account is out of credit. Add some at console.anthropic.com, then try again."
    if code and code >= 500:
        return "Claude's servers had a problem. Try again in a minute."
    return f"Claude couldn't write the note ({code or 'no connection'}). {detail[:200]}".strip()


def _post_claude(url, headers, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout, context=_download_ssl()) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _claude_detail(err):
    try:
        detail = json.loads(err.read().decode("utf-8", "replace")).get("error", {}).get("message", "")
    except (ValueError, OSError, AttributeError):
        detail = ""
    # Never write the API's own message text to quickpad.log: some error types (e.g. content-policy ones) can echo
    # back a fragment of the consult text that was sent, and the log is what "Copy report to send to Nick" reads
    # from. `detail` is still returned for the on-screen message, which is shown only to the person who sent it.
    log.warning("claude error %s", err.code)
    return detail


def claude_write_note(source, settings, key=None, timeout=120):
    """Send the consult text to Claude and return the note. Raises AIError with a readable reason."""
    key = key if key is not None else read_claude_key()
    if not key:
        raise AIError("Add a Claude key first: Settings > AI note.")
    if not (source or "").strip():
        raise AIError("There was no consult text to work from.")
    url, headers, body = claude_request(source, settings, key)
    try:
        reply = _post_claude(url, headers, body, timeout)
    except urllib.error.HTTPError as e:
        detail = _claude_detail(e)
        if e.code == 400 and "fallback" in detail.lower() and "fallbacks" in body:
            # An account or API version without the fallback option: ask again without it rather than fail.
            body.pop("fallbacks")
            headers.pop("anthropic-beta", None)
            try:
                reply = _post_claude(url, headers, body, timeout)
            except urllib.error.HTTPError as e2:
                raise AIError(claude_error(e2.code, _claude_detail(e2)))
            except (urllib.error.URLError, OSError, socket.timeout) as e2:
                raise AIError(f"Couldn't reach Claude. Check the internet connection. ({e2})")
            except ValueError:
                raise AIError("Claude sent back something unreadable. Try again.")
            return parse_claude_reply(reply)
        raise AIError(claude_error(e.code, detail))
    except (urllib.error.URLError, OSError, socket.timeout) as e:
        raise AIError(f"Couldn't reach Claude. Check the internet connection. ({e})")
    except ValueError:
        raise AIError("Claude sent back something unreadable. Try again.")
    return parse_claude_reply(reply)


# ---- 3.4: where the AI note is written. "local" (the default) runs an AI model on this computer with llama.cpp, so
# nothing leaves it. "openai" (any OpenAI-compatible server) and "anthropic" (Claude) are the person's own provider and
# key, opt-in only. The choice is kept per computer (ai-provider.json), never in the buttons file: that can be shared
# through a cloud folder, and one computer choosing a cloud provider must never switch another one to it.
AI_ENGINES = ("local", "openai", "anthropic")
AI_DIR = os.path.join(LOCAL_DIR, "ai")
AI_PROVIDER_PATH = os.path.join(LOCAL_DIR, "ai-provider.json")
OPENAI_KEY_PATH = os.path.join(LOCAL_DIR, "ai-openai-key.txt")
AI_PROVIDER_DEFAULTS = {"engine": "local", "local_model": "", "openai_url": "", "openai_model": ""}

# llama.cpp's own prebuilt server, one pinned build (MIT licence). Each file is checked against its SHA-256 before use.
LLAMA_BUILD = "b11429"
LLAMA_ENGINES = {
    "win-cpu-x64": {"file": "llama-b11429-bin-win-cpu-x64.zip", "bytes": 19398918,
                    "sha256": "1283323272b04cd07905816a597a0da810918102de958f4ff6f7bbaa70ed2efe"},
    "macos-arm64": {"file": "llama-b11429-bin-macos-arm64.tar.gz", "bytes": 11971406,
                    "sha256": "740288ec6887be94280a5dfa25b5e23a78285cab104519e6c7e218904ee82459"},
    "macos-x64": {"file": "llama-b11429-bin-macos-x64.tar.gz", "bytes": 11487431,
                  "sha256": "29ac3ea02be6bd143e824973f2cc5fa74bc4094393a9eaab0ff6814f19dd8522"},
    "ubuntu-x64": {"file": "llama-b11429-bin-ubuntu-x64.tar.gz", "bytes": 17693462,
                   "sha256": "f6d25dde8f51133143d1453da4fd5f73b145127177612a283bf7995957af3392"},
}
# Note-writing models (Apache-2.0), from a pinned Hugging Face commit: the uploader sometimes replaces files on main.
# Chosen by writing 8 FOAMING notes from the made-up consult with each (15 Oct 2026, see docs/SPEC-3.4-ai-local.md):
# Qwen3.5-9B invented nothing. Qwen3-4B-Instruct-2507 got every treatment right but once invented a daughter, so it is
# only the smaller choice. Qwen3.5-4B (an invented treatment in 5 of 8) and Qwen3.5-2B (an invented medical history)
# were left out.
LOCAL_MODELS = [
    {"key": "qwen3.5-9b", "name": "Standard (Qwen3.5 9B, 5.7 GB)", "repo": "unsloth/Qwen3.5-9B-GGUF",
     "commit": "3885219b6810b007914f3a7950a8d1b469d598a5", "file": "Qwen3.5-9B-Q4_K_M.gguf", "bytes": 5680522464,
     "sha256": "03b74727a860a56338e042c4420bb3f04b2fec5734175f4cb9fa853daf52b7e8", "min_ram_gb": 12,
     "note": "The most careful. Needs 16 GB of memory; about a minute a note on a typical laptop."},
    {"key": "qwen3-4b-2507", "name": "Smaller (Qwen3 4B, 2.5 GB)", "repo": "bartowski/Qwen_Qwen3-4B-Instruct-2507-GGUF",
     "commit": "ae44f08e1392f39c0e474af10c3ff8355c8b6688", "file": "Qwen_Qwen3-4B-Instruct-2507-Q4_K_M.gguf",
     "bytes": 2497280736, "sha256": "2fde00ce69dd4899c70d020845e2638353015bba0fdf161b3eb965f2bca4464e",
     "min_ram_gb": 6,
     "note": "For computers with 8 GB of memory. Quicker, but less careful: it sometimes adds background details "
             "(like family) that weren't said, so check those lines closely."},
]


def engine_url(plat):
    return f"https://github.com/ggml-org/llama.cpp/releases/download/{LLAMA_BUILD}/{LLAMA_ENGINES[plat]['file']}"


def local_model_info(key):
    return next((m for m in LOCAL_MODELS if m["key"] == key), None)


def local_model_url(key):
    m = local_model_info(key)
    return f"https://huggingface.co/{m['repo']}/resolve/{m['commit']}/{m['file']}"


def local_model_path(key):
    return os.path.join(AI_DIR, "models", local_model_info(key)["file"])


def engine_dir():
    return os.path.join(AI_DIR, "engine-" + LLAMA_BUILD)


def engine_platform(info):
    """Which llama.cpp build suits this computer, or None if there isn't one (e.g. Linux on ARM)."""
    system, arch = info.get("system") or "", (info.get("arch") or "").lower()
    if system.startswith("win"):
        return "win-cpu-x64" if arch in ("amd64", "x86_64") else None
    if system == "darwin":
        return {"arm64": "macos-arm64", "aarch64": "macos-arm64", "x86_64": "macos-x64"}.get(arch)
    if system.startswith("linux"):
        return "ubuntu-x64" if arch in ("x86_64", "amd64") else None
    return None


def suggest_local_model(info):
    return "qwen3.5-9b" if (info.get("ram_gb") or 0) >= 15 else "qwen3-4b-2507"   # "16 GB" reads as 15.x


def glibc_version():
    """(major, minor) of the C library on Linux, or None elsewhere / if it can't be read."""
    try:
        m = re.search(r"(\d+)\.(\d+)", os.confstr("CS_GNU_LIBC_VERSION") or "")
    except (AttributeError, ValueError, OSError):
        return None
    return (int(m.group(1)), int(m.group(2))) if m else None


def _gb(n):
    return f"{n / 1e9:.1f}".rstrip("0").rstrip(".")      # decimal GB, as download sizes are quoted


def local_setup_problem(info, key, free_bytes, glibc):
    """Why the local AI can't be set up on this computer, in plain English, or "" if it can."""
    plat = engine_platform(info)
    if not plat:
        return ("The AI engine can't run on this computer (it needs Windows, a Mac, or Linux on an Intel or AMD "
                "processor). You can use your own AI provider instead.")
    if (info.get("system") or "").startswith("linux") and glibc and glibc < (2, 34):
        return "The AI engine needs a newer Linux: Linux Mint 21 or Ubuntu 22.04, or newer."
    m = local_model_info(key)
    ram = info.get("ram_gb")
    if ram and ram < m["min_ram_gb"]:
        if m is LOCAL_MODELS[-1]:
            return (f"This computer has {ram:g} GB of memory, not enough to write notes on it (it needs at least "
                    f"{m['min_ram_gb']} GB). You can use your own AI provider instead.")
        return (f"This computer has {ram:g} GB of memory and this model needs at least {m['min_ram_gb']} GB. "
                "Choose the smaller model.")
    need = 2 * (LLAMA_ENGINES[plat]["bytes"] + m["bytes"])
    if free_bytes < need:
        return f"Setting it up needs about {_gb(need)} GB free; this computer has {_gb(free_bytes)} GB free."
    return ""


def find_server_exe(folder):
    """The llama-server program in an unpacked engine (at the top or one folder down), or ""."""
    names = ("llama-server.exe", "llama-server")
    for depth_dir in [folder] + sorted(glob.glob(os.path.join(folder, "*"))):
        for n in names:
            p = os.path.join(depth_dir, n)
            if os.path.isfile(p):
                return p
    return ""


def local_ai_state(provider):
    """(ready, why not) for writing notes on this computer."""
    info = machine_info()
    if not engine_platform(info):
        return False, local_setup_problem(info, LOCAL_MODELS[-1]["key"], 0, None)
    key = (provider or {}).get("local_model") or suggest_local_model(info)
    if not local_model_info(key):
        key = suggest_local_model(info)
    folder = engine_dir()
    if not find_server_exe(folder):
        if os.path.isdir(folder):
            return False, ("Part of the AI engine is missing; your antivirus may have removed it. Click Set up in "
                           "Settings > AI note to put it back (you may need to allow Quickpad's folder in the "
                           "antivirus).")
        return False, "Set up the AI note first: Settings > AI note > Set up (a one-off download)."
    if not os.path.isfile(local_model_path(key)):
        return False, "Set up the AI note first: Settings > AI note > Set up (a one-off download)."
    return True, ""


def read_ai_provider():
    """This computer's AI provider. The first time (no file yet), a computer that already has a Claude key from 3.3
    keeps using Claude, as it was deliberately set up; any other starts on this computer. That choice is then
    written down, so it's settled once and never re-guessed."""
    p = dict(AI_PROVIDER_DEFAULTS)
    if not os.path.exists(AI_PROVIDER_PATH):
        p["engine"] = "anthropic" if read_claude_key() else "local"
        try:
            write_ai_provider(p)
        except OSError:
            pass
        return p
    try:
        with open(AI_PROVIDER_PATH, encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, ValueError):
        return p
    if isinstance(raw, dict):
        p.update({k: str(raw[k]) for k in AI_PROVIDER_DEFAULTS if isinstance(raw.get(k), str)})
    if p["engine"] not in AI_ENGINES:
        p["engine"] = "local"
    return p


def write_ai_provider(p):
    out = dict(AI_PROVIDER_DEFAULTS)
    out.update({k: str(v) for k, v in (p or {}).items() if k in AI_PROVIDER_DEFAULTS and v is not None})
    os.makedirs(os.path.dirname(AI_PROVIDER_PATH) or ".", exist_ok=True)
    with open(AI_PROVIDER_PATH + ".tmp", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    os.replace(AI_PROVIDER_PATH + ".tmp", AI_PROVIDER_PATH)


def ai_host(p):
    """Where the consult text goes for this provider, or None when it stays on this computer."""
    engine = (p or {}).get("engine")
    if engine == "anthropic":
        return CLAUDE_HOST
    if engine == "openai":
        return urllib.parse.urlsplit((p or {}).get("openai_url") or "").hostname or ""
    return None


def read_openai_key():
    return _read_secret(OPENAI_KEY_PATH)


def write_openai_key(key):
    _write_secret(OPENAI_KEY_PATH, key)


def _local_host(host):
    if host == "localhost" or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private


def check_openai_url(url):
    """(ok, cleaned address, problem). https:// is required, except for this computer or the clinic's own network."""
    url = (url or "").strip()
    try:
        u = urllib.parse.urlsplit(url)
        host = u.hostname or ""
    except ValueError:
        return False, url, "That isn't a web address. It should look like https://api.example.com/v1"
    if u.scheme not in ("http", "https") or not host:
        return False, url, "That isn't a web address. It should look like https://api.example.com/v1"
    if u.username or u.password:
        return False, url, "Put the key in the key box, not in the address."
    if u.scheme == "http" and not _local_host(host):
        return False, url, ("Use an https:// address. Only this computer or the clinic's own network can use "
                            "http://, because over the internet the text would travel unencrypted.")
    return True, url.rstrip("/"), ""


def openai_request(source, settings, base_url, model, key):
    """An OpenAI-style chat completions request (url, headers, body): the format most AI servers accept, including
    the local engine."""
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = "Bearer " + key
    body = {"model": model, "temperature": 0.2, "stream": False,
            "messages": [{"role": "system", "content": ai_system_prompt(settings)},
                         {"role": "user", "content": consult_message(source)}]}
    return base_url.rstrip("/") + "/chat/completions", headers, body


def parse_openai_reply(reply, who="The AI"):
    try:
        choice = reply["choices"][0]
        text = choice["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise AIError(f"{who} sent back something unreadable. Try again.")
    if not isinstance(text, str):
        raise AIError(f"{who} sent back something unreadable. Try again.")
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()   # a model that thinks out loud first
    if choice.get("finish_reason") != "length":
        text = tidy_note(text)                 # a cut-off note is shown as it stopped
    if not text:
        raise AIError(f"{who} sent back an empty note. Try again.")
    if choice.get("finish_reason") == "length":
        text += "\n[The note was cut off because it was very long. Check the end.]"
    return text


def openai_error(code, detail, host):
    if code in (401, 403):
        return f"{host} didn't accept the key. Check it in Settings > AI note."
    if code == 429:
        return f"{host} is busy or the account's limit was reached. Wait a minute and try again."
    if code == 404:
        return (f"{host} doesn't know that model or address. Check the model name and server address in "
                "Settings > AI note.")
    if code and code >= 500:
        return f"{host} had a problem. Try again in a minute."
    return f"{host} couldn't write the note ({code or 'no connection'}). {detail[:200]}".strip()


def _post_json(url, headers, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout, context=_download_ssl()) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _openai_detail(err):
    """The error message from an OpenAI-style error reply. Never logged (it can echo the consult text)."""
    try:
        e = json.loads(err.read().decode("utf-8", "replace")).get("error", {})
        return e.get("message", "") if isinstance(e, dict) else str(e)
    except (ValueError, OSError, AttributeError):
        return ""


def openai_write_note(source, settings, base_url, model, key, timeout=180, who=None):
    who = who or urllib.parse.urlsplit(base_url).hostname or "The AI"
    url, headers, body = openai_request(source, settings, base_url, model, key)
    return _send_openai(url, headers, body, timeout, who)


def _send_openai(url, headers, body, timeout, who):
    try:
        reply = _post_json(url, headers, body, timeout)
    except urllib.error.HTTPError as e:
        log.warning("AI provider error %s", e.code)
        raise AIError(openai_error(e.code, _openai_detail(e), who))
    except (urllib.error.URLError, OSError, socket.timeout) as e:
        raise AIError(f"Couldn't reach {who}. ({e})")
    except ValueError:
        raise AIError(f"{who} sent back something unreadable. Try again.")
    return parse_openai_reply(reply, who)


def ai_write_note(source, settings, provider=None):
    """Write the note with this computer's chosen provider. Raises AIError with a readable reason."""
    p = provider or read_ai_provider()
    if not (source or "").strip():
        raise AIError("There was no consult text to work from.")
    if p["engine"] == "anthropic":
        return claude_write_note(source, settings, read_claude_key())
    if p["engine"] == "openai":
        ok, url, problem = check_openai_url(p.get("openai_url"))
        if not ok:
            raise AIError(problem + " (Settings > AI note)")
        if not (p.get("openai_model") or "").strip():
            raise AIError("Type the model name in Settings > AI note.")
        return openai_write_note(source, settings, url, p["openai_model"].strip(), read_openai_key())
    ready, why = local_ai_state(p)
    if not ready:
        raise AIError(why)
    info = machine_info()
    key = p.get("local_model") if local_model_info(p.get("local_model")) else suggest_local_model(info)
    return LOCAL_AI.write(source, settings, exe=find_server_exe(engine_dir()), model=local_model_path(key))


# ---- setting up the local engine: downloads checked against the pinned SHA-256, unpacked safely

def _download_checked(url, dest, size, sha256, name, progress=None, cancelled=None):
    """Fetch url to dest via dest.part and keep it only if the size and SHA-256 match. A download that drops part way
    leaves its .part behind, and the next try asks for just the rest (HTTP Range): a model is gigabytes."""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    have = os.path.getsize(part) if os.path.isfile(part) else 0
    if have >= size:
        _quiet_remove(part)
        have = 0
    digest, done = hashlib.sha256(), 0
    headers = {"User-Agent": f"{APP}/{VERSION}"}
    if have:
        headers["Range"] = f"bytes={have}-"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30, context=_download_ssl()) as r:
            resumed = bool(have) and getattr(r, "status", 200) == 206
            if resumed:
                with open(part, "rb") as f:
                    for block in iter(lambda: f.read(1 << 20), b""):
                        digest.update(block)
                done = have
            with open(part, "ab" if resumed else "wb") as out:
                while True:
                    if cancelled and cancelled():
                        raise Cancelled()
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
                    digest.update(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, size)
    except Cancelled:
        raise                                         # the .part stays, so setting up again carries on
    except (urllib.error.URLError, OSError) as e:
        raise AIError(f"Couldn't download the {name}. Check the internet connection and try again; it carries on "
                      f"from where it stopped. ({e})")
    if done != size or digest.hexdigest() != sha256:
        _quiet_remove(part)
        raise AIError(f"The {name} didn't download correctly (it doesn't match the known file), so it wasn't kept. "
                      "Try again.")
    os.replace(part, dest)
    return dest


def _inside(name):
    """True if an archive path stays inside the folder it's unpacked into."""
    if not name or name.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", name):
        return False
    norm = os.path.normpath(name.replace("\\", "/"))
    return norm != ".." and not norm.startswith(".." + os.sep) and not norm.startswith("../")


def safe_unpack(archive, dest):
    """Unpack the engine archive into dest, refusing anything that would land outside it (absolute paths, "..",
    or links pointing out of the folder). The engine's own library links (libllama.so -> libllama.so.0) are kept."""
    os.makedirs(dest, exist_ok=True)
    if archive.endswith(".zip"):
        with zipfile.ZipFile(archive) as z:
            for n in z.namelist():
                if not _inside(n):
                    raise AIError("The AI engine download had an unexpected file in it, so it wasn't used.")
            z.extractall(dest)
        return
    with tarfile.open(archive, "r:*") as t:
        members = t.getmembers()
        for m in members:
            ok = _inside(m.name) and (m.isfile() or m.isdir() or m.issym() or m.islnk())
            if ok and m.issym():
                ok = not os.path.isabs(m.linkname) and _inside(os.path.join(os.path.dirname(m.name), m.linkname))
            if ok and m.islnk():
                ok = _inside(m.linkname)
            if not ok:
                raise AIError("The AI engine download had an unexpected file in it, so it wasn't used.")
        if hasattr(tarfile, "data_filter"):
            t.extractall(dest, filter="data")
        else:  # pragma: no cover - Python without extraction filters; every member was checked above
            t.extractall(dest)


def setup_local_ai(model_key, say=print, progress=None, cancelled=None):
    """Download and check the AI engine and the chosen model. A few minutes the first time. Raises AIError (or
    Cancelled) with what to do next."""
    info = machine_info()
    m = local_model_info(model_key)
    if not m:
        raise AIError(f"Unknown model {model_key!r}.")
    os.makedirs(AI_DIR, exist_ok=True)
    problem = local_setup_problem(info, model_key, shutil.disk_usage(AI_DIR).free, glibc_version())
    if problem:
        raise AIError(problem)
    plat = engine_platform(info)
    folder = engine_dir()
    if not find_server_exe(folder):
        e = LLAMA_ENGINES[plat]
        say("Downloading the AI engine…")
        archive = _download_checked(engine_url(plat), os.path.join(AI_DIR, e["file"]), e["bytes"], e["sha256"],
                                    "AI engine", progress, cancelled)
        say("Unpacking the AI engine…")
        tmp = folder + ".tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            safe_unpack(archive, tmp)
        except (tarfile.TarError, zipfile.BadZipFile, OSError) as err:
            shutil.rmtree(tmp, ignore_errors=True)
            raise AIError(f"Couldn't unpack the AI engine ({err}). Try again.")
        finally:
            _quiet_remove(archive)
        if IS_MAC:
            sh(["xattr", "-dr", "com.apple.quarantine", tmp], timeout=60)
        shutil.rmtree(folder, ignore_errors=True)
        os.replace(tmp, folder)
        if not find_server_exe(folder):
            raise AIError("The AI engine download didn't contain the expected program. Try again.")
    if not os.path.isfile(local_model_path(model_key)):
        say(f"Downloading the note-writing model ({_gb(m['bytes'])} GB)… this can take a while.")
        _download_checked(local_model_url(model_key), local_model_path(model_key), m["bytes"], m["sha256"],
                          "note-writing model", progress, cancelled)
    say("The AI note is ready on this computer.")


# ---- running the local engine

def llama_server_command(exe, model, port, token, cores):
    """The engine listens on this computer only, with a per-run token so other programs on it can't use it, and never
    goes online itself. --no-slots: the slots endpoint would hand back the last prompt (the consult) to anyone on the
    computer who learnt the token from the process list. Half the processor's threads leaves the rest of the computer
    responsive."""
    return [exe, "-m", model, "--host", "127.0.0.1", "--port", str(port), "--api-key", token,
            "-c", "8192", "-t", str(max(1, (cores or 1) // 2)), "-np", "1", "--jinja", "--reasoning", "off",
            "--no-webui", "--offline", "--no-slots"]


class LocalAIServer:
    """Starts llama-server the first time a note is written and keeps the model loaded between notes, so the next
    one doesn't wait for it to load. Stops after idle_seconds without a note, and when Quickpad quits."""

    def __init__(self, command_prefix=None, log_path=None, idle_seconds=600, start_timeout=180):
        self.command_prefix, self.idle_seconds, self.start_timeout = command_prefix, idle_seconds, start_timeout
        self.log_path = log_path or os.path.join(AI_DIR, "engine.log")
        self.lock = threading.Lock()
        self.proc = self.model = self.port = self.token = None
        self.last_used = 0.0

    @property
    def base_url(self):
        return f"http://127.0.0.1:{self.port}"

    def _open_log(self):
        os.makedirs(os.path.dirname(self.log_path) or ".", exist_ok=True)
        try:
            if os.path.getsize(self.log_path) > 1_000_000:
                os.replace(self.log_path, self.log_path + ".old")
        except OSError:
            pass
        return open(self.log_path, "ab")

    def _start(self, exe, model):
        self._stop_locked()
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        token = secrets.token_urlsafe(24)
        cmd = llama_server_command(exe, model, port, token, machine_info().get("cores"))
        if self.command_prefix:
            cmd = list(self.command_prefix) + cmd[1:]
        with self._open_log() as logf:
            try:
                proc = subprocess.Popen(cmd, stdout=logf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                        cwd=os.path.dirname(exe) if os.path.isfile(exe) else None, **_no_window())
            except OSError as e:
                raise AIError(f"The AI engine couldn't start ({e}). Your antivirus may have blocked it; try Set up "
                              "again in Settings > AI note.")
        self.proc, self.model, self.port, self.token = proc, model, port, token
        deadline = time.monotonic() + self.start_timeout
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                self.proc = None
                raise AIError("The AI engine stopped while starting. Copy report (Settings > Help) and send it to "
                              "Nick.")
            try:
                with urllib.request.urlopen(self.base_url + "/health", timeout=2) as r:
                    if r.status == 200:
                        threading.Thread(target=self._watch_idle, args=(proc,), daemon=True).start()
                        return
            except urllib.error.HTTPError:
                pass                                   # 503 while the model loads
            except (urllib.error.URLError, OSError):
                pass
            time.sleep(0.2)
        self._stop_locked()
        raise AIError("The AI engine took too long to start. Try again; if it keeps happening, the computer may not "
                      "have enough free memory (close other programs, or choose the smaller model).")

    def write(self, source, settings, exe, model, timeout=600):
        with self.lock:
            if self.proc is None or self.proc.poll() is not None or self.model != model:
                self._start(exe, model)
            self.last_used = time.monotonic()
            url, headers, body = openai_request(source, settings, self.base_url + "/v1", "local", self.token)
            body["max_tokens"] = 1500
            body["chat_template_kwargs"] = {"enable_thinking": False}
            try:
                return _send_openai(url, headers, body, timeout, "The AI engine on this computer")
            finally:
                self.last_used = time.monotonic()

    def _watch_idle(self, proc):
        while True:
            time.sleep(max(0.1, min(self.idle_seconds / 4, 30)))
            with self.lock:
                if self.proc is not proc or proc.poll() is not None:
                    return
                if time.monotonic() - self.last_used >= self.idle_seconds:
                    self._stop_locked()
                    return

    def _stop_locked(self):
        proc, self.proc = self.proc, None
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(5)

    def stop(self):
        with self.lock:
            self._stop_locked()


LOCAL_AI = LocalAIServer()
atexit.register(LOCAL_AI.stop)


# The worker runs inside the dictation environment, never inside Quickpad itself. Kept in this file so a Quickpad
# update brings a matching worker with it (write_worker() puts it in place before each run).
DICTATION_WORKER_SOURCE = r'''"""Quickpad dictation worker. Written out by quickpad.py: changes made here are overwritten.

Usage: python worker.py check | devices | dictate | file  [--file WAV --model PATH --threads N --prompt TEXT --device NAME
       --max-seconds N --min-seconds N --silent-peak X --fake-audio WAV]
Prints one JSON object per line on stdout. In dictate mode it listens until "stop" (or "cancel") arrives on stdin.
"""
import json
import shutil
import subprocess
import sys
import threading
import time
import traceback

RATE = 16000


def emit(**kw):
    sys.stdout.write(json.dumps(kw) + "\n")
    sys.stdout.flush()


def opt(name, default=""):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv[:-1] else default


class MicError(Exception):
    pass


class SoundDeviceRecorder:
    kind = "sounddevice"

    def __init__(self, device):
        import numpy as np
        import sounddevice as sd
        self.np, self.sd, self.chunks, self.level = np, sd, [], 0.0
        dev = device or None
        if dev is not None:
            try:
                sd.query_devices(dev, "input")
            except Exception:
                emit(event="note", message=f"microphone {device!r} not found; using the standard one")
                dev = None
        try:
            sd.check_input_settings(device=dev, samplerate=RATE, channels=1, dtype="float32")
            self.rate = RATE
        except Exception:
            self.rate = int(sd.query_devices(dev, "input")["default_samplerate"])
        self.stream = sd.InputStream(device=dev, samplerate=self.rate, channels=1, dtype="float32", callback=self.got)

    def got(self, data, frames, when, status):
        mono = data[:, 0].copy()
        self.chunks.append(mono)
        if len(mono):
            self.level = float(self.np.sqrt(self.np.mean(mono * mono)))

    def start(self):
        self.stream.start()

    def stop(self):
        self.stream.stop()
        self.stream.close()
        np = self.np
        audio = np.concatenate(self.chunks) if self.chunks else np.zeros(0, np.float32)
        if self.rate != RATE and len(audio):
            n = int(len(audio) * RATE / self.rate)
            audio = np.interp(np.linspace(0, len(audio) - 1, n), np.arange(len(audio)), audio).astype(np.float32)
        return audio


class ArecordRecorder:
    """Linux fallback when PortAudio (the libportaudio2 package) is missing: ALSA's own arecord, raw samples on a pipe."""
    kind = "arecord"

    def __init__(self, device):
        import numpy as np
        self.np, self.buf, self.level = np, bytearray(), 0.0
        self.cmd = ["arecord", "-q", "-f", "S16_LE", "-r", str(RATE), "-c", "1", "-t", "raw"] + (["-D", device] if device else [])

    def start(self):
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.reader = threading.Thread(target=self.read, daemon=True)
        self.reader.start()
        time.sleep(0.3)
        if self.proc.poll() is not None and not self.buf:
            raise MicError(self.proc.stderr.read().decode(errors="replace").strip() or "arecord couldn't start")

    def read(self):
        while True:
            data = self.proc.stdout.read(3200)          # 0.1 s
            if not data:
                return
            self.buf += data
            s = self.np.frombuffer(data[: len(data) // 2 * 2], self.np.int16).astype(self.np.float32) / 32768
            if len(s):
                self.level = float(self.np.sqrt(self.np.mean(s * s)))

    def stop(self):
        self.proc.terminate()                           # arecord finishes cleanly on SIGTERM (its exit code is nonzero)
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.reader.join(timeout=3)
        n = len(self.buf) // 2 * 2
        return self.np.frombuffer(bytes(self.buf[:n]), self.np.int16).astype(self.np.float32) / 32768


class FileRecorder:
    """For tests (--fake-audio WAV): plays a WAV file in as if it were being spoken, at real speed."""
    kind = "file"

    def __init__(self, path):
        import numpy as np
        self.np, self.audio, self.started = np, read_wav(path), time.time()

    def start(self):
        self.started = time.time()

    def played(self):
        return min(len(self.audio), int((time.time() - self.started) * RATE))

    @property
    def level(self):
        chunk = self.audio[max(0, self.played() - 1600): self.played()]
        return float(self.np.sqrt(self.np.mean(chunk * chunk))) if len(chunk) else 0.0

    def stop(self):
        return self.audio[: self.played()]


def read_wav(path):
    import wave
    import numpy as np
    with wave.open(path) as w:
        rate, width, chans = w.getframerate(), w.getsampwidth(), w.getnchannels()
        raw = w.readframes(w.getnframes())
    if width != 2:
        raise ValueError("only 16-bit WAV files")
    audio = np.frombuffer(raw, np.int16).astype(np.float32).reshape(-1, chans).mean(axis=1) / 32768
    if rate != RATE:
        n = int(len(audio) * RATE / rate)
        audio = np.interp(np.linspace(0, len(audio) - 1, n), np.arange(len(audio)), audio).astype(np.float32)
    return audio


def make_recorder(device):
    if opt("--fake-audio"):
        return FileRecorder(opt("--fake-audio"))
    try:
        return SoundDeviceRecorder(device)
    except Exception as e:
        if sys.platform.startswith("linux") and shutil.which("arecord"):
            return ArecordRecorder(device)
        raise MicError(str(e) or type(e).__name__)


def load_model(path, threads):
    from pywhispercpp.model import Model
    return Model(path, n_threads=threads, redirect_whispercpp_logs_to=None, print_progress=False, print_realtime=False)


def transcribe(model, audio, prompt):
    params = {"no_context": True, "language": "en"}
    if prompt:
        params["initial_prompt"] = prompt
    return " ".join(s.text.strip() for s in model.transcribe(audio, **params)).strip()


def check():
    import numpy  # noqa: F401
    import pywhispercpp.model  # noqa: F401
    recorder, note = "", ""
    try:
        import sounddevice  # noqa: F401
        recorder = "sounddevice"
    except Exception as e:
        note = f"sounddevice unavailable ({e})"
        if sys.platform.startswith("linux") and shutil.which("arecord"):
            recorder = "arecord"
        elif sys.platform.startswith("linux"):
            note += "; install libportaudio2 (or alsa-utils)"
    emit(event="check", recorder=recorder, note=note)


def devices():
    names = []
    try:
        import sounddevice as sd
        for d in sd.query_devices():
            if d["max_input_channels"] > 0 and d["name"] not in names:
                names.append(d["name"])
    except Exception as e:
        emit(event="note", message=f"couldn't list microphones: {e}")
    emit(event="devices", devices=names)


def transcribe_file(path):
    audio = read_wav(path)
    model = load_model(opt("--model"), int(opt("--threads", "4")))
    t = time.time()
    emit(event="result", text=transcribe(model, audio, opt("--prompt")), seconds=round(len(audio) / RATE, 1),
         took=round(time.time() - t, 2))


def dictate():
    loaded = {}

    def loader():                                       # load the model while the person is still talking
        try:
            loaded["model"] = load_model(opt("--model"), int(opt("--threads", "4")))
        except Exception as e:
            loaded["error"] = e
    threading.Thread(target=loader, daemon=True).start()

    try:
        rec = make_recorder(opt("--device") or None)
        rec.start()
    except Exception as e:
        emit(event="error", code="microphone", message=str(e))
        return
    emit(event="recording", recorder=rec.kind)
    stop, cancelled = threading.Event(), threading.Event()

    def listen():
        for line in sys.stdin:
            if line.strip() == "cancel":
                cancelled.set()
            if line.strip() in ("stop", "cancel"):
                break
        else:
            cancelled.set()                             # Quickpad went away: nobody is waiting for the words
        stop.set()
    threading.Thread(target=listen, daemon=True).start()

    start, limit = time.time(), float(opt("--max-seconds", "180"))
    while not stop.wait(0.1):
        emit(event="level", level=round(rec.level, 5), seconds=round(time.time() - start, 1))
        if time.time() - start >= limit:
            emit(event="note", message=f"stopped listening after {limit:g} s")
            break
    audio = rec.stop()
    if cancelled.is_set():
        emit(event="cancelled")
        return
    seconds = len(audio) / RATE
    peak = float(abs(audio).max()) if len(audio) else 0.0
    emit(event="working", seconds=round(seconds, 1), peak=round(peak, 5))
    if seconds < float(opt("--min-seconds", "0.6")):
        emit(event="error", code="short", message=f"only {seconds:.1f} s recorded")
        return
    if peak < float(opt("--silent-peak", "0.002")):
        emit(event="error", code="silent", message=f"loudest sound {peak:.5f}")
        return
    while "model" not in loaded and "error" not in loaded:
        time.sleep(0.05)
    if "error" in loaded:
        raise loaded["error"]
    t = time.time()
    emit(event="result", text=transcribe(loaded["model"], audio, opt("--prompt")), seconds=round(seconds, 1),
         took=round(time.time() - t, 2))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "check"
    try:
        if mode == "check":
            check()
        elif mode == "devices":
            devices()
        elif mode == "file":
            transcribe_file(opt("--file"))
        elif mode == "dictate":
            dictate()
        else:
            emit(event="error", code="failed", message=f"unknown mode {mode}")
    except Exception as e:
        traceback.print_exc()
        emit(event="error", code="failed", message=f"{type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
'''


class HoverTip:
    """A small note that appears when the pointer rests on a widget for a moment."""

    def __init__(self, widget, get_text, enabled=lambda: True, delay=650):
        self.widget, self.get_text, self.enabled, self.delay = widget, get_text, enabled, delay
        self.job, self.tip = None, None
        widget.bind("<Enter>", self.schedule, add="+")
        for ev in ("<Leave>", "<ButtonPress>", "<Destroy>", "<KeyPress>"):
            widget.bind(ev, self.hide, add="+")

    def schedule(self, _e=None):
        self.hide()
        self.job = self.widget.after(self.delay, self.show)

    def show(self):
        self.hide()      # never leave an earlier tip (or a still-pending one) behind
        try:
            if not self.enabled() or not self.widget.winfo_exists():
                return
            text = self.get_text()
            if not text:
                return
            tip = tk.Toplevel(self.widget)
            tip.overrideredirect(True)
            tip.attributes("-topmost", True)
            frame = tk.Frame(tip, bg=EDGE, padx=1, pady=1)
            frame.pack()
            tk.Label(frame, text=text, bg=CARD, fg=INK, justify="left", anchor="w", padx=10, pady=8, wraplength=320,
                     font=("TkDefaultFont", 10)).pack()
            tip.update_idletasks()
            w, h = tip.winfo_reqwidth(), tip.winfo_reqheight()
            sw, sh_ = tip.winfo_screenwidth(), tip.winfo_screenheight()
            x = min(self.widget.winfo_rootx() + 24, max(0, sw - w - 4))
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
            if y + h > sh_:
                y = max(0, self.widget.winfo_rooty() - h - 4)
            tip.geometry(f"+{x}+{y}")
            self.tip = tip
        except tk.TclError:
            self.tip = None

    def hide(self, _e=None):
        if self.job:
            try:
                self.widget.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        if self.tip is not None:
            try:
                self.tip.destroy()
            except tk.TclError:
                pass
            self.tip = None


class WhatsNewDialog(tk.Toplevel):
    """Plain-words list of what changed, shown once after an update."""

    def __init__(self, parent, entries):
        super().__init__(parent)
        self.title(f"{APP} — What's new")
        self.attributes("-topmost", True)
        self.configure(bg=APP_BG)
        self.geometry("560x520")
        self.minsize(420, 320)
        ttk.Label(self, text=f"Quickpad is now version {VERSION}", font=("TkDefaultFont", 14, "bold"),
                  padding=(16, 14, 16, 2)).pack(anchor="w")
        ttk.Label(self, text="Here is what has changed.", foreground=MUTED, padding=(16, 0, 16, 8)).pack(anchor="w")
        body = tk.Text(self, wrap="word", relief="flat", padx=16, pady=4, font=("TkDefaultFont", 11), bg=APP_BG, fg=INK,
                       highlightthickness=0, cursor="arrow", spacing3=4)
        sb = ttk.Scrollbar(self, orient="vertical", command=body.yview)
        body.configure(yscrollcommand=sb.set)
        bottom = ttk.Frame(self, padding=14)
        bottom.pack(side="bottom", fill="x")
        ttk.Button(bottom, text="Got it", style="Big.TButton", command=self.destroy).pack(side="right")
        sb.pack(side="right", fill="y")
        body.pack(fill="both", expand=True)
        body.tag_configure("ver", font=("TkDefaultFont", 12, "bold"), spacing1=10, spacing3=4)
        for ver, items in entries:
            body.insert("end", f"Version {ver}\n", "ver")
            for it in items:
                body.insert("end", "•  " + it + "\n")
        body.configure(state="disabled")
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.destroy())


# ================================================================ config + backups

# ---- buttons file, version 2 (docs/SPEC-3.3.md §1). Every family, button, saved list and workflow has a permanent id
# and an `updated` time (milliseconds), and deleting something leaves a dated tombstone in `deleted`. That is what lets
# two copies of the buttons (two computers, a phone, an imported setup) be combined later without losing anyone's edits.
CONFIG_VERSION = 2
SYNC_KEYS = ("config_version", "layout", "families", "lists", "workflows", "deleted")
ID_PREFIX = {"family": "f_", "button": "b_", "list": "l_", "workflow": "w_"}
AFTER_CHOICES = ("default", "stay", "next", "previous", "first")


def now_ms():
    return int(time.time() * 1000)


def new_id(kind):
    """A fresh permanent id: f_ / b_ / l_ / w_ and 16 random lower-case hex characters."""
    return ID_PREFIX[kind] + secrets.token_hex(8)


def _as_ms(v):
    try:
        return max(0, int(v or 0))
    except (TypeError, ValueError):
        return 0


def normalise(raw):
    """Fill in anything missing so the rest of Quickpad can rely on it. Keys this version doesn't know about (written by
    a newer Quickpad, or by the phone app) are kept as they are, never dropped."""
    out = {"config_version": CONFIG_VERSION}
    settings = {**DEFAULT_CONFIG["settings"], **(raw.get("settings") or {})}
    families = [f for f in raw.get("families") or [] if isinstance(f, dict)]
    for f in families:
        f.setdefault("name", "Untitled")
        f.setdefault("colour", PALETTE[0])
        f["buttons"] = [b for b in f.get("buttons") or [] if isinstance(b, dict)]
        f.setdefault("columns", 1)     # buttons per row in this group
        f.setdefault("size", "")       # "" = use the global text size; else small / normal / large / xlarge
        f["updated"] = _as_ms(f.get("updated"))
        for b in f["buttons"]:
            b.setdefault("label", "Button")
            b.setdefault("steps", [])
            if b.get("after") not in AFTER_CHOICES:
                b["after"] = "default"   # what a workflow does after this button (SPEC-3.3 §4)
            b["updated"] = _as_ms(b.get("updated"))
    lists = []
    for lst in raw.get("lists") or []:
        if not isinstance(lst, dict):
            continue
        items = []
        for it in lst.get("items") or []:
            if isinstance(it, str):
                it = {"label": it}
            if isinstance(it, dict) and (str(it.get("label", "")).strip() or str(it.get("value", "")).strip()):
                items.append(it)
        lst["items"] = items
        lst["name"] = str(lst.get("name") or "List")
        lst["updated"] = _as_ms(lst.get("updated"))
        lists.append(lst)
    workflows = []
    for wf in raw.get("workflows") or []:
        if isinstance(wf, dict):
            wf.setdefault("name", "Workflow")
            wf["steps"] = [s for s in wf.get("steps") or [] if isinstance(s, dict)]
            wf.setdefault("loop", True)
            wf.setdefault("auto_advance", True)
            wf["updated"] = _as_ms(wf.get("updated"))
            workflows.append(wf)
    deleted = {}
    raw_deleted = raw.get("deleted") if isinstance(raw.get("deleted"), dict) else {}
    for k, v in raw_deleted.items():
        if isinstance(k, str) and k:
            deleted[k] = _as_ms(v)
    layout = raw.get("layout") if isinstance(raw.get("layout"), dict) else {}
    out.update(settings=settings, layout={**layout, "updated": _as_ms(layout.get("updated"))}, families=families,
               lists=lists, workflows=workflows, deleted=deleted)
    for k, v in raw.items():
        if k not in out:
            out[k] = v
    return out


def _all_objects(cfg):
    """(kind, object) for every family, button, saved list and workflow in a config or sync doc."""
    for f in cfg.get("families") or []:
        if isinstance(f, dict):
            yield "family", f
            for b in f.get("buttons") or []:
                if isinstance(b, dict):
                    yield "button", b
    for kind, key in (("list", "lists"), ("workflow", "workflows")):
        for x in cfg.get(key) or []:
            if isinstance(x, dict):
                yield kind, x


def ensure_ids(cfg, now=None):
    """Give everything that has no id one (and an `updated` time: `now`, or 0 when migrating an old file so that any
    real edit elsewhere wins). Ids are never changed, except that a second object carrying the same id as an earlier
    one (a copy made without a new id) gets its own. Used on load, import, restore and every save. Returns True if it
    changed anything."""
    seen, changed = set(), False
    for kind, x in _all_objects(cfg):
        i = x.get("id")
        if not isinstance(i, str) or not i or i in seen:
            x["id"] = i = new_id(kind)
            x["updated"] = now or 0
            changed = True
        elif "updated" not in x:
            x["updated"] = now or 0
            changed = True
        seen.add(i)
        if kind == "button" and x.get("after") not in AFTER_CHOICES:
            x["after"] = "default"
            changed = True
    for key, default in (("lists", []), ("workflows", []), ("deleted", {}), ("layout", {"updated": 0})):
        if not isinstance(cfg.get(key), type(default)):
            cfg[key] = copy.deepcopy(default)
            changed = True
    if cfg.get("config_version") != CONFIG_VERSION:
        cfg["config_version"] = CONFIG_VERSION
        changed = True
    return changed


def fresh_ids(obj, kind):
    """A copy (Duplicate, Make a copy, Copy to another family) is a new thing: new ids for it and its buttons."""
    obj["id"] = new_id(kind)
    obj["updated"] = now_ms()
    if kind == "family":
        for b in obj.get("buttons", []):
            fresh_ids(b, "button")
    return obj


def touch_button(b, now=None):
    """Anything about this button changed (label, steps, shortcut, symbol, after…)."""
    b["updated"] = now or now_ms()


def touch_family(f, now=None):
    """The family's name/colour/size/columns changed, or a button was added to, removed from or moved within it."""
    f["updated"] = now or now_ms()


def touch_list(lst, now=None):
    """Anything about this saved list changed (its name or items)."""
    lst["updated"] = now or now_ms()


def touch_workflow(wf, now=None):
    """Anything about this workflow changed (its name, steps, loop or move-on setting)."""
    wf["updated"] = now or now_ms()


def touch_layout(cfg, now=None):
    """A family, saved list or workflow was added, removed or reordered."""
    cfg.setdefault("layout", {})["updated"] = now or now_ms()


def tombstone(cfg, obj, now=None):
    """Remember that this was deleted, so a sync or merge doesn't bring it back. A family takes its buttons with it.
    The caller removes the object itself."""
    now = now or now_ms()
    dead = cfg.setdefault("deleted", {})
    if obj.get("id"):
        dead[obj["id"]] = now
    for b in obj.get("buttons") or []:
        if isinstance(b, dict) and b.get("id"):
            dead[b["id"]] = now


def _ids(items):
    return [x.get("id") for x in items or [] if isinstance(x, dict) and x.get("id")]


def stamp_changes(before, after, now=None):
    """The safety net behind the touch_* helpers, run on every save: compare with what was saved last time, bump
    `updated` on anything whose content changed while its `updated` didn't, and tombstone anything that vanished
    without one. Something whose `updated` already differs (edited and touched, or brought in by a merge with the
    other side's time) is left alone, so a merge never makes old edits look new."""
    now = now or now_ms()

    def same(a, b, skip):
        return {k: v for k, v in a.items() if k not in skip} == {k: v for k, v in b.items() if k not in skip}

    def untouched(new, old):
        return _as_ms(new.get("updated")) == _as_ms(old.get("updated"))

    old_fams = {f["id"]: f for f in before.get("families") or [] if isinstance(f, dict) and f.get("id")}
    old_btns = {}
    for f in old_fams.values():
        for b in f.get("buttons") or []:
            if isinstance(b, dict) and b.get("id"):
                old_btns.setdefault(b["id"], (b, f["id"]))
    for f in after.get("families") or []:
        old = old_fams.get(f.get("id"))
        if old is not None and untouched(f, old) and (
                _ids(f.get("buttons")) != _ids(old.get("buttons")) or not same(f, old, ("updated", "buttons"))):
            f["updated"] = now
        for b in f.get("buttons") or []:
            prev = old_btns.get(b.get("id"))
            if prev is not None and untouched(b, prev[0]) and (
                    prev[1] != f.get("id") or not same(b, prev[0], ("updated",))):
                b["updated"] = now                     # changed, or moved to another family
    for key in ("lists", "workflows"):
        old = {x["id"]: x for x in before.get(key) or [] if isinstance(x, dict) and x.get("id")}
        for x in after.get(key) or []:
            prev = old.get(x.get("id"))
            if prev is not None and untouched(x, prev) and not same(x, prev, ("updated",)):
                x["updated"] = now
    if any(_ids(before.get(k)) != _ids(after.get(k)) for k in ("families", "lists", "workflows")):
        if untouched(after.get("layout") or {}, before.get("layout") or {}):
            touch_layout(after, now)
    had = {x.get("id") for _, x in _all_objects(before) if x.get("id")}
    has = {x.get("id") for _, x in _all_objects(after) if x.get("id")}
    dead = after.setdefault("deleted", {})
    for i in had - has:
        dead.setdefault(i, now)


def canonicalise(cfg):
    """Fill in the defaults normalise() gives on load (a family's columns/size, a button's after, ...) in place,
    keeping the same family/button objects. Things made since the file was loaded (Edit buttons' New family, the
    Computer help family, imports) can lack them until the next restart, and two copies that differ only by those
    defaults must still compare equal: otherwise a hub serves one shape while the computers syncing with it store
    another, and the copies never match. Returns cfg."""
    out = normalise({k: cfg[k] for k in SYNC_KEYS if k in cfg})
    for k in SYNC_KEYS:
        cfg[k] = out[k]
    return cfg


def sync_doc(cfg):
    """What two copies of the buttons share: everything except this computer's settings (SPEC-3.3 §1), in the
    canonical shape (see canonicalise), so the hub, desktop clients and phones all hold exactly the same doc."""
    return canonicalise({k: copy.deepcopy(cfg[k]) for k in SYNC_KEYS if k in cfg})


def apply_sync_doc(cfg, doc):
    """Put a merged or received sync doc into this computer's config, keeping its own settings. Changes cfg and
    returns it."""
    doc = normalise({**copy.deepcopy(doc), "settings": cfg.get("settings", {})})
    ensure_ids(doc)
    for k in SYNC_KEYS:
        cfg[k] = doc[k]
    return cfg


# ---- merging two copies of the buttons (sync, Import › Merge). A straight port of scripts/sync_reference.py::merge,
# which is the definition: tests/fixtures/sync-vectors.json checks that this gives exactly the same answers.
TOMBSTONE_DAYS = 90
DAY_MS = 86_400_000


def _by_id(items):
    return {x["id"]: x for x in items if isinstance(x, dict) and x.get("id")}


def _upd(x):
    try:
        return int(x.get("updated", 0) or 0)
    except (TypeError, ValueError):
        return 0


def _pick(a, b):
    """The newer of two versions of one object. Ties go to `a` (the side doing the merge)."""
    if a is None:
        return b
    if b is None:
        return a
    return a if _upd(a) >= _upd(b) else b


def _dead(obj, tomb):
    return obj["id"] in tomb and tomb[obj["id"]] >= _upd(obj)


def _ordered_ids(winner_items, loser_items, keep):
    out, seen = [], set()
    for src in (winner_items, loser_items):
        for x in src:
            i = x.get("id") if isinstance(x, dict) else None
            if i in keep and i not in seen:
                seen.add(i)
                out.append(i)
    return out


def merge_docs(local, incoming, now_ms=None):
    """Merge sync doc `incoming` into sync doc `local` (SPEC-3.3 §2). Pure: neither input is changed. Newer edits win
    per family, button, list and workflow; deletions win over older edits; with `now_ms`, tombstones over 90 days old
    are dropped."""
    a, b = copy.deepcopy(local or {}), copy.deepcopy(incoming or {})
    tomb = {}
    for side in (a, b):
        for k, v in (side.get("deleted") or {}).items():
            try:
                v = int(v)
            except (TypeError, ValueError):
                continue
            tomb[k] = max(tomb.get(k, 0), v)

    la, lb = _upd(a.get("layout") or {}), _upd(b.get("layout") or {})
    win, lose = (a, b) if la >= lb else (b, a)

    # families: their properties and their button order come from the newer version
    fa, fb = _by_id(a.get("families", [])), _by_id(b.get("families", []))
    fams = {}
    for fid in set(fa) | set(fb):
        f = _pick(fa.get(fid), fb.get(fid))
        if not _dead(f, tomb):
            fams[fid] = f

    # buttons: content from the newer button
    def button_index(doc):
        idx = {}
        for fam in doc.get("families", []):
            if not isinstance(fam, dict):
                continue
            for pos, btn in enumerate(fam.get("buttons", [])):
                if isinstance(btn, dict) and btn.get("id") and btn["id"] not in idx:
                    idx[btn["id"]] = (btn, fam.get("id"), pos)
        return idx

    ba, bb = button_index(a), button_index(b)
    buttons, home = {}, {}
    for bid in set(ba) | set(bb):
        va, vb = ba.get(bid), bb.get(bid)
        btn = _pick(va[0] if va else None, vb[0] if vb else None)
        if _dead(btn, tomb):
            continue
        buttons[bid] = btn
        # Where it lives if no family's list claims it: the side whose button version won.
        primary = va if (va and btn is va[0]) else vb
        other = vb if primary is va else va
        home[bid] = [primary[1], primary[2]] + ([other[1]] if other else [])

    fam_order = _ordered_ids(win.get("families", []), lose.get("families", []), fams)
    placed, out_fams = set(), []
    for fid in fam_order:
        f = copy.deepcopy(fams[fid])
        ids = []
        for btn in f.get("buttons", []):
            bid = btn.get("id") if isinstance(btn, dict) else None
            if bid in buttons and bid not in placed:
                placed.add(bid)
                ids.append(bid)
        f["_ids"] = ids
        out_fams.append(f)

    by_fid = {f["id"]: f for f in out_fams}
    leftovers = sorted((bid for bid in buttons if bid not in placed), key=lambda i: (home[i][1], i))
    for bid in leftovers:
        for fid in [home[bid][0]] + home[bid][2:]:
            if fid in by_fid:
                by_fid[fid]["_ids"].append(bid)
                placed.add(bid)
                break
    for f in out_fams:
        f["buttons"] = [copy.deepcopy(buttons[i]) for i in f.pop("_ids")]

    # saved lists and workflows: whole-object, newest wins
    def merge_flat(key):
        xa, xb = _by_id(a.get(key, [])), _by_id(b.get(key, []))
        keep = {}
        for i in set(xa) | set(xb):
            x = _pick(xa.get(i), xb.get(i))
            if not _dead(x, tomb):
                keep[i] = x
        return [copy.deepcopy(keep[i]) for i in _ordered_ids(win.get(key, []), lose.get(key, []), keep)]

    if now_ms is not None:
        tomb = {k: v for k, v in tomb.items() if now_ms - v <= TOMBSTONE_DAYS * DAY_MS}

    return {
        "config_version": CONFIG_VERSION,
        "layout": {"updated": max(la, lb)},
        "families": out_fams,
        "lists": merge_flat("lists"),
        "workflows": merge_flat("workflows"),
        "deleted": dict(sorted(tomb.items())),
    }


# ---- sealed boxes: encryption + tamper check for sync messages on the clinic's own network (SPEC-3.3 §6.3), built
# only from HMAC-SHA256 in the standard library, exactly as scripts/sync_reference.py::seal / open_sealed define it.
def _box_keys(token):
    t = token.encode("utf-8")
    return (hmac.new(t, b"quickpad-sync-enc-v1", hashlib.sha256).digest(),
            hmac.new(t, b"quickpad-sync-mac-v1", hashlib.sha256).digest())


def _box_stream(enc_key, nonce, n):
    out, i = bytearray(), 0
    while len(out) < n:
        out += hmac.new(enc_key, nonce + i.to_bytes(8, "big"), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def seal_box(token, data, nonce=None):
    """Encrypt and sign `data` (bytes) with a paired device's token. A fresh random nonce every time unless one is
    given (only the tests give one, to check against the reference vectors)."""
    nonce = nonce if nonce is not None else secrets.token_bytes(16)
    enc_key, mac_key = _box_keys(token)
    ct = bytes(x ^ y for x, y in zip(data, _box_stream(enc_key, nonce, len(data))))
    tag = hmac.new(mac_key, nonce + ct, hashlib.sha256).digest()
    b64 = lambda x: base64.b64encode(x).decode("ascii")      # noqa: E731
    return {"v": 1, "nonce": b64(nonce), "ct": b64(ct), "tag": b64(tag)}


def open_box(token, box):
    """The bytes inside a sealed box. Raises ValueError if it's malformed, was made with a different token, or was
    changed on the way (the tag is checked, in constant time, before anything is decrypted)."""
    try:
        if not isinstance(box, dict) or box.get("v") != 1:
            raise ValueError("bad box")
        nonce, ct, tag = (base64.b64decode(box[k], validate=True) for k in ("nonce", "ct", "tag"))
    except (KeyError, TypeError, binascii.Error) as e:
        raise ValueError("bad box") from e
    if len(nonce) != 16:
        raise ValueError("bad box")
    enc_key, mac_key = _box_keys(token)
    if not hmac.compare_digest(tag, hmac.new(mac_key, nonce + ct, hashlib.sha256).digest()):
        raise ValueError("bad tag")
    return bytes(x ^ y for x, y in zip(ct, _box_stream(enc_key, nonce, len(ct))))


def _read_saved_config():
    """What's in the buttons file right now (for stamp_changes), or None."""
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        return raw if isinstance(raw, dict) else None
    except (OSError, ValueError):
        return None


def load_config():
    """Returns (config, ok). ok=False means the file was unreadable and must not be overwritten silently."""
    if not os.path.exists(CONFIG_PATH):
        cfg = normalise(copy.deepcopy(DEFAULT_CONFIG))
        seed_actions(cfg)
        ensure_ids(cfg, now_ms())
        save_config(cfg)
        return cfg, True
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            raise ValueError("it doesn't contain Quickpad buttons")
    except (OSError, ValueError) as e:
        messagebox.showerror(APP, f"Couldn't read {CONFIG_PATH}:\n{e}\n\n"
                                  f"Showing the default buttons. Your file hasn't been changed. "
                                  f"Dated backups are in {LOCAL_BACKUP_DIR}; use Import in the editor to restore one.")
        cfg = normalise(copy.deepcopy(DEFAULT_CONFIG))
        ensure_ids(cfg)
        return cfg, False
    migrating = raw.get("config_version") != CONFIG_VERSION     # a 3.2 or older file: saved as version 2 now
    upgraded = upgrade_to_31(raw) | upgrade_ai_layout(raw)
    cfg = normalise(raw)
    changed = seed_actions(cfg) | upgrade_starter_dictate(cfg) | upgraded
    if ensure_ids(cfg) | migrating | changed:
        try:
            save_config(cfg)
        except OSError:
            pass
    return cfg, True


def save_config(cfg, stamp=True):
    """Write the buttons file safely (a .bak of the old one, then an atomic replace). New things get ids, and anything
    changed since the last save gets its `updated` time (see stamp_changes) — except with stamp=False, used for a
    sync result, which is already exactly what both sides should have."""
    now = now_ms()
    ensure_ids(cfg, now)
    before = _read_saved_config() if stamp else None
    if before and before.get("config_version") == CONFIG_VERSION:     # an older file has no ids to compare with
        stamp_changes(before, cfg, now)
    os.makedirs(CONFIG_DIR, exist_ok=True)
    if os.path.exists(CONFIG_PATH):
        shutil.copy2(CONFIG_PATH, CONFIG_PATH + ".bak")
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, CONFIG_PATH)


def backup_dirs(cfg):
    dirs = [LOCAL_BACKUP_DIR]
    extra = cfg["settings"].get("backup_dir", "").strip()
    if extra:
        dirs.append(os.path.expanduser(extra))
    return dirs


def write_backup(cfg):
    """Write a dated copy to the local backups folder and the chosen backup folder. Returns errors."""
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    errors = []
    for d in backup_dirs(cfg):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, f"quickpad-backup-{stamp}.json"), "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2, ensure_ascii=False)
            old = sorted(glob.glob(os.path.join(d, "quickpad-backup-*.json")))
            for p in old[:-KEEP_BACKUPS]:
                os.remove(p)
        except OSError as e:
            errors.append(f"{d}: {e}")
    return errors


def latest_backup_age_hours():
    files = sorted(glob.glob(os.path.join(LOCAL_BACKUP_DIR, "quickpad-backup-*.json")))
    if not files:
        return None
    return (time.time() - os.path.getmtime(files[-1])) / 3600


def count_buttons(cfg):
    return sum(len(f["buttons"]) for f in cfg["families"])


SETUP_EXT = ".quickpad"      # Export setup… writes this; Import setup… also reads the older .json backups


def platform_name():
    """linux / windows / mac, as written in an exported setup (the phone app writes android)."""
    if IS_MAC:
        return "mac"
    return "windows" if sys.platform.startswith("win") else "linux"


def build_export(cfg):
    """The full portable copy (SPEC-3.3 §5): every family, button, saved list, workflow, id and setting, minus the
    settings that belong to this computer (window position, folders, password, microphone…)."""
    data = copy.deepcopy(cfg)
    for k in MACHINE_SETTINGS:
        data["settings"].pop(k, None)
    data["exported"] = {"app": APP, "version": VERSION, "at": datetime.datetime.now().isoformat(timespec="seconds"),
                        "platform": platform_name()}
    return data


def setup_counts(cfg):
    """(families, buttons, saved lists, workflows)."""
    return (len(cfg.get("families") or []), count_buttons(cfg), len(cfg.get("lists") or []),
            len(cfg.get("workflows") or []))


def write_export(cfg, path):
    """Write a setup file (or a full backup), then read it back to prove it's complete. Returns (families, buttons)."""
    data = build_export(cfg)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    try:
        back = load_backup_file(path)
    except ValueError as e:
        raise OSError(f"the saved file couldn't be read back: {e}")
    same_ids = _ids(back.get("families")) == _ids(cfg.get("families")) or not all(
        f.get("id") for f in cfg.get("families") or [])           # (ids are only added to a copy without them)
    if setup_counts(back) != setup_counts(cfg) or not same_ids:
        raise OSError("the saved file didn't match what was in Quickpad")
    return len(back["families"]), count_buttons(back)


def load_backup_file(path, info=None):
    """Read and normalise a setup file (.quickpad) or backup (.json). Raises ValueError with a readable reason. When
    `info` (a dict) is given, it gets the file's `exported` description (app, version, at, platform), if any."""
    try:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ValueError(str(e))
    if not isinstance(raw, dict) or not isinstance(raw.get("families"), list):
        raise ValueError("this file doesn't contain Quickpad families")
    exported = raw.pop("exported", None)        # describes the file, not the buttons
    if info is not None and isinstance(exported, dict):
        info.update(exported)
    upgrade_ai_layout(raw)           # an older backup keeps the note layout it had
    cfg = normalise(raw)
    ensure_ids(cfg)                  # an older backup has no ids yet: they're added the same way as on load
    return cfg


def restore_into(current, incoming, replace, now=None):
    """Import a setup file or backup (SPEC-3.3 §5). Returns the new config; neither input is changed.

    Replace everything: the file's buttons, lists, workflows and settings (this computer's own settings are kept).
    Everything restored is stamped *now* and everything that was here but isn't in the file gets a tombstone, so the
    replacement also wins on other computers or phones that sync with this one later, instead of their older copies
    of the replaced buttons quietly coming back.

    Merge: merge_docs() with the file as the incoming side, so per family, button, list and workflow the newer edit
    wins and deletions stick. Settings stay as they are here. Something that only came from the file and has the same
    name as a family, list or workflow here gets " (imported)" added, so the two can be told apart."""
    now = now or now_ms()
    incoming = copy.deepcopy(incoming)
    ensure_ids(incoming)                        # an old backup has no ids yet; merging needs them
    if replace:
        out = incoming
        for k in MACHINE_SETTINGS:   # window position and folder paths belong to this computer, not the backup
            out["settings"][k] = current["settings"].get(k, "")
        keep = set()
        for _, x in _all_objects(out):
            x["updated"] = now
            keep.add(x["id"])
        out["layout"] = {**(out.get("layout") or {}), "updated": now}
        dead = {}
        for side in (current, incoming):
            for k, v in (side.get("deleted") or {}).items():
                dead[k] = max(dead.get(k, 0), _as_ms(v))
        for _, x in _all_objects(current):
            if x.get("id") and x["id"] not in keep:
                dead[x["id"]] = now
        out["deleted"] = {k: v for k, v in dead.items() if k not in keep}
        return out
    mine = {x.get("id") for _, x in _all_objects(current)}
    out = apply_sync_doc(copy.deepcopy(current), merge_docs(sync_doc(current), sync_doc(incoming), now))
    for key in ("families", "lists", "workflows"):
        names = {str(x.get("name", "")).strip().lower() for x in out[key] if x.get("id") in mine}
        for x in out[key]:
            if x.get("id") in mine:
                continue
            name = str(x.get("name", ""))
            while name.strip().lower() in names:
                name += " (imported)"
            if name != x.get("name"):
                x["name"] = name
                x["updated"] = now
            names.add(name.strip().lower())
    return out


# ================================================================ updates

class UpdateError(Exception):
    pass


_UPDATE_HOSTS = {"gist.githubusercontent.com", "github.com", "objects.githubusercontent.com",
                  "release-assets.githubusercontent.com"}


class _SameHostRedirect(urllib.request.HTTPRedirectHandler):
    """Follow a redirect only onto a known update host. A GitHub Releases download (fetch_latest_app, the frozen
    Mac/Windows builds) always 302s to one of the githubusercontent.com CDN hosts, not github.com itself, so this
    can't just check against the request's own host - the signature check is what actually protects the update,
    this is only here to stop it being redirected somewhere unrelated."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u = urllib.parse.urlparse(newurl)
        if u.scheme != "https" or u.hostname not in _UPDATE_HOSTS or u.port not in (None, 443):
            return None
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def version_tuple(v):
    return tuple(int(p) for p in re.findall(r"\d+", v))


def _download(url):
    """Fetch `url` and return its raw bytes. Raises UpdateError with a plain-English message."""
    headers = {"User-Agent": f"{APP}/{VERSION}", "Cache-Control": "no-cache"}
    try:
        # Same certificates as the model downloads, so a Mac with python.org's Python can still update.
        opener = urllib.request.build_opener(_SameHostRedirect, urllib.request.HTTPSHandler(context=_download_ssl()))
        with opener.open(urllib.request.Request(url, headers=headers), timeout=15) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code == 429 or e.code == 403:
            raise UpdateError("The update server is busy. Try again in a few minutes.") from None
        if e.code == 404:
            raise UpdateError("The update source wasn't found. Please tell Nick.") from None
        raise UpdateError(f"The update server said {e.code}.") from None
    except (urllib.error.URLError, OSError):
        raise UpdateError("Couldn't reach the update server. Check the internet connection.") from None


def fetch_latest():
    """Download the latest quickpad.py from the update gist, checked against its signature. Returns (version, raw
    bytes). Raises UpdateError — including when the signature is missing or doesn't check out, so a compromised or
    tampered gist can never be installed automatically."""
    data = _download(UPDATE_URL)
    try:
        text = data.decode("utf-8")
        compile(text, "quickpad.py", "exec")
    except (UnicodeDecodeError, SyntaxError, ValueError):
        raise UpdateError("The downloaded update looks damaged, so it wasn't installed.")
    m = re.search(r'^VERSION = "([^"]+)"', text, re.M)
    if not m or "class Panel" not in text:
        raise UpdateError("The downloaded file isn't a Quickpad release, so it wasn't installed.")
    try:
        signature = _download(SIG_URL).decode("ascii", "ignore")
    except UpdateError:
        raise UpdateError("Couldn't check the update's signature, so it wasn't installed. Please tell Nick.") from None
    if not verify_release_signature(data, signature):
        raise UpdateError("The update's signature didn't check out, so it wasn't installed. Please tell Nick.")
    return m.group(1), data


def apply_update(data):
    """Swap the running script for the downloaded one, keeping the old copy so a bad update can be undone."""
    path = os.path.abspath(__file__)
    tmp = path + ".new"
    m = re.search(rb'^VERSION = "([^"]+)"', data, re.M)
    new_ver = m.group(1).decode() if m else "?"
    try:
        os.makedirs(LOCAL_DIR, exist_ok=True)
        shutil.copy2(path, PREVIOUS_PATH)
        with open(tmp, "wb") as f:
            f.write(data)
        shutil.copymode(path, tmp)
        # The first launch of the new version is watched (see _probation_guard), so the marker must exist before the
        # script is swapped; if it can't be written, the update doesn't happen rather than happening unprotected.
        with open(PENDING_PATH, "w", encoding="utf-8") as f:
            json.dump({"from": VERSION, "to": new_ver, "at": time.time()}, f)
        os.replace(tmp, path)
    except OSError as e:
        for leftover in (tmp, PENDING_PATH):
            try:
                os.remove(leftover)
            except OSError:
                pass
        raise UpdateError(f"Couldn't write the update to {path}: {e}")
    return path


def app_zip_version(data):
    """The running build's version, read straight out of a downloaded update zip without extracting the rest: the
    CFBundleShortVersionString inside Quickpad.app/Contents/Info.plist on Mac (which macOS needs anyway), or the
    plain Quickpad/VERSION.txt file on Windows (there's no Windows equivalent of Info.plist worth reading without
    extra dependencies). Raises ValueError if this isn't either shape of a Quickpad release zip."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            if "Quickpad.app/Contents/Info.plist" in names:
                with z.open("Quickpad.app/Contents/Info.plist") as f:
                    plist = plistlib.load(f)
                if plist.get("CFBundleIdentifier") != "com.praxentis.quickpad":
                    raise ValueError("not Quickpad's bundle identifier")
                ver = plist.get("CFBundleShortVersionString")
                if not ver:
                    raise ValueError("no version in Info.plist")
                return ver
            if "Quickpad/VERSION.txt" in names:
                ver = z.read("Quickpad/VERSION.txt").decode("utf-8", "ignore").strip()
                if not ver:
                    raise ValueError("no version in VERSION.txt")
                return ver
    except zipfile.BadZipFile as e:
        raise ValueError(f"not a zip file: {e}")
    raise ValueError("not a Quickpad release zip (neither the Mac nor the Windows shape)")


def fetch_latest_app():
    """Download the latest Quickpad-<platform>.zip (the frozen Mac or Windows build) from GitHub Releases, checked
    against its signature exactly like fetch_latest() does for the loose-script update. Returns (version, zip
    bytes)."""
    data = _download(app_update_url())
    try:
        ver = app_zip_version(data)
    except ValueError:
        raise UpdateError("The downloaded update isn't a Quickpad release, so it wasn't installed.")
    try:
        signature = _download(app_sig_url()).decode("ascii", "ignore")
    except UpdateError:
        raise UpdateError("Couldn't check the update's signature, so it wasn't installed. Please tell Nick.") from None
    if not verify_release_signature(data, signature):
        raise UpdateError("The update's signature didn't check out, so it wasn't installed. Please tell Nick.")
    return ver, data


def running_app_path():
    """The folder this frozen build is running from - the .app bundle root on Mac (e.g.
    /Users/alex/Applications/Quickpad.app), or the folder holding Quickpad.exe on Windows - or None if this isn't a
    frozen build, or its executable isn't where we expect."""
    if not getattr(sys, "frozen", False):
        return None
    if sys.platform.startswith("win"):
        return ntpath.dirname(sys.executable)
    # sys.executable is .../Quickpad.app/Contents/MacOS/Quickpad
    app_dir = os.path.dirname(os.path.dirname(os.path.dirname(sys.executable)))
    return app_dir if app_dir.endswith(".app") else None


def relauncher_script(app_path, update_zip_path, pid):
    """A small script that waits for `pid` (the running Quickpad) to quit, then replaces `app_path` with the
    downloaded update and reopens it. A running build's own files can't safely be replaced out from under it, so
    this runs as a separate detached process started just before Quickpad quits. Unzips to a staging folder first
    and only swaps it in once the new build's own executable is confirmed present, so a truncated download or a
    disk full partway through unzip leaves the old build in place instead of deleting Quickpad outright."""
    if sys.platform.startswith("win"):
        parent = ntpath.dirname(app_path)
        staging = ntpath.join(parent, ".quickpad-update-staging")
        staged_exe = ntpath.join(staging, "Quickpad", "Quickpad.exe")
        exe_path = ntpath.join(app_path, "Quickpad.exe")
        # Inside the PowerShell -Command string, these paths sit in single-quoted literals - double any embedded
        # ' or a Windows username containing one (e.g. O'Brien; LOCAL_DIR lives under %APPDATA%\<username>) would
        # end the literal early and Expand-Archive would fail.
        ps_zip = update_zip_path.replace("'", "''")
        ps_staging = staging.replace("'", "''")
        return f"""@echo off
:wait
tasklist /FI "PID eq {pid}" 2>NUL | find "{pid}" >NUL
if not errorlevel 1 (
    timeout /t 1 /nobreak >NUL
    goto wait
)
rmdir /s /q "{staging}" 2>NUL
mkdir "{staging}"
powershell -NoProfile -Command "$ErrorActionPreference = 'Stop'; try {{ Expand-Archive -Force -LiteralPath '{ps_zip}' -DestinationPath '{ps_staging}'; exit 0 }} catch {{ exit 1 }}"
if errorlevel 1 goto cleanup
if exist "{staged_exe}" (
    rmdir /s /q "{app_path}"
    if not errorlevel 1 (
        move "{staging}\\Quickpad" "{app_path}"
        if not errorlevel 1 (
            start "" "{exe_path}"
            rmdir /s /q "{staging}"
        )
    )
)
:cleanup
del "{update_zip_path}"
del "%~f0"
"""
    parent = os.path.dirname(app_path)
    staging = f"{parent}/.quickpad-update-staging"
    staged_exe = f"{staging}/Quickpad.app/Contents/MacOS/Quickpad"
    return f"""#!/bin/bash
while kill -0 {pid} 2>/dev/null; do sleep 0.2; done
rm -rf "{staging}"
mkdir -p "{staging}"
if unzip -oq "{update_zip_path}" -d "{staging}" && [ -x "{staged_exe}" ]; then
    rm -rf "{app_path}"
    mv "{staging}/Quickpad.app" "{app_path}"
    open "{app_path}"
fi
rm -rf "{staging}"
rm -f "{update_zip_path}"
rm -f "$0"
"""


def stage_app_update(data):
    """Write a downloaded Quickpad update zip and its relauncher script to this computer's local folder. Returns
    the relauncher script's path; the caller runs it (detached) just before quitting."""
    os.makedirs(LOCAL_DIR, exist_ok=True)
    zip_path = os.path.join(LOCAL_DIR, "quickpad-update.zip")
    with open(zip_path, "wb") as f:
        f.write(data)
    is_win = sys.platform.startswith("win")
    script_path = os.path.join(LOCAL_DIR, "quickpad-relauncher" + (".bat" if is_win else ".sh"))
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(relauncher_script(running_app_path(), zip_path, os.getpid()))
    if not is_win:
        os.chmod(script_path, 0o755)
    return script_path


def bad_versions():
    try:
        with open(BAD_VERSIONS_PATH, encoding="utf-8") as f:
            return {line.strip() for line in f if line.strip()}
    except OSError:
        return set()


# ================================================================ helpers: password, login start, position, shortcuts

def has_password(settings):
    return bool(settings.get("password_hash") and settings.get("password_salt"))


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    return salt.hex(), hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000).hex()


def password_ok(settings, attempt):
    """True if no password is set, or the attempt matches it. (A casual lock, not encryption.)"""
    if not has_password(settings):
        return True
    try:
        _, got = hash_password(attempt, bytes.fromhex(settings["password_salt"]))
    except ValueError:
        return False
    return hmac.compare_digest(got, settings["password_hash"])


def autostart_path():
    """Where the 'start when I log in' file lives, or '' if this system/mode can't do it."""
    if PORTABLE or IS_MAC:
        return ""
    if sys.platform.startswith("win"):
        return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs",
                            "Startup", "Quickpad.bat")
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "autostart",
                        "quickpad.desktop")


def autostart_enabled():
    path = autostart_path()
    return bool(path) and os.path.exists(path)


def set_autostart(on):
    path = autostart_path()
    if not path:
        raise OSError("Starting at login isn't available in this mode.")
    if not on:
        if os.path.exists(path):
            os.remove(path)
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    script = os.path.abspath(__file__)
    if sys.platform.startswith("win"):
        exe = sys.executable
        pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        text = f'@echo off\r\nstart "" "{pyw if os.path.exists(pyw) else exe}" "{script}"\r\n'
    else:
        def q(t):
            return '"' + t.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("`", "\\`") + '"'
        text = ("[Desktop Entry]\nType=Application\nName=Quickpad\nComment=Button panel that types text and keystrokes\n"
                f"Exec={q(sys.executable)} {q(script)}\nTerminal=false\nX-GNOME-Autostart-enabled=true\n"
                "X-GNOME-Autostart-Delay=3\n")
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


GEO_RE = re.compile(r"^(\d+)x(\d+)([+-])(-?\d+)([+-])(-?\d+)$")


def parse_geometry(geo):
    """'330x560+100+50' -> (330, 560, 100, 50), or None."""
    m = GEO_RE.match(geo or "")
    if not m:
        return None
    x = int(m.group(4)) * (1 if m.group(3) == "+" else -1)
    y = int(m.group(6)) * (1 if m.group(5) == "+" else -1)
    return int(m.group(1)), int(m.group(2)), x, y


# Narrower than this and the top buttons clip: Windows' native ttk buttons render wider than on Mac and Linux, and at
# 330 a first-launch panel cut Settings off. A first launch opens a little wider still.
PANEL_MIN_W, PANEL_MIN_H = 360, 240
PANEL_DEFAULT_GEOMETRY = "380x560"


def clamp_geometry(geo, screen_w, screen_h, min_w=PANEL_MIN_W, min_h=PANEL_MIN_H):
    """Keep a saved window position on screen (a monitor may have been unplugged). '' if it can't be parsed."""
    g = parse_geometry(geo)
    if not g:
        return ""
    w, h, x, y = g
    w, h = max(min_w, min(w, screen_w)), max(min_h, min(h, screen_h))
    x, y = max(0, min(x, screen_w - w)), max(0, min(y, screen_h - h))
    return f"{w}x{h}+{x}+{y}"


# Button sizes: (font points, vertical padding). "" on a family means "use the global text size".
SIZES = {"small": (10, 6), "normal": (12, 10), "large": (15, 12), "xlarge": (18, 14)}
SIZE_NAMES = {"": "Same as everywhere else", "small": "Small", "normal": "Normal", "large": "Large", "xlarge": "Extra large"}

MOD_KEYSYMS = {"Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Meta_L", "Meta_R", "Super_L", "Super_R",
               "Caps_Lock", "Num_Lock", "ISO_Level3_Shift", "Mode_switch"}
if IS_MAC:
    MOD_BITS = ((0x4, "ctrl"), (0x10, "alt"), (0x1, "shift"), (0x8, "super"))
elif sys.platform.startswith("win"):
    MOD_BITS = ((0x4, "ctrl"), (0x20000, "alt"), (0x1, "shift"))
else:
    MOD_BITS = ((0x4, "ctrl"), (0x8, "alt"), (0x1, "shift"), (0x40, "super"))
MOD_ORDER = ["ctrl", "alt", "shift", "super"]


def normalise_shortcut(text):
    """'Ctrl + Shift+F5' -> 'ctrl+shift+f5'. '' if it isn't a usable shortcut."""
    parts = [p.strip().lower() for p in str(text).split("+") if p.strip()]
    if not parts:
        return ""
    key, mods = parts[-1], {MODIFIERS.get(p, p) for p in parts[:-1]}
    if not mods <= set(MOD_ORDER) or key in MODIFIERS:
        return ""
    return "+".join([m for m in MOD_ORDER if m in mods] + [key])


def event_shortcut(e):
    """The shortcut string for a Tk key event, or '' for a bare modifier press."""
    if e.keysym in MOD_KEYSYMS:
        return ""
    mods = [name for bit, name in MOD_BITS if e.state & bit]
    key = e.keysym.lower()
    if len(e.keysym) == 1 and "shift" in mods and not e.keysym.isalpha():   # shift+1 arrives as '!'
        key = e.keysym
    return normalise_shortcut("+".join([m for m in MOD_ORDER if m in mods] + [key]))


# ================================================================ system-wide shortcut keys (Linux with X11, e.g. Mint)

def hotkey_eligible(shortcut):
    """A shortcut may be system-wide only if it can't hijack normal typing: it needs Ctrl, Alt or Super, or is an F key."""
    parts = normalise_shortcut(shortcut).split("+")
    if not parts or not parts[-1]:
        return False
    mods, key = set(parts[:-1]), parts[-1]
    is_f = bool(re.fullmatch(r"f([1-9]|1\d|2[0-4])", key))
    if is_f and {"ctrl", "alt"} <= mods:
        return False          # the system reserves Ctrl+Alt+F1..F12 for switching screens
    return bool({"ctrl", "alt", "super"} & mods) or is_f


def keysym_name(key):
    """Our lower-case key name -> the X11 keysym name (f5 -> F5, return -> Return, a -> a)."""
    if re.fullmatch(r"f\d{1,2}", key):
        return key.upper()
    return KEY_ALIASES.get(key, key)


class GlobalHotkeys(threading.Thread):
    """Makes shortcut keys work in any program by reserving them on the X11 root window (XGrabKey). Linux with X11
    only (Linux Mint is X11); Wayland doesn't allow it. The thread owns its own connection to the X server."""

    LOCKS = (0, 0x2, 0x10, 0x12)           # CapsLock / NumLock in any combination must not stop a shortcut working
    MODS = {"ctrl": 0x4, "alt": 0x8, "shift": 0x1, "super": 0x40}
    MASK = 0x4 | 0x8 | 0x1 | 0x40

    def __init__(self, callback):
        super().__init__(daemon=True)
        self.callback = callback
        self.jobs = queue.Queue()
        self.ok = False
        self.ready = threading.Event()
        self.table = {}                    # (keycode, modifier mask) -> shortcut string
        self._rfd, self._wfd = os.pipe()
        self._stop = False

    @staticmethod
    def possible():
        if not sys.platform.startswith("linux") or not os.environ.get("DISPLAY"):
            return False
        if "wayland" in os.environ.get("XDG_SESSION_TYPE", "").lower() and os.environ.get("QUICKPAD_X11_HOTKEYS") != "1":
            return False
        return bool(ctypes.util.find_library("X11"))

    @staticmethod
    def prepare():
        """Must run before Tk opens the display: lets Xlib be used from two threads safely."""
        try:
            ctypes.CDLL(ctypes.util.find_library("X11")).XInitThreads()
        except (OSError, TypeError, AttributeError):
            pass

    def run(self):
        try:
            self._x = ctypes.CDLL(ctypes.util.find_library("X11"))
            X = self._x
            X.XOpenDisplay.restype = ctypes.c_void_p
            X.XOpenDisplay.argtypes = [ctypes.c_char_p]
            X.XDefaultRootWindow.restype = ctypes.c_ulong
            X.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
            X.XStringToKeysym.restype = ctypes.c_ulong
            X.XStringToKeysym.argtypes = [ctypes.c_char_p]
            X.XKeysymToKeycode.restype = ctypes.c_ubyte
            X.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
            X.XGrabKey.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int]
            X.XUngrabKey.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, ctypes.c_ulong]
            X.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
            X.XPending.argtypes = [ctypes.c_void_p]
            X.XNextEvent.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            X.XConnectionNumber.argtypes = [ctypes.c_void_p]
            self.dpy = X.XOpenDisplay(None)
            if not self.dpy:
                raise OSError("no X display")
            # One long-lived error handler, installed once and kept referenced for the life of the process. Xlib's
            # default handler exits the program on any X error, and we expect BadAccess when a key is already
            # taken. Errors on other connections (Tk's) are passed straight on to whatever was installed before.
            ERR = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
            self._errors = []

            def on_error(display, event):
                if display == self.dpy:
                    self._errors.append(1)
                    return 0
                return self._prev(display, event) if self._prev else 0
            self._handler = ERR(on_error)
            X.XSetErrorHandler.restype = ctypes.c_void_p
            X.XSetErrorHandler.argtypes = [ERR]
            previous = X.XSetErrorHandler(self._handler)
            self._prev = ERR(previous) if previous else None
            self.root = X.XDefaultRootWindow(self.dpy)
            self.fd = X.XConnectionNumber(self.dpy)
            self.ok = True
        except (OSError, TypeError, AttributeError):
            self.ok = False
        self.ready.set()
        if not self.ok:
            return

        class XKeyEvent(ctypes.Structure):
            _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                        ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("root", ctypes.c_ulong),
                        ("subwindow", ctypes.c_ulong), ("time", ctypes.c_ulong), ("x", ctypes.c_int),
                        ("y", ctypes.c_int), ("x_root", ctypes.c_int), ("y_root", ctypes.c_int),
                        ("state", ctypes.c_uint), ("keycode", ctypes.c_uint), ("same_screen", ctypes.c_int)]
        buf = ctypes.create_string_buffer(192)
        ev = ctypes.cast(buf, ctypes.POINTER(XKeyEvent))
        while not self._stop:
            if select.select([self._rfd], [], [], 0)[0]:
                os.read(self._rfd, 1024)
            while not self.jobs.empty():
                combos, box, done = self.jobs.get()
                try:
                    box["v"] = self._apply(combos)
                except Exception as e:  # noqa: BLE001
                    box["v"] = {c: f"internal error: {e}" for c in combos}
                done.set()
            # Drain anything Xlib has already buffered (our own calls can read events) BEFORE waiting on the socket.
            while self._x.XPending(self.dpy):
                self._x.XNextEvent(self.dpy, buf)
                if ev.contents.type == 2:           # KeyPress
                    combo = self.table.get((ev.contents.keycode, ev.contents.state & self.MASK))
                    if combo:
                        try:
                            self.callback(combo)
                        except Exception:  # noqa: BLE001
                            pass
            select.select([self.fd, self._rfd], [], [], 0.5)

    def _apply(self, combos):
        """(Re)grab exactly these shortcuts. Returns {shortcut: '' or the reason it couldn't be reserved}."""
        X, out, errors = self._x, {}, self._errors
        X.XUngrabKey(self.dpy, 0, 1 << 15, self.root)        # AnyKey, AnyModifier
        self.table = {}
        for combo in combos:
            parts = combo.split("+")
            mods = 0
            for m in parts[:-1]:
                mods |= self.MODS.get(m, 0)
            sym = X.XStringToKeysym(keysym_name(parts[-1]).encode()) or X.XStringToKeysym(parts[-1].capitalize().encode())
            code = X.XKeysymToKeycode(self.dpy, sym) if sym else 0
            if not code:
                out[combo] = "this keyboard has no such key"
                continue
            del errors[:]
            for lock in self.LOCKS:
                X.XGrabKey(self.dpy, code, mods | lock, self.root, 1, 1, 1)
            X.XSync(self.dpy, 0)
            if errors:
                out[combo] = "another program already uses it"
                for lock in self.LOCKS:       # release only what THIS combo asked for; other combos may share the key
                    X.XUngrabKey(self.dpy, code, mods | lock, self.root)
                X.XSync(self.dpy, 0)
                del errors[:]
                continue
            self.table[(code, mods)] = combo
            out[combo] = ""
        return out

    def set_keys(self, combos, timeout=3.0):
        """Reserve exactly these shortcuts system-wide. Returns {shortcut: '' if OK else the reason}."""
        combos = list(dict.fromkeys(combos))
        if not self.ready.wait(timeout) or not self.ok:
            return {c: "system-wide shortcut keys aren't available here" for c in combos}
        box, done = {}, threading.Event()
        self.jobs.put((combos, box, done))
        os.write(self._wfd, b"x")
        if not done.wait(timeout):
            return {c: "timed out" for c in combos}
        return box["v"]

    def stop(self):
        self._stop = True
        try:
            os.write(self._wfd, b"x")
        except OSError:
            pass


def panel_of(widget):
    """The Panel that owns this dialog (walks up through the parent windows), or None."""
    while widget is not None:
        if hasattr(widget, "panel"):
            return widget.panel
        widget = getattr(widget, "master", None)
    return None


COMMON_KEYS = {"period", "comma", "minus", "plus", "slash", "backslash", "semicolon", "apostrophe", "grave", "equal",
               "bracketleft", "bracketright", "menu", "print", "pause", "caps_lock", "num_lock", "scroll_lock", "super",
               "ctrl", "control", "alt", "shift", "meta", "win", "cmd", "command", "option", "opt"}


def validate_keys(text):
    """'' if a 'Press keys' step is sensible, else a plain-English problem plus what to write instead."""
    for tok in text.split():
        parts = tok.split("+")
        if any(not p for p in parts):
            return f"“{tok}” has a stray + in it. Use + only between keys pressed together, like ctrl+s."
        for p in parts[:-1]:
            if p.lower() not in MODIFIERS:
                return (f"“{tok}”: the + only joins ctrl, alt, shift or cmd to another key, like ctrl+s.\n\n"
                        f"To press keys one after another, put a space between them instead:  {' '.join(parts)}")
        last = parts[-1]
        low = last.lower()
        if len(last) > 1 and low not in KEY_ALIASES and low not in COMMON_KEYS and not re.fullmatch(r"f\d{1,2}", low) \
                and re.fullmatch(r"[a-z]+", low):
            return (f"“{last}” isn't a key name.\n\nThis kind of step presses single keys, like Tab, Return, F5 or "
                    "ctrl+s. To type words, use a “Type text” step instead.")
    return ""


# ================================================================ support: log, crash reports, "Check my setup", one copy only

log = logging.getLogger("quickpad")
_log_ready = False


def setup_logging():
    """A small rotating log next to the per-computer state, so problems can be looked at afterwards."""
    global _log_ready
    if _log_ready:
        return
    _log_ready = True
    try:
        os.makedirs(LOCAL_DIR, exist_ok=True)
        h = logging.handlers.RotatingFileHandler(LOG_PATH, maxBytes=200_000, backupCount=2, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    except OSError:
        log.addHandler(logging.NullHandler())


def tail_log(lines=40):
    try:
        with open(LOG_PATH, encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-lines:]).strip() or "(the log is empty)"
    except OSError:
        return "(no log yet)"


def open_path(path):
    """Show a file or folder in the system's own viewer."""
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)                                  # noqa: S606
        else:
            subprocess.Popen(["open" if IS_MAC else "xdg-open", path])
    except OSError as e:
        messagebox.showerror(APP, f"Couldn't open {path}:\n{e}")


OK, WARN, BAD = "ok", "warn", "bad"
SYMBOL = {OK: "✓", WARN: "!", BAD: "✗"}          # plain glyphs: the heavy ✔ / ✖ turn into colourless emoji
COLOUR = {OK: "#1a7f37", WARN: "#9a6700", BAD: "#b3261e"}


def typing_status(backend):
    """(OK / WARN / BAD, one line) for "Typing into other programs". A backend that can say more than "its tool is
    installed" (KDE: whether the person has allowed it) has a status(); the rest are as they always were."""
    status = getattr(backend, "status", None)
    if status:
        level, text = status()
        return level, " ".join(text.split())
    problems = backend.problems()
    if problems:
        return BAD, " ".join(problems[0].split())
    return OK, f"working ({backend.name})"


def run_diagnostics(panel=None):
    """The 'Check my setup' list: [(status, what, detail)]. Quick, read-only, never raises."""
    rows = []

    def add(status, name, detail=""):
        rows.append((status, name, detail))

    def guarded(fn):
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            add(WARN, "A check couldn't run", f"{type(e).__name__}: {e}")

    add(OK, "Quickpad", f"version {VERSION}")
    add(OK, "Computer", platform.platform())
    add(OK, "Desktop", desktop_label())

    def tools():
        tk_version = panel.root.tk.call("info", "patchlevel") if panel else "?"
        add(OK, "Python and Tk", f"Python {platform.python_version()}, Tk {tk_version}")
        if panel:
            level, detail = typing_status(panel.backend)
            add(level, "Typing into other programs", detail)
    guarded(tools)

    def hotkeys():
        if GlobalHotkeys.possible():
            if panel and panel.hotkeys and panel.hotkeys.ok:
                if panel.hotkey_problems:
                    add(WARN, "Shortcut keys in any program", "; ".join(f"{k}: {v}" for k, v in panel.hotkey_problems.items()))
                else:
                    add(OK, "Shortcut keys in any program", "available")
            else:
                add(WARN, "Shortcut keys in any program", "couldn't start; shortcuts work only while Quickpad is active")
        else:
            add(WARN, "Shortcut keys in any program", "not available here (needs Linux with X11); shortcuts work while "
                                                      "Quickpad is the active window")
    guarded(hotkeys)

    def linux_extras():
        if not sys.platform.startswith("linux"):
            return
        term = next((name for name, _ in TERMINALS if shutil.which(name)), None)
        add(OK if term else WARN, "Terminal window for Computer help", term or "no terminal program found")
        if shutil.which("apt"):
            missing = sorted({t for needs in ACTION_NEEDS.values() for t in needs if not shutil.which(t)})
            add(WARN if missing else OK, "Computer help tools", ("missing: " + ", ".join(missing)) if missing else "all present")
    guarded(linux_extras)

    def files():
        writable = os.path.isdir(CONFIG_DIR) and os.access(CONFIG_DIR, os.W_OK)
        add(OK if writable else BAD, "Your buttons and settings folder", CONFIG_DIR if writable else f"can't write to {CONFIG_DIR}")
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg = json.load(f)
            n = sum(len(x.get("buttons", [])) for x in cfg.get("families", []))
            add(OK, "Your buttons file", f"{len(cfg.get('families', []))} groups, {n} buttons")
        except (OSError, ValueError) as e:
            add(BAD, "Your buttons file", f"can't read it: {e}")
        age = latest_backup_age_hours()
        if age is None:
            add(WARN, "Backups", "no automatic backup made yet")
        else:
            add(OK if age < 24 * 8 else WARN, "Backups", f"last automatic backup {age / 24:.1f} days ago" if age >= 24 else f"last automatic backup {age:.0f} hours ago")
        extra = (panel.cfg["settings"].get("backup_dir") or "").strip() if panel else ""
        if extra:
            ok_dir = os.path.isdir(extra) and os.access(extra, os.W_OK)
            add(OK if ok_dir else WARN, "Extra backup folder", extra if ok_dir else f"can't write to {extra}")
    guarded(files)

    def dictation():
        s = panel.cfg["settings"] if panel else {}
        ready, why = dictation_state(s)
        m = model_info(chosen_model(s))
        if ready:
            add(OK, "Dictation", f"ready ({m['name']} model, microphone via {engine_status()[1] or 'unknown'})")
        else:
            add(WARN, "Dictation", why + " Settings > Dictation sets it up. (Dictate buttons pause for Continue until then.)")
    guarded(dictation)

    def misc():
        if autostart_path():
            add(OK, "Start when I log in", "on" if autostart_enabled() else "off")
        bad = bad_versions()
        if bad:
            add(WARN, "Skipped updates", "these versions failed to start here and were undone: " + ", ".join(sorted(bad)))
        if panel and panel.pending:
            add(WARN, "Update", f"version {panel.pending[0]} is waiting to be installed")
        add(OK, "Log file", LOG_PATH)
    guarded(misc)

    def typing_method():
        s = panel.cfg["settings"] if panel else {}
        mode = s.get("insert_method", "type")
        text = {"type": "typed letter by letter", "paste": "pasted in through the clipboard",
                "auto": "pasted into " + (s.get("paste_programs") or DEFAULT_PASTE_PROGRAMS) + ", typed elsewhere"}
        add(OK, "How buttons put text in", text.get(mode, text["type"]) +
            " (Settings › Buttons). The Typing test button below tries it on a window you pick.")
    guarded(typing_method)
    guarded(lambda: sync_diagnostics(panel, add))
    return rows


TYPING_TEST_LINE = "Quickpad typing test 1 2 3 - this line can be deleted"
FOCUS_WORDS = {
    "ok": "Quickpad handed the keyboard back to it first time.",
    "fallback": "The usual way of handing the keyboard back didn't work, but the second way did (buttons do this by "
                "themselves).",
    "unconfirmed": "Quickpad couldn't confirm that the keyboard went back to it. If the test line isn't there, that "
                   "is the problem: copy the report for Nick.",
    "not checked": "This computer can't report whether the keyboard went back, so check that the line appeared.",
}


def typing_test_report(title, wclass, method, why, focus, problem=""):
    """What the Typing test in Check my setup says afterwards. It can go into the report for Nick, so only the
    program's part of the window title is shown (the rest can be a patient's name)."""
    where = (app_name(title) if title else "the window you clicked") + (f"  ({wclass})" if wclass else "")
    lines = [f"Window: {where}"]
    if problem:
        return "\n".join(lines + ["", problem])
    lines += [("How: pasted in through the clipboard" if method == "paste" else "How: typed letter by letter") +
              f" ({why}).", FOCUS_WORDS.get(focus, focus), "",
              f"Look in that window: is “{TYPING_TEST_LINE}” there?"]
    if method != "paste":
        lines.append("If it isn't, set Settings › Buttons › How text goes into other programs to Paste and try again.")
    else:
        lines.append("If it isn't, copy the report for Nick.")
    return "\n".join(lines)


def support_report(panel=None, problem=""):
    """Everything Nick needs to help, as plain text. Never includes the password."""
    out = [f"Quickpad support report  ({datetime.datetime.now():%Y-%m-%d %H:%M:%S})", ""]
    if problem:
        out += ["What went wrong:", problem.strip(), ""]
    out.append("Setup checks:")
    for status, name, detail in run_diagnostics(panel):
        out.append(f"  [{SYMBOL[status]}] {name}: {detail}")
    if panel:
        safe = {k: v for k, v in panel.cfg["settings"].items() if not k.startswith("password")}
        out += ["", f"{len(panel.cfg['families'])} groups, {count_buttons(panel.cfg)} buttons", "Settings:",
                json.dumps(safe, indent=1, sort_keys=True)]
    out += ["", "Recent log:", tail_log(40)]
    return "\n".join(out)


class DiagnosticsDialog(tk.Toplevel):
    """'Check my setup': one screen of green ticks and red crosses that can be photographed or copied."""

    def __init__(self, parent, panel):
        super().__init__(parent)
        self.panel = panel
        self.title(f"{APP} — Check my setup")
        self.geometry("720x620")
        self.minsize(560, 420)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        rows = run_diagnostics(panel)
        bad = sum(1 for r in rows if r[0] == BAD)
        warn = sum(1 for r in rows if r[0] == WARN)
        head = "Everything looks good." if not (bad or warn) else f"{bad} problem{'s' if bad != 1 else ''}, {warn} to look at." if bad else f"Working, with {warn} thing{'s' if warn != 1 else ''} to look at."
        tk.Label(outer, text=head, font=("TkDefaultFont", 14, "bold"), fg=COLOUR[BAD if bad else WARN if warn else OK],
                 anchor="w", bg=panel.bg).pack(fill="x", pady=(0, 8))
        box = ttk.Frame(outer)
        box.pack(fill="both", expand=True)
        canvas = tk.Canvas(box, highlightthickness=0, bg=panel.bg)
        sb = ttk.Scrollbar(box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(canvas, bg=panel.bg)
        canvas.create_window((0, 0), window=self.inner, anchor="nw", tags="in")
        canvas.bind("<Configure>", lambda e: (canvas.itemconfigure("in", width=e.width), self.rewrap(e.width)))
        self.inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self.details = []
        for status, name, detail in rows:
            self.add_row(status, name, detail)
        self.update_row = self.add_row(WARN, "Newest version online", "checking…")
        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Close", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="Copy report to send to Nick", command=self.copy).pack(side="right", padx=8)
        self.test_btn = ttk.Button(btns, text="Typing test…", command=self.typing_test)
        self.test_btn.pack(side="left")
        self.test_note = ttk.Label(btns, foreground=MUTED)
        self.test_note.pack(side="left", padx=8)
        self.testing = False
        self.bind("<Escape>", lambda e: self.destroy())
        threading.Thread(target=self.check_update, daemon=True).start()

    # ---- Typing test (SPEC-3.3 §7): type a line into a window the person picks, the way a button would
    def typing_test(self):
        if self.testing or self.panel.busy:
            return
        if not messagebox.askokcancel(
                APP, "Click OK, then within 5 seconds click into the window to test, where the text should go (for "
                     "example a LibreOffice Writer document).\n\nQuickpad then comes back to the front and types a "
                     "test line there, exactly as a button would, and tells you how it went.", parent=self):
            return
        self.testing = True
        self.test_btn.state(["disabled"])
        threading.Thread(target=self.typing_test_worker, daemon=True).start()

    def typing_test_worker(self):
        panel = self.panel
        for n in range(5, 0, -1):
            panel.post(lambda n=n: self.test_note.config(text=f"Click into the window to test… {n}"))
            time.sleep(1)
        try:
            wid, ours = panel.backend.active()
        except Exception:  # noqa: BLE001
            wid, ours = None, False
        if not wid and panel.backend.poll_interval <= 0:
            wid, ours = panel.tracker.last, False
        if not wid or ours:
            report = typing_test_report("", "", "", "", "", "Quickpad was still the active window, so there was "
                                        "nowhere to type. Try again, and click into the other window before the "
                                        "count reaches 0.")
        else:
            title, wclass = window_info(panel.backend, wid)
            panel.post(self.come_forward)          # Quickpad in front, as it is just after a button is clicked
            time.sleep(0.6)
            panel.busy = True
            runner = Runner(panel, wid, int(panel.cfg["settings"].get("type_delay_ms", 8)))
            problem = ""
            try:
                runner.run([{"type": "text", "value": TYPING_TEST_LINE}])
            except Exception as e:  # noqa: BLE001
                problem = f"Something went wrong while typing: {e}"
                log.exception("typing test failed")
            finally:
                panel.busy = False
            report = typing_test_report(title, wclass, runner.method, runner.method_why, runner.focus, problem)
        panel.post(lambda: self.show_test(report))

    def come_forward(self):
        try:
            self.lift()
            self.focus_force()
        except tk.TclError:
            pass

    def show_test(self, report):
        self.testing = False
        if not self.winfo_exists():
            return
        self.test_btn.state(["!disabled"])
        self.test_note.config(text="")
        self.add_row(OK, "Typing test", report)
        self.last_test = report
        messagebox.showinfo(APP, report, parent=self)

    def add_row(self, status, name, detail):
        row = tk.Frame(self.inner, bg=self.panel.bg)
        row.pack(fill="x", pady=2)
        sym = tk.Label(row, text=SYMBOL[status], fg=COLOUR[status], bg=self.panel.bg, font=("TkDefaultFont", 13, "bold"), width=2)
        sym.pack(side="left", anchor="n")
        txt = tk.Frame(row, bg=self.panel.bg)
        txt.pack(side="left", fill="x", expand=True)
        tk.Label(txt, text=name, anchor="w", bg=self.panel.bg, font=("TkDefaultFont", 10, "bold")).pack(fill="x")
        d = tk.Label(txt, text=detail, anchor="w", justify="left", bg=self.panel.bg, fg="#444")
        d.pack(fill="x")
        self.details.append(d)
        return sym, d

    def rewrap(self, width):
        for d in self.details:
            d.config(wraplength=max(200, width - 60))

    def check_update(self):
        try:
            ver, _ = fetch_latest_app() if getattr(sys, "frozen", False) else fetch_latest()
            newer = version_tuple(ver) > version_tuple(VERSION)
            result = (WARN if newer else OK, f"v{ver} is available. Click 'Check for updates' at the bottom of the panel." if newer else f"v{ver}: you have the newest version")
        except UpdateError as e:
            result = (WARN, str(e))
        except Exception as e:  # noqa: BLE001
            result = (WARN, f"couldn't check: {e}")
        self.panel.post(lambda: self.show_update(result))

    def show_update(self, result):
        if not self.winfo_exists():
            return
        sym, d = self.update_row
        sym.config(text=SYMBOL[result[0]], fg=COLOUR[result[0]])
        d.config(text=result[1])

    def copy(self):
        report = support_report(self.panel)
        if getattr(self, "last_test", ""):
            report += "\n\nTyping test:\n" + self.last_test
        self.panel.set_clipboard(report)
        messagebox.showinfo(APP, "Copied. Paste it into an email or message to Nick.", parent=self)


class SingleInstance:
    """Only one Quickpad per data folder. Starting a second one just brings the first to the front, so two copies can
    never fight over the same shortcut keys. Uses a small local socket. A handful of candidate ports are tried, in
    case another program is using one, and each copy says which data folder it belongs to, so a copy on a USB stick
    and one on the computer are never mistaken for duplicates of each other."""
    MAGIC = b"quickpad-instance-v1"
    TRIES = 8

    def __init__(self):
        digest = hashlib.sha1(os.path.abspath(CONFIG_DIR).encode("utf-8")).hexdigest()
        self.key = digest[:16].encode()
        base = int(digest[16:22], 16) % 20000
        self.ports = [40000 + (base + i) % 20000 for i in range(self.TRIES)]
        self.port = None
        self.index = None
        self.duplicate = False              # set by claim() if another copy won a simultaneous start
        self.server = None
        self.callback = None
        self.thread = None
        self._stop = False

    def _ask(self, port, verb=b"raise"):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1.5) as s:
                s.settimeout(1.5)
                s.sendall(self.MAGIC + b" " + verb + b" " + self.key + b"\n")
                return s.recv(64).startswith(self.MAGIC + b" ok")
        except OSError:
            return False

    def already_running(self, below=None, verb=b"raise"):
        """True if a Quickpad for this data folder answers. By default it is also asked to come to the front; use
        verb=b"ping" to only listen."""
        return any(self._ask(port, verb) for port in self.ports[:below])

    def wait_until_free(self, seconds=8.0):
        """After an update the old copy is still shutting down; wait for it instead of mistaking it for a duplicate."""
        end = time.time() + seconds
        while time.time() < end and self.already_running(verb=b"ping"):     # just listen: don't pop the old window up
            time.sleep(0.3)

    def claim(self, callback):
        """Start listening on the first free candidate port. False if we lost a simultaneous start to another copy
        (then self.duplicate is True) or no port was free (carry on without the guard)."""
        for i, port in enumerate(self.ports):
            srv = socket.socket()
            try:
                srv.bind(("127.0.0.1", port))
                srv.listen(4)
            except OSError:
                srv.close()
                continue
            srv.settimeout(0.4)               # so close() can stop the loop and really free the port
            self.server, self.callback, self.port, self.index = srv, callback, port, i
            self.thread = threading.Thread(target=self._serve, daemon=True)
            self.thread.start()
            if i and self.already_running(below=i, verb=b"ping"):    # two copies started at the same moment: the lower port wins
                self.duplicate = True
                self.close()
                return False
            return True
        return False

    def _serve(self):
        while not self._stop:
            try:
                conn, _ = self.server.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            try:
                conn.settimeout(1.0)
                data = conn.recv(96)
                if data.startswith(self.MAGIC):
                    if data.rstrip(b"\n").endswith(self.key):
                        conn.sendall(self.MAGIC + b" ok\n")
                        if b"raise" in data and self.callback:
                            self.callback()
                    else:
                        conn.sendall(self.MAGIC + b" other\n")       # a Quickpad, but for a different data folder
            except OSError:
                pass
            finally:
                conn.close()

    def close(self):
        """Stop listening and release the port (a socket another thread is waiting on isn't freed by close() alone)."""
        self._stop = True
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(1.5)
        if self.server:
            try:
                self.server.close()
            except OSError:
                pass
            self.server = None


# ================================================================ LAN sync (docs/SPEC-3.3.md §6)
#
# One desktop is the hub ("Let phones and other computers sync with this computer"): a small web server on the
# clinic's own network. Phones and other computers pair with it once (an 8-character code, or a QR code) and then
# sync their buttons to it. Nothing goes through the internet. Every message after pairing is a sealed box (seal_box)
# made with that device's own token, so someone else on the network can neither read nor change it.
#
# Where things live: the hub's id, its paired devices (with their tokens) and this computer's own pairing with
# another hub are kept in sync_devices.json next to the buttons file (owner-only on Linux/Mac). They are never in the
# buttons file, so they never go into a backup, an export or a sync. The on/off switch, name and port are this
# computer's settings (MACHINE_SETTINGS).
#
# Threads: the web server answers on its own threads, but anything that changes the buttons is handed to the Tk
# thread (panel.ui_queue), the same as every other change, so it can never race the panel or a save. If Edit buttons
# is open with unsaved changes while a sync arrives, the sync goes into the saved buttons as normal, and when the
# editor saves, its changes are combined with whatever arrived meanwhile (merge_editor_changes) instead of
# overwriting it, so neither side's edits are lost.
SYNC_PORT = 47651
SYNC_PROTOCOL = 1
SYNC_MAX_BODY = 10 * 1024 * 1024
SYNC_CONNECT_TIMEOUT = 3          # seconds to wait for another computer to answer, per address
SYNC_REPLY_TIMEOUT = 30           # …and for its reply once connected (it may be busy for a moment)
SYNC_DEBOUNCE = 5                 # seconds after a save before syncing it
SYNC_PERIOD = 120                 # and otherwise every two minutes
PAIR_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
PAIR_CODE_SECONDS = 600           # a pairing code works once, for ten minutes
PAIR_MAX_WRONG = 5                # this many wrong codes within PAIR_LOCK_SECONDS…
PAIR_LOCK_SECONDS = 600           # …and pairing is refused for this long
SYNC_MODES = ("merge", "pull", "push")
SYNC_PRIVATE_NETS = tuple(ipaddress.ip_network(n) for n in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "127.0.0.0/8", "::1/128", "fc00::/7",
    "fe80::/10"))
FIREWALL_HINT = ("If a phone or another computer can't connect, the firewall on this computer may be blocking it. On "
                 "Linux Mint, open Firewall Configuration and allow port {port} (TCP), or ask Nick to run: "
                 "sudo ufw allow {port}/tcp")
MACHINE_SETTINGS += ("sync_hub", "sync_port", "sync_name", "sync_last")   # noqa: F821 (defined near the top)


def is_private_address(addr):
    """True for an address on a local network (the only ones the hub answers): 10/8, 172.16/12, 192.168/16,
    169.254/16, 127/8, ::1, fc00::/7, fe80::/10."""
    try:
        ip = ipaddress.ip_address(str(addr).split("%", 1)[0])
    except ValueError:
        return False
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return any(ip in net for net in SYNC_PRIVATE_NETS if net.version == ip.version)


def _address_rank(a):
    for i, prefix in enumerate(("192.168.", "10.", "172.", "169.254.")):
        if a.startswith(prefix):
            return i
    return 9


def filter_addresses(candidates):
    """The private IPv4 addresses among `candidates` (no 127.x, no duplicates), the most likely one first."""
    out = []
    for a in candidates:
        try:
            ip = ipaddress.ip_address(a)
        except ValueError:
            continue
        if ip.version == 4 and not ip.is_loopback and is_private_address(a) and a not in out:
            out.append(a)
    return sorted(out, key=lambda a: (_address_rank(a), out.index(a)))


def local_addresses():
    """This computer's addresses on the local network, for other devices to reach the hub. The ones its network
    connection actually uses come first; others (e.g. for virtual machines) after them."""
    routed, other = [], []
    for probe in ("192.168.0.1", "10.255.255.255", "172.16.0.1"):
        try:      # "connecting" a UDP socket sends nothing; it just shows which address that network would use
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((probe, 9))
                routed.append(s.getsockname()[0])
        except OSError:
            pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            other.append(info[4][0])
    except OSError:
        pass
    first = filter_addresses(routed)
    return first + [a for a in filter_addresses(other) if a not in first]


def computer_name():
    try:
        return socket.gethostname().split(".")[0] or "This computer"
    except OSError:
        return "This computer"


def sync_name(settings):
    return (settings.get("sync_name") or "").strip()[:60] or computer_name()


def sync_port(settings):
    try:
        port = int(settings.get("sync_port") or SYNC_PORT)
    except (TypeError, ValueError):
        return SYNC_PORT
    return port if 1024 <= port <= 65535 else SYNC_PORT


def new_pair_code():
    raw = "".join(secrets.choice(PAIR_ALPHABET) for _ in range(8))
    return raw[:4] + "-" + raw[4:]


def normalise_code(text):
    """What was typed, as XXXX-XXXX (spaces, dashes and lower case don't matter)."""
    raw = "".join(ch for ch in str(text or "").upper() if ch.isascii() and ch.isalnum())
    return raw[:4] + "-" + raw[4:] if len(raw) == 8 else raw


def pair_url(hosts, port, code, name):
    """What the QR code holds: quickpad://pair?h=<ip1>,<ip2>&p=<port>&c=<code>&n=<url-encoded name>."""
    return (f"quickpad://pair?h={','.join(hosts)}&p={int(port)}&c={code}"
            f"&n={urllib.parse.quote(name, safe='')}")


def parse_hub_address(text, default_port=SYNC_PORT):
    """What someone typed (or pasted) as the other computer's address → (hosts, port, code or "").
    Takes 192.168.1.20, 192.168.1.20:47651, several separated by commas, or a whole quickpad://pair link."""
    text = (text or "").strip()
    if text.lower().startswith("quickpad://"):
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(text).query)
        hosts = [h.strip() for h in (q.get("h") or [""])[0].split(",") if h.strip()]
        try:
            port = int((q.get("p") or [default_port])[0])
        except ValueError:
            port = default_port
        return hosts, port, normalise_code((q.get("c") or [""])[0])
    hosts, port = [], default_port
    for part in re.split(r"[,\s]+", text):
        if not part:
            continue
        if part.count(":") == 1:
            part, _, p = part.partition(":")
            if p.isdigit():
                port = int(p)
        hosts.append(part)
    return hosts, port, ""


class PairingCodes:
    """The hub's current pairing code: XXXX-XXXX, works once, for ten minutes. Five wrong codes within ten minutes
    lock pairing for ten minutes (and the code is changed). `clock` is replaceable for tests."""

    def __init__(self, clock=time.time):
        self.clock = clock
        self.lock = threading.Lock()
        self.code, self.issued, self.used = "", 0.0, True
        self.wrong = []
        self.locked_until = 0.0

    def new(self):
        with self.lock:
            self.code, self.issued, self.used = new_pair_code(), self.clock(), False
            return self.code

    def current(self):
        """The code to show, making a fresh one if the last was used or has run out."""
        with self.lock:
            fresh = not self.used and self.clock() - self.issued < PAIR_CODE_SECONDS
        return self.code if fresh else self.new()

    def seconds_left(self):
        with self.lock:
            return max(0, int(PAIR_CODE_SECONDS - (self.clock() - self.issued))) if not self.used else 0

    def locked(self):
        with self.lock:
            return self.clock() < self.locked_until

    def check(self, typed):
        """'ok' (and the code is used up), 'bad', or 'locked'."""
        with self.lock:
            now = self.clock()
            if now < self.locked_until:
                return "locked"
            good = (not self.used and now - self.issued < PAIR_CODE_SECONDS and self.code
                    and hmac.compare_digest(normalise_code(typed), self.code))
            if good:
                self.used = True
                return "ok"
            self.wrong = [t for t in self.wrong if now - t < PAIR_LOCK_SECONDS] + [now]
            if len(self.wrong) >= PAIR_MAX_WRONG:
                self.locked_until, self.wrong, self.used = now + PAIR_LOCK_SECONDS, [], True
            return "bad"


def sync_devices_path():
    return os.path.join(CONFIG_DIR, "sync_devices.json")


class SyncDevices:
    """sync_devices.json: {"hub_id", "devices": [{device_id, name, token, paired_at, last_seen}], "client": {...}}.
    "client" is this computer's own pairing with another computer's hub: {hub_id, name, hosts, port, device_id,
    token, paired_at, first_sync_done}. Read fresh each time (it's tiny); written atomically, owner-only."""

    def __init__(self, path=None):
        self._path = path
        self.lock = threading.RLock()

    @property
    def path(self):
        return self._path or sync_devices_path()

    def load(self):
        with self.lock:
            try:
                with open(self.path, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = {}
            if not isinstance(data, dict):
                data = {}
            if not isinstance(data.get("devices"), list):
                data["devices"] = []
            data["devices"] = [d for d in data["devices"] if isinstance(d, dict) and d.get("device_id")]
            if not isinstance(data.get("client"), dict):
                data.pop("client", None)
            return data

    def save(self, data):
        with self.lock:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            if os.name == "posix":
                os.chmod(tmp, 0o600)
            os.replace(tmp, self.path)

    def hub_id(self):
        with self.lock:
            data = self.load()
            if not data.get("hub_id"):
                data["hub_id"] = "h_" + secrets.token_hex(8)
                self.save(data)
            return data["hub_id"]

    def devices(self):
        return self.load()["devices"]

    def find(self, device_id):
        return next((d for d in self.devices() if d["device_id"] == device_id), None)

    def add(self, device_id, name):
        """Pair (or re-pair) a device. Returns its new token."""
        with self.lock:
            data = self.load()
            token = secrets.token_urlsafe(32)
            data["devices"] = [d for d in data["devices"] if d["device_id"] != device_id]
            data["devices"].append({"device_id": device_id, "name": name, "token": token, "paired_at": now_ms(),
                                    "last_seen": 0})
            self.save(data)
            return token

    def seen(self, device_id, name=None):
        with self.lock:
            data = self.load()
            for d in data["devices"]:
                if d["device_id"] == device_id:
                    d["last_seen"] = now_ms()
                    if name:
                        d["name"] = name
            self.save(data)

    def remove(self, device_id):
        with self.lock:
            data = self.load()
            data["devices"] = [d for d in data["devices"] if d["device_id"] != device_id]
            self.save(data)

    def client(self):
        return self.load().get("client")

    def my_device_id(self):
        """This computer's own id when it syncs with another computer's hub (kept, so pairing again replaces the
        old entry there instead of adding a second one)."""
        with self.lock:
            data = self.load()
            if not data.get("device_id"):
                data["device_id"] = "d_" + secrets.token_hex(8)
                self.save(data)
            return data["device_id"]

    def set_client(self, client):
        with self.lock:
            data = self.load()
            if client:
                data["client"] = client
            else:
                data.pop("client", None)
            self.save(data)


# ---- what the hub does with a sync request (on the Tk thread in the app)

def clean_incoming_doc(doc):
    """A sync doc from another device, tidied the same way a buttons file is on load (ids added if missing)."""
    if not isinstance(doc, dict):
        raise ValueError("no buttons were sent")
    out = normalise(copy.deepcopy(doc))
    out.pop("settings", None)
    ensure_ids(out)
    return {k: out[k] for k in SYNC_KEYS}


def hub_handle(cfg, mode, incoming, now=None):
    """Answer one sync request against `cfg` (this computer's config, changed in place). Saves the buttons file,
    with a safety backup first for push and the usual on-save backup after any change. Returns (doc to send back,
    whether this computer's buttons changed)."""
    if mode not in SYNC_MODES:
        raise ValueError("unknown mode")
    if mode == "pull":
        return sync_doc(cfg), False
    incoming = clean_incoming_doc(incoming)
    before = sync_doc(cfg)
    new = incoming if mode == "push" else merge_docs(before, incoming, now or now_ms())
    if json.dumps(new, sort_keys=True) == json.dumps(before, sort_keys=True):
        return before, False
    if mode == "push":
        errors = write_backup(cfg)       # "use this device's buttons" replaces everything here: keep a copy first
        if errors:
            raise OSError("couldn't make a safety backup first: " + "; ".join(errors))
    apply_sync_doc(cfg, new)
    save_config(cfg, stamp=False)        # a merge result: stamping it would make old edits look new
    # (Not after a push: backups are named to the second, so this one would overwrite the safety copy just made.)
    if mode != "push" and cfg["settings"].get("backup_on_save", True):
        write_backup(cfg)
    return sync_doc(cfg), True


def client_apply(cfg, sent, received, mode, now=None):
    """Take the hub's answer into this computer's config (changed in place). Normally the answer replaces what's
    here; but if the buttons changed here while the request was on its way, the answer is merged with them instead,
    so that edit isn't lost. Returns True if anything changed (the caller saves)."""
    received = clean_incoming_doc(received)
    current = sync_doc(cfg)
    if mode == "pull" or json.dumps(current, sort_keys=True) == json.dumps(sent, sort_keys=True):
        new = received
    else:
        new = merge_docs(current, received, now or now_ms())
    if json.dumps(new, sort_keys=True) == json.dumps(current, sort_keys=True):
        return False
    apply_sync_doc(cfg, new)
    return True


def merge_editor_changes(base, editor_cfg, saved_cfg, now=None):
    """Edit buttons keeps its own working copy. If a sync changed the saved buttons while it was open (the saved ones
    no longer match `base`, what the editor started from), combine instead of overwriting: stamp the editor's own
    changes since `base`, then merge the saved buttons into them (the editor's version wins a tie). Changes
    editor_cfg in place; returns True if something from elsewhere was combined in."""
    current = sync_doc(saved_cfg)
    if base is None or json.dumps(current, sort_keys=True) == json.dumps(base, sort_keys=True):
        return False
    now = now or now_ms()
    canonicalise(editor_cfg)        # base is canonical: a missing default must not look like an edit
    ensure_ids(editor_cfg, now)
    stamp_changes(base, editor_cfg, now)
    apply_sync_doc(editor_cfg, merge_docs(sync_doc(editor_cfg), current, now))
    return True


DEFAULT_BUTTON_KEYS = None


def only_starter_buttons(cfg):
    """True if every button here came with Quickpad (the examples, Computer help, starter notes): a fresh install,
    where taking the hub's buttons loses nothing."""
    global DEFAULT_BUTTON_KEYS
    if DEFAULT_BUTTON_KEYS is None:
        DEFAULT_BUTTON_KEYS = {(f["name"], b["label"]) for src in (DEFAULT_CONFIG["families"], [ACTIONS_FAMILY],
                                                                     [STARTER_NOTES_FAMILY])
                               for f in src for b in f["buttons"]}
    return all((f.get("name"), b.get("label")) in DEFAULT_BUTTON_KEYS for f in cfg.get("families", [])
               for b in f.get("buttons", []))


# ---- the hub's web server

class SyncHub:
    """The web server other devices sync with. `apply(mode, doc)` does the work and returns the doc to send back (in
    the app it runs hub_handle on the Tk thread); `name()` gives the name shown on the other devices."""

    def __init__(self, apply, name, devices=None, port=SYNC_PORT, host="0.0.0.0", codes=None):
        self.apply, self.name = apply, name
        self.devices = devices or SyncDevices()
        self.codes = codes or PairingCodes()
        self.port, self.host = port, host
        self.httpd = None
        self.thread = None
        self.on_change = None            # called (on the server thread) after a device pairs or syncs
        self.seen_nonces = collections.OrderedDict()   # recent request nonces: a copied request can't be replayed
        self.nonce_lock = threading.Lock()

    def fresh_nonce(self, nonce):
        """False if this request's nonce was used before (someone resending a captured request)."""
        with self.nonce_lock:
            if nonce in self.seen_nonces:
                return False
            self.seen_nonces[nonce] = True
            while len(self.seen_nonces) > 5000:
                self.seen_nonces.popitem(last=False)
            return True

    def start(self):
        hub = self

        class Handler(SyncRequestHandler):
            pass
        Handler.hub = hub
        httpd = http.server.ThreadingHTTPServer((self.host, self.port), Handler)
        httpd.daemon_threads = True
        httpd.block_on_close = False
        self.httpd = httpd
        self.port = httpd.server_address[1]
        self.hub_id = self.devices.hub_id()
        self.thread = threading.Thread(target=httpd.serve_forever, kwargs={"poll_interval": 0.3}, daemon=True)
        self.thread.start()
        log.info("Sync: this computer is a hub on port %s", self.port)
        return self

    def stop(self):
        if self.httpd:
            httpd, self.httpd = self.httpd, None
            httpd.shutdown()
            httpd.server_close()
            log.info("Sync: hub stopped")

    @property
    def running(self):
        return self.httpd is not None

    def changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:  # noqa: BLE001
                pass


class SyncRequestHandler(http.server.BaseHTTPRequestHandler):
    hub = None
    server_version = "Quickpad"
    sys_version = ""
    protocol_version = "HTTP/1.0"

    def log_message(self, fmt, *args):     # requests aren't logged one by one; problems are (below)
        pass

    def reply(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def allowed(self):
        if not is_private_address(self.client_address[0]):
            self.reply(403, {"error": "not on this network"})
            return False
        return True

    def read_json(self):
        """The request body as JSON, or None after replying with the problem."""
        try:
            n = int(self.headers.get("Content-Length", ""))
        except ValueError:
            self.reply(411, {"error": "length required"})
            return None
        if n < 0 or n > SYNC_MAX_BODY:
            self.reply(413, {"error": "too big"})
            self.close_connection = True
            return None
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self.reply(400, {"error": "bad request"})
            return None

    def do_GET(self):
        if not self.allowed():
            return
        if self.path.split("?")[0] != "/qp/v1/hello":
            self.reply(404, {"error": "not found"})
            return
        hub = self.hub
        self.reply(200, {"app": APP, "protocol": SYNC_PROTOCOL, "version": VERSION, "name": hub.name(),
                         "hub_id": hub.hub_id})

    def do_POST(self):
        if not self.allowed():
            return
        path = self.path.split("?")[0]
        if path == "/qp/v1/pair":
            self.pair()
        elif path == "/qp/v1/sync":
            self.sync()
        else:
            self.reply(404, {"error": "not found"})

    def pair(self):
        hub = self.hub
        if hub.codes.locked():
            self.reply(429, {"error": "too many tries"})
            return
        body = self.read_json()
        if body is None:
            return
        device_id = body.get("device_id") if isinstance(body, dict) else None
        if not isinstance(device_id, str) or not device_id.strip() or len(device_id) > 200:
            self.reply(400, {"error": "bad request"})
            return
        result = hub.codes.check(body.get("code", ""))
        if result == "locked":
            self.reply(429, {"error": "too many tries"})
            return
        if result != "ok":
            log.info("Sync: a pairing code was wrong or out of date (from %s)", self.client_address[0])
            self.reply(403, {"error": "bad code"})
            return
        name = str(body.get("device_name") or "Device").strip()[:80] or "Device"
        token = hub.devices.add(device_id, name)
        log.info("Sync: paired %s", name)
        self.reply(200, {"token": token, "hub_id": hub.hub_id, "name": hub.name()})
        hub.changed()

    def sync(self):
        hub = self.hub
        auth = self.headers.get("Authorization", "")
        device_id = auth[7:].strip() if auth.startswith("Bearer ") else ""
        device = hub.devices.find(device_id) if device_id else None
        if not device:
            self.reply(401, {"error": "unknown device"})
            return
        box = self.read_json()
        if box is None:
            return
        try:
            req = json.loads(open_box(device["token"], box).decode("utf-8"))
            if not hub.fresh_nonce(box["nonce"]):
                raise ValueError("replayed")
            if not isinstance(req, dict) or req.get("protocol") != SYNC_PROTOCOL or req.get("mode") not in SYNC_MODES:
                raise ValueError("bad request")
            mode, doc = req["mode"], req.get("doc")
            if mode != "pull" and not isinstance(doc, dict):
                raise ValueError("no buttons sent")
        except (ValueError, UnicodeDecodeError):
            self.reply(400, {"error": "bad box"})
            return
        try:
            out = hub.apply(mode, doc)
        except Exception as e:  # noqa: BLE001
            log.warning("Sync: couldn't sync with %s: %s", device.get("name"), e)
            self.reply(503, {"error": "busy"})
            return
        name = str(req.get("device_name") or "").strip()[:80] or None
        hub.devices.seen(device_id, name)
        reply = json.dumps({"doc": out, "server_time": now_ms()}, ensure_ascii=False).encode("utf-8")
        self.reply(200, seal_box(device["token"], reply))
        hub.changed()


# ---- the client side: this computer syncing with another computer's hub

class SyncError(Exception):
    """kind: 'unreachable', 'bad code', 'locked', 'unpaired' (the hub doesn't know us any more), or 'problem'."""

    def __init__(self, kind, message=""):
        super().__init__(message or kind)
        self.kind = kind


def _http(host, port, method, path, body=None, headers=None):
    """One request → (status, JSON reply). Raises OSError if that address can't be reached in time."""
    conn = http.client.HTTPConnection(host, port, timeout=SYNC_CONNECT_TIMEOUT)
    try:
        conn.connect()
        conn.sock.settimeout(SYNC_REPLY_TIMEOUT)
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        hdrs = {"Content-Type": "application/json; charset=utf-8", **(headers or {})}
        conn.request(method, path, body=data, headers=hdrs)
        resp = conn.getresponse()
        raw = resp.read(SYNC_MAX_BODY + 1)
        try:
            obj = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            obj = {}
        return resp.status, obj
    except http.client.HTTPException as e:
        raise OSError(str(e)) from e
    finally:
        conn.close()


def _each_host(hosts, port, fn):
    """Try fn(host) for each address in turn; the first that answers wins → (result, host)."""
    last = None
    for host in hosts:
        try:
            return fn(host), host
        except OSError as e:
            last = e
    raise SyncError("unreachable", str(last or "no address"))


def pair_with_hub(hosts, port, code, device_id, device_name):
    """Pair with another computer's hub. Returns {hub_id, name, hosts, port, device_id, token, paired_at}."""
    def go(host):
        return _http(host, port, "POST", "/qp/v1/pair",
                     {"code": normalise_code(code), "device_id": device_id, "device_name": device_name})
    (status, reply), host = _each_host(hosts, port, go)
    if status == 403:
        raise SyncError("bad code")
    if status == 429:
        raise SyncError("locked")
    if status != 200 or not reply.get("token"):
        raise SyncError("problem", f"the other computer answered {status}")
    ordered = [host] + [h for h in hosts if h != host]
    return {"hub_id": reply.get("hub_id", ""), "name": str(reply.get("name") or ordered[0]), "hosts": ordered,
            "port": port, "device_id": device_id, "token": reply["token"], "paired_at": now_ms(),
            "first_sync_done": False}


def sync_with_hub(client, mode, doc, device_name):
    """One sync with our hub. Returns (the hub's doc, the address that answered)."""
    if mode not in SYNC_MODES:
        raise ValueError("unknown mode")
    token = client["token"]
    body = json.dumps({"protocol": SYNC_PROTOCOL, "mode": mode, "device_name": device_name,
                       "doc": doc if mode != "pull" else None}, ensure_ascii=False).encode("utf-8")

    def go(host):
        return _http(host, client.get("port", SYNC_PORT), "POST", "/qp/v1/sync", seal_box(token, body),
                     {"Authorization": "Bearer " + client["device_id"]})
    (status, reply), host = _each_host(client.get("hosts") or [], client.get("port", SYNC_PORT), go)
    if status == 401:
        raise SyncError("unpaired")
    if status != 200:
        raise SyncError("problem", f"the other computer answered {status}")
    try:
        inner = json.loads(open_box(token, reply).decode("utf-8"))
        doc = inner["doc"]
        if not isinstance(doc, dict):
            raise ValueError("no doc")
    except (ValueError, KeyError, TypeError, UnicodeDecodeError) as e:
        raise SyncError("problem", "the reply couldn't be read") from e
    return doc, host


class SyncSchedule:
    """When this computer (paired to another computer's hub) syncs: straight away on start, SYNC_DEBOUNCE seconds
    after a save (a run of saves waits for the last one), and every SYNC_PERIOD seconds. Times are plain seconds, so
    tests can use a fake clock."""

    def __init__(self, now):
        self.next_periodic = now
        self.due = None

    def saved(self, now):
        self.due = now + SYNC_DEBOUNCE

    def ready(self, now):
        return (self.due is not None and now >= self.due) or now >= self.next_periodic

    def synced(self, now):
        self.due = None
        self.next_periodic = now + SYNC_PERIOD


def describe_ago(ms, now=None):
    secs = max(0, ((now or now_ms()) - ms) / 1000)
    if secs < 60:
        return "just now"
    mins = int(secs // 60)
    if mins < 60:
        return f"{mins} min ago"
    hours = mins // 60
    if hours < 24:
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    days = hours // 24
    return f"{days} day{'s' if days != 1 else ''} ago"


def firewall_on():
    """True/False if ufw's own settings file says whether it's on (readable without sudo), else None."""
    try:
        with open("/etc/ufw/ufw.conf", encoding="utf-8") as f:
            for line in f:
                if line.strip().upper().startswith("ENABLED="):
                    return line.split("=", 1)[1].strip().strip("\"'").lower() == "yes"
    except OSError:
        return None
    return None


def hub_answers(port):
    """True if a Quickpad hub answers on this computer at `port`."""
    try:
        status, reply = _http("127.0.0.1", port, "GET", "/qp/v1/hello")
        return status == 200 and reply.get("app") == APP
    except OSError:
        return False


class SyncController:
    """The panel's side of sync: runs the hub when it's switched on, and keeps this computer in step with another
    computer's hub once paired (SyncSchedule). Network work happens on worker threads; every change to the buttons
    happens on the Tk thread."""

    TICK_MS = 1000
    HOST = "0.0.0.0"                     # every network on this computer (the tests use 127.0.0.1)

    def __init__(self, panel, clock=time.time):
        self.panel = panel
        self.clock = clock
        self.devices = SyncDevices()
        self.codes = PairingCodes(clock)
        self.hub = None
        self.hub_error = ""
        self.schedule = SyncSchedule(clock())
        self.busy = False
        self.last_ok = 0                 # ms of the last good sync with our hub (this session or saved)
        self.last_error = ""             # "" or what went wrong last time
        self.listeners = []              # callables told when anything changes (the Sync tab)
        self._mtime = self._config_mtime()
        self._tick_job = None
        self._client = None
        self.stopped = False

    # -- hub
    def settings(self):
        return self.panel.cfg["settings"]

    def start(self):
        self._client = self.devices.client()
        self.last_ok = int(self.settings().get("sync_last") or 0)
        if self.settings().get("sync_hub"):
            self.start_hub()
        self.tick()

    def start_hub(self):
        self.stop_hub()
        port = sync_port(self.settings())
        try:
            self.hub = SyncHub(self.apply_from_thread, lambda: sync_name(self.settings()), self.devices, port,
                               host=self.HOST, codes=self.codes).start()
            self.hub.on_change = lambda: self.panel.post(self.notify)
            self.hub_error = ""
        except OSError as e:
            self.hub = None
            self.hub_error = (f"Couldn't start on port {port}: another program may be using it ({e.strerror or e}). "
                              "Try another port.")
            log.warning("Sync: %s", self.hub_error)
        self.notify()
        return self.hub is not None

    def stop_hub(self):
        if self.hub:
            self.hub.stop()
            self.hub = None
        self.notify()

    def apply_from_thread(self, mode, doc):
        """Called on a server thread: do the work on the Tk thread and wait for it."""
        box, done = {}, threading.Event()
        self.panel.ui_queue.put((lambda: self.apply_on_ui(mode, doc), box, done))
        if not done.wait(SYNC_REPLY_TIMEOUT - 5):
            raise TimeoutError("Quickpad was busy")
        if "e" in box:
            raise box["e"]
        return box["v"]

    def apply_on_ui(self, mode, doc):
        panel = self.panel
        if not panel.cfg_ok:
            raise OSError("this computer's buttons file couldn't be read, so syncing is paused")
        out, changed = hub_handle(panel.cfg, mode, doc)
        if changed:
            self._mtime = self._config_mtime()
            panel.build()
        return out

    # -- client
    def client(self):
        if self._client is None:
            self._client = self.devices.client() or {}
        return self._client or None

    def set_client(self, client):
        self.devices.set_client(client)
        self._client = client or {}
        self.last_error = ""
        self.notify()

    def _config_mtime(self):
        try:
            return os.stat(CONFIG_PATH).st_mtime_ns
        except OSError:
            return None

    def tick(self):
        """Every second: notice saves (the buttons file changed) and sync when the schedule says so."""
        if self.stopped:
            return
        try:
            now = self.clock()
            m = self._config_mtime()
            if m != self._mtime:
                self._mtime = m
                self.schedule.saved(now)
            client = self.client()
            if not self.busy and client and client.get("first_sync_done") and self.schedule.ready(now):
                self.sync_now()
        except Exception as e:  # noqa: BLE001
            log.warning("Sync: %s", e)
        try:
            self._tick_job = self.panel.root.after(self.TICK_MS, self.tick)
        except (tk.TclError, RuntimeError):
            pass

    def sync_now(self, mode="merge", done=None):
        """Start a sync with our hub (on a worker thread). done(error_text_or_"") is called on the Tk thread."""
        client = self.client()
        if not client or self.busy or not self.panel.cfg_ok:
            if done:
                done("" if client else "not paired")
            return False
        self.busy = True
        self.schedule.synced(self.clock())
        sent = sync_doc(self.panel.cfg)
        name = sync_name(self.settings())

        def work():
            try:
                doc, host = sync_with_hub(client, mode, sent, name)
                result = (doc, host, None)
            except SyncError as e:
                result = (None, None, e)
            except Exception as e:  # noqa: BLE001
                result = (None, None, SyncError("problem", str(e)))
            self.panel.post(lambda: self.finish(client, mode, sent, result, done))
        threading.Thread(target=work, daemon=True).start()
        return True

    def finish(self, client, mode, sent, result, done):
        doc, host, err = result
        self.busy = False
        problem = ""
        if err is None:
            try:
                panel = self.panel
                safety = mode == "pull" and json.dumps(sync_doc(panel.cfg), sort_keys=True) != json.dumps(
                    clean_incoming_doc(doc), sort_keys=True)
                if safety:
                    errors = write_backup(panel.cfg)     # "use the hub's buttons": keep a copy of these first
                    if errors:
                        raise OSError("couldn't make a backup of this computer's buttons first")
                changed = client_apply(panel.cfg, sent, doc, mode)
                self.last_ok = now_ms()
                self.last_error = ""
                self.settings()["sync_last"] = self.last_ok      # saved with the next save (or on closing)
                if changed:
                    save_config(panel.cfg, stamp=False)
                    if not safety and panel.cfg["settings"].get("backup_on_save", True):   # (see hub_handle)
                        write_backup(panel.cfg)
                    self._mtime = self._config_mtime()
                    panel.build()
                fresh = dict(self.client() or {})               # {} if "Stop syncing" was clicked meanwhile
                if fresh and (not fresh.get("first_sync_done") or (host and fresh.get("hosts") and
                                                                   fresh["hosts"][0] != host)):
                    fresh["first_sync_done"] = True
                    if host and host in fresh.get("hosts", []):      # try the address that worked first next time
                        fresh["hosts"] = [host] + [h for h in fresh["hosts"] if h != host]
                    self.devices.set_client(fresh)
                    self._client = fresh
            except (OSError, ValueError) as e:
                problem = f"Couldn't save what came back: {e}"
        else:
            problem = {"unreachable": "unreachable", "unpaired": "unpaired"}.get(err.kind, str(err))
        if problem:
            self.last_error = problem
            log.info("Sync: with %s: %s", client.get("name"), problem)
        self.notify()
        if done:
            done(problem)

    def status_text(self):
        client = self.client()
        if not client:
            return ""
        name = client.get("name") or "the other computer"
        if self.busy:
            return f"Syncing with {name}…"
        if self.last_error == "unreachable":
            return f"Couldn't reach {name}"
        if self.last_error == "unpaired":
            return f"{name} doesn't recognise this computer any more. Stop syncing, then pair again."
        if self.last_error:
            return f"Couldn't sync with {name}: {self.last_error}"
        if not client.get("first_sync_done"):
            return f"Paired with {name}, not synced yet"
        if self.last_ok:
            return f"Last synced {describe_ago(self.last_ok)} with {name}"
        return f"Not synced yet with {name}"

    def unpair(self):
        self.devices.set_client(None)
        self._client = {}
        self.last_ok, self.last_error = 0, ""
        self.settings()["sync_last"] = 0
        self.notify()

    # -- everything else
    def notify(self):
        for fn in list(self.listeners):
            try:
                fn()
            except Exception:  # noqa: BLE001
                pass

    def stop(self):
        self.stopped = True
        if self._tick_job:
            try:
                self.panel.root.after_cancel(self._tick_job)
            except (tk.TclError, RuntimeError):
                pass
        if self.hub:
            self.hub.stop()
            self.hub = None


def sync_diagnostics(panel, add):
    """Check my setup's Sync row(s)."""
    ctl = getattr(panel, "sync", None) if panel else None
    s = panel.cfg["settings"] if panel else {}
    port = sync_port(s)
    if s.get("sync_hub"):
        if hub_answers(port):
            fw = firewall_on()
            extra = (" The firewall (ufw) is on: if other devices can't connect, allow port "
                     f"{port}/tcp.") if fw else (" If other devices can't connect, check the firewall allows port "
                                                  f"{port}/tcp." if fw is None and sys.platform.startswith("linux")
                                                  else "")
            addrs = ", ".join(local_addresses()) or "no local network address found"
            add(OK if not fw else WARN, "Sync (other devices sync with this computer)",
                f"on, listening on port {port} at {addrs}.{extra}")
        else:
            why = (ctl.hub_error if ctl and ctl.hub_error else "it isn't answering")
            add(BAD, "Sync (other devices sync with this computer)", f"switched on, but {why}")
    else:
        add(OK, "Sync (other devices sync with this computer)", "off (Settings › Sync)")
    if ctl and ctl.client():
        text = ctl.status_text()
        add(WARN if ctl.last_error else OK, "Sync with another computer", text)


# ---- a small QR code maker (byte mode, error correction level M, versions 1-10: up to 213 characters), so the
# pairing link can be shown as a code a phone scans without installing anything on the desktop. Follows ISO/IEC 18004.
QR_ECC_M = (None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26)      # error-correction codewords per block, by version
QR_BLOCKS_M = (None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5)             # number of blocks, by version
QR_ALIGN = (None, (), (6, 18), (6, 22), (6, 26), (6, 30), (6, 34), (6, 22, 38), (6, 24, 42), (6, 26, 46), (6, 28, 50))
QR_MAX_VERSION = 10


def _qr_raw_codewords(ver):
    n = (16 * ver + 128) * ver + 64
    if ver >= 2:
        k = ver // 7 + 2
        n -= (25 * k - 10) * k - 55
        if ver >= 7:
            n -= 36
    return n // 8


def _qr_data_codewords(ver):
    return _qr_raw_codewords(ver) - QR_ECC_M[ver] * QR_BLOCKS_M[ver]


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    out = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            out[j] = _gf_mul(out[j], root)
            if j + 1 < degree:
                out[j] ^= out[j + 1]
        root = _gf_mul(root, 0x02)
    return out


def _rs_remainder(data, divisor):
    out = [0] * len(divisor)
    for b in data:
        factor = b ^ out.pop(0)
        out.append(0)
        for i, coef in enumerate(divisor):
            out[i] ^= _gf_mul(coef, factor)
    return out


def _qr_codewords(data, ver):
    """Data bits → interleaved data + error-correction codewords for `ver`."""
    bits = []

    def put(value, n):
        bits.extend((value >> i) & 1 for i in range(n - 1, -1, -1))
    put(0b0100, 4)                                    # byte mode
    put(len(data), 8 if ver < 10 else 16)
    for b in data:
        put(b, 8)
    cap = _qr_data_codewords(ver) * 8
    put(0, min(4, cap - len(bits)))                   # terminator
    put(0, -len(bits) % 8)
    words = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(words) < cap // 8:
        words.append(pad)
        pad ^= 0xEC ^ 0x11
    nblocks, ecc = QR_BLOCKS_M[ver], QR_ECC_M[ver]
    raw = _qr_raw_codewords(ver)
    short = nblocks - raw % nblocks
    short_len = raw // nblocks
    div = _rs_divisor(ecc)
    blocks, k = [], 0
    for i in range(nblocks):
        n = short_len - ecc + (0 if i < short else 1)
        dat = words[k:k + n]
        k += n
        block = dat + _rs_remainder(dat, div)
        if i < short:
            block.insert(short_len - ecc, None)       # placeholder so every block is the same length
        blocks.append(block)
    out = []
    for i in range(len(blocks[0])):
        for blk in blocks:
            if blk[i] is not None:
                out.append(blk[i])
    return out


def _qr_penalty(m):
    size = len(m)
    score = 0
    lines = [list(r) for r in m] + [[m[y][x] for y in range(size)] for x in range(size)]
    pattern_a = [True, False, True, True, True, False, True, False, False, False, False]
    pattern_b = pattern_a[::-1]
    for line in lines:
        run, prev = 0, None
        for v in line:
            if v == prev:
                run += 1
            else:
                if run >= 5:
                    score += run - 2
                run, prev = 1, v
        if run >= 5:
            score += run - 2
        padded = [False] * 4 + line + [False] * 4
        for i in range(len(padded) - 10):
            window = padded[i:i + 11]
            if window == pattern_a or window == pattern_b:
                score += 40
    for y in range(size - 1):
        for x in range(size - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(r) for r in m)
    score += 10 * (abs(dark * 20 - size * size * 10) // (size * size))   # 10 per 5% away from half dark
    return score


QR_MASKS = (
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
)


def qr_matrix(text, mask=None):
    """A QR code for `text` (UTF-8, byte mode, level M) as rows of booleans (True = dark), without the quiet zone.
    The mask with the lowest penalty is chosen, unless one is given. Raises ValueError if it's too long."""
    data = text.encode("utf-8") if isinstance(text, str) else bytes(text)
    for ver in range(1, QR_MAX_VERSION + 1):
        head = 4 + (8 if ver < 10 else 16)
        if head + 8 * len(data) <= _qr_data_codewords(ver) * 8:
            break
    else:
        raise ValueError("too long for a QR code here")
    size = ver * 4 + 17
    mod = [[False] * size for _ in range(size)]
    fixed = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        mod[y][x] = dark
        fixed[y][x] = True
    for i in range(size):                                 # timing patterns
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):  # finder patterns + separators
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    setf(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    pos = QR_ALIGN[ver]
    last = len(pos) - 1
    for i, ax in enumerate(pos):
        for j, ay in enumerate(pos):
            if (i, j) in ((0, 0), (0, last), (last, 0)):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format(m):
        d = (0 << 3) | m                                   # level M = 00
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = ((d << 10) | rem) ^ 0x5412
        bit = lambda i: (bits >> i) & 1 == 1              # noqa: E731
        for i in range(6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)                           # the module that is always dark
    draw_format(0)                                        # reserve the format areas
    if ver >= 7:
        rem = ver
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = (ver << 12) | rem
        for i in range(18):
            dark = (bits >> i) & 1 == 1
            a, b = size - 11 + i % 3, i // 3
            setf(a, b, dark)
            setf(b, a, dark)
    words = _qr_codewords(data, ver)
    i, total = 0, len(words) * 8
    right = size - 1
    while right >= 1:                                     # zigzag placement, two columns at a time
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                y = size - 1 - vert if ((right + 1) & 2) == 0 else vert
                if not fixed[y][x] and i < total:
                    mod[y][x] = (words[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1
        right -= 2

    def masked(m):
        fn = QR_MASKS[m]
        out = [[mod[y][x] ^ (not fixed[y][x] and fn(x, y)) for x in range(size)] for y in range(size)]
        return out
    choices = [mask] if mask is not None else range(8)
    best = None
    for m in choices:
        draw_format(m)
        cand = masked(m)
        score = _qr_penalty(cand)
        if best is None or score < best[0]:
            best = (score, m, cand)
    return best[2]


def qr_pgm(matrix, scale=8, border=4):
    """The QR code as a binary PGM image (for tests and anyone who wants a file): black on white."""
    size = len(matrix)
    side = (size + 2 * border) * scale
    rows = bytearray()
    for y in range(-border, size + border):
        line = bytearray()
        for x in range(-border, size + border):
            dark = 0 <= x < size and 0 <= y < size and matrix[y][x]
            line += (b"\x00" if dark else b"\xff") * scale
        rows += bytes(line) * scale
    return b"P5\n%d %d\n255\n" % (side, side) + bytes(rows)


def draw_qr(canvas, matrix, module=4, border=4):
    """Draw a QR code on a Tk canvas: black on white whatever the colour scheme, so any phone can read it."""
    canvas.delete("all")
    n = len(matrix)
    side = (n + 2 * border) * module
    canvas.configure(width=side, height=side, bg="#ffffff")
    canvas.create_rectangle(0, 0, side, side, fill="#ffffff", outline="")
    for y, row in enumerate(matrix):
        x = 0
        while x < n:
            if row[x]:
                start = x
                while x < n and row[x]:
                    x += 1
                canvas.create_rectangle((start + border) * module, (y + border) * module, (x + border) * module,
                                        (y + border + 1) * module, fill="#000000", outline="")
            else:
                x += 1
    return side


class FirstSyncDialog(tk.Toplevel):
    """After pairing: whose buttons to start from (SPEC-3.3 §6.2). result: 'pull', 'merge', 'push' or None."""

    def __init__(self, parent, hub_name, fresh):
        super().__init__(parent)
        self.result = None
        self.title(f"{APP} — Start syncing")
        self.transient(parent.winfo_toplevel())
        self.resizable(False, False)
        f = ttk.Frame(self, padding=16)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text=f"Use the buttons from {hub_name}?", font=("TkDefaultFont", 12, "bold")).pack(anchor="w")
        ttk.Label(f, text="Choose how to start. After this, changes on either computer are copied to the other "
                          "automatically.", foreground=MUTED, wraplength=440, justify="left").pack(anchor="w",
                                                                                             pady=(4, 10))
        options = [("pull", f"Use {hub_name}'s buttons",
                    f"This computer gets the same buttons as {hub_name}. A backup of this computer's buttons is "
                    "made first."),
                   ("merge", "Combine both", "Keeps every button from both computers. Buttons that are on both "
                                             "may appear twice; delete the extra ones afterwards."),
                   ("push", "Use this computer's buttons",
                    f"{hub_name} gets the same buttons as this computer. {hub_name} makes a backup of its buttons "
                    "first.")]
        default = "pull" if fresh else "merge"
        self.buttons = {}
        for mode, title, help_text in options:
            b = ttk.Button(f, text=title, command=lambda m=mode: self.pick(m))
            b.pack(fill="x", pady=(6, 0))
            ttk.Label(f, text=help_text, foreground=MUTED, wraplength=440, justify="left").pack(anchor="w")
            self.buttons[mode] = b
        self.not_now = ttk.Button(f, text="Not now", command=self.destroy)
        self.not_now.pack(anchor="e", pady=(14, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        self.buttons[default].focus_set()
        self.bind("<Return>", lambda e: self.focus_get().invoke() if hasattr(self.focus_get(), "invoke") else None)
        place_beside(self, parent.winfo_toplevel())

    def pick(self, mode):
        self.result = mode
        self.destroy()

    @classmethod
    def ask(cls, parent, hub_name, fresh):
        dlg = cls(parent, hub_name, fresh)
        try:
            dlg.grab_set()
        except tk.TclError:
            pass
        parent.wait_window(dlg)
        return dlg.result


class SyncTab:
    """Settings › Sync. Everything here takes effect straight away (like Back up now), so there's nothing to undo
    with Cancel."""

    def __init__(self, frame, dialog):
        self.f, self.dlg = frame, dialog
        self.panel = dialog.panel
        self.ctl = getattr(self.panel, "sync", None)
        self.qr_text = None
        self._addrs, self._addr_at = [], 0.0
        s = self.panel.cfg["settings"]
        f = frame
        ttk.Label(f, text="Keep your buttons the same on several computers and phones", font=("TkDefaultFont", 11,
                                                                                            "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(f, text="They sync over the clinic's own network. Nothing goes over the internet.",
                  foreground=MUTED, wraplength=540, justify="left").grid(row=1, column=0, columnspan=2, sticky="w",
                                                                         pady=(2, 10))
        if self.ctl is None:
            ttk.Label(f, text="Sync isn't available in this window.", foreground=MUTED).grid(row=2, column=0,
                                                                                            sticky="w")
            return
        # ---- this computer as the hub
        hub = ttk.LabelFrame(f, text="Let other devices sync with this computer", padding=10)
        hub.grid(row=2, column=0, columnspan=2, sticky="ew")
        hub.columnconfigure(1, weight=1)
        self.hub_on = tk.BooleanVar(value=bool(s.get("sync_hub")))
        ttk.Checkbutton(hub, text="Let phones and other computers sync with this computer", variable=self.hub_on,
                        command=self.toggle_hub).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(hub, text="Usually the computer at the front desk, which is on all day.", foreground=MUTED).grid(
            row=1, column=0, columnspan=3, sticky="w")
        ttk.Label(hub, text="This computer's name").grid(row=2, column=0, sticky="w", pady=(8, 2))
        self.name_var = tk.StringVar(value=s.get("sync_name") or computer_name())
        name = ttk.Entry(hub, textvariable=self.name_var, width=28)
        name.grid(row=2, column=1, sticky="w", padx=8, pady=(8, 2))
        name.bind("<FocusOut>", lambda e: self.apply_name())
        name.bind("<Return>", lambda e: self.apply_name())
        ttk.Label(hub, text="Port").grid(row=3, column=0, sticky="w", pady=2)
        self.port_var = tk.StringVar(value=str(sync_port(s)))
        port = ttk.Spinbox(hub, from_=1024, to=65535, width=7, textvariable=self.port_var)
        port.grid(row=3, column=1, sticky="w", padx=8, pady=2)
        port.bind("<FocusOut>", lambda e: self.apply_port())
        port.bind("<Return>", lambda e: self.apply_port())
        self.hub_status = tk.StringVar()
        self.hub_status_lbl = ttk.Label(hub, textvariable=self.hub_status, wraplength=520, justify="left")
        self.hub_status_lbl.grid(row=4, column=0, columnspan=3, sticky="w", pady=(8, 0))
        self.pairing = ttk.Frame(hub)
        self.pairing.grid(row=5, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        left = ttk.Frame(self.pairing)
        left.pack(side="left", anchor="n", fill="x", expand=True)
        ttk.Label(left, text="Pairing code").pack(anchor="w")
        self.code_var = tk.StringVar()
        ttk.Label(left, textvariable=self.code_var, font=("TkFixedFont", 20, "bold")).pack(anchor="w")
        self.code_note = tk.StringVar()
        ttk.Label(left, textvariable=self.code_note, foreground=MUTED).pack(anchor="w")
        ttk.Button(left, text="New code", command=self.new_code).pack(anchor="w", pady=(4, 0))
        ttk.Label(left, text="On a phone: open Quickpad, choose Sync, and scan the square code. On another computer: "
                             "Settings › Sync › Sync this computer with another Quickpad, then type this computer's "
                             "address and the code.", foreground=MUTED, wraplength=300, justify="left").pack(
            anchor="w", pady=(8, 0))
        self.qr = tk.Canvas(self.pairing, width=180, height=180, bg="#ffffff", highlightthickness=0, bd=0)
        self.qr.pack(side="right", anchor="n", padx=(10, 0))
        ttk.Label(hub, text="Paired devices").grid(row=6, column=0, columnspan=3, sticky="w", pady=(10, 2))
        self.dev_tree = ttk.Treeview(hub, columns=("name", "last"), show="headings", height=4, selectmode="browse")
        self.dev_tree.heading("name", text="Name")
        self.dev_tree.heading("last", text="Last synced")
        self.dev_tree.column("name", width=240)
        self.dev_tree.column("last", width=160)
        self.dev_tree.grid(row=7, column=0, columnspan=2, sticky="ew")
        ttk.Button(hub, text="Remove", command=self.remove_device).grid(row=7, column=2, sticky="nw", padx=(6, 0))
        self.fw_var = tk.StringVar()
        ttk.Label(hub, textvariable=self.fw_var, foreground=MUTED, wraplength=540, justify="left").grid(
            row=8, column=0, columnspan=3, sticky="w", pady=(8, 0))
        # ---- this computer syncing with another computer's hub
        self.client_box = ttk.LabelFrame(f, text="Sync this computer with another Quickpad", padding=10)
        self.client_box.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        self.client_box.columnconfigure(1, weight=1)
        self.client_state = None
        self.addr_var = tk.StringVar()
        self.pair_code_var = tk.StringVar()
        self.client_status = tk.StringVar()
        self.pairing_now = False
        self.ctl.listeners.append(self.refresh)
        frame.bind("<Destroy>", self.gone, add="+")
        self.refresh()
        self.tick()

    def gone(self, event):
        if event.widget is self.f and self.refresh in self.ctl.listeners:
            self.ctl.listeners.remove(self.refresh)

    def alive(self):
        try:
            return bool(self.f.winfo_exists())
        except tk.TclError:
            return False

    def tick(self):
        if self.alive():
            self.refresh()
            self.f.after(1000, self.tick)

    # -- hub side
    def settings(self):
        return self.panel.cfg["settings"]

    def persist(self):
        if self.panel.cfg_ok:
            try:
                save_config(self.panel.cfg)
            except OSError as e:
                messagebox.showerror(APP, f"Couldn't save:\n{e}", parent=self.dlg)

    def apply_name(self):
        name = " ".join(self.name_var.get().split())[:60]
        new = "" if name in ("", computer_name()) else name
        if new != (self.settings().get("sync_name") or ""):
            self.settings()["sync_name"] = new
            self.persist()
        self.refresh()

    def apply_port(self):
        try:
            port = int(self.port_var.get())
            if not 1024 <= port <= 65535:
                raise ValueError
        except ValueError:
            self.port_var.set(str(sync_port(self.settings())))
            return
        if port != sync_port(self.settings()):
            self.settings()["sync_port"] = port
            self.persist()
            if self.ctl.hub:
                self.ctl.start_hub()
        self.refresh()

    def toggle_hub(self):
        on = bool(self.hub_on.get())
        self.apply_name()
        self.apply_port()
        self.settings()["sync_hub"] = on
        if on:
            self.ctl.start_hub()
            self.ctl.codes.new()
        else:
            self.ctl.stop_hub()
        self.persist()
        self.refresh()

    def new_code(self):
        self.ctl.codes.new()
        self.refresh()

    def selected_device(self):
        sel = self.dev_tree.selection()
        return sel[0] if sel and sel[0] != "__none__" else None

    def remove_device(self):
        dev = self.selected_device()
        if not dev:
            messagebox.showinfo(APP, "Click a device in the list first.", parent=self.dlg)
            return
        found = self.ctl.devices.find(dev)
        name = found.get("name", "this device") if found else "this device"
        if messagebox.askyesno(APP, f"Stop syncing with “{name}”?\n\nIts buttons stay as they are. To sync it "
                                    "again later, pair it again with a new code.", parent=self.dlg):
            self.ctl.devices.remove(dev)
            self.refresh()

    def refresh(self):
        if not self.alive():
            return
        s = self.settings()
        port = sync_port(s)
        running = self.ctl.hub is not None
        if running:
            if time.time() - self._addr_at > 10:          # looked up every few seconds, not every refresh
                self._addrs, self._addr_at = local_addresses(), time.time()
            addrs = self._addrs
            if addrs:
                self.hub_status.set(f"On. Other devices reach this computer at {', '.join(addrs)}, port {port}.")
            else:
                self.hub_status.set("On, but this computer doesn't seem to be on a local network right now.")
            self.hub_status_lbl.configure(foreground=INK)
            code = self.ctl.codes.current()
            mins = max(1, (self.ctl.codes.seconds_left() + 59) // 60)
            self.code_var.set(code)
            self.code_note.set(f"Works once, for the next {mins} minute{'s' if mins != 1 else ''}"
                               if not self.ctl.codes.locked() else "Too many wrong codes: pairing is paused for a "
                                                                   "few minutes")
            text = pair_url(addrs[:3] or ["127.0.0.1"], port, code, sync_name(s))   # 3 keeps the code small
            if text != self.qr_text:
                self.qr_text = text
                try:
                    draw_qr(self.qr, qr_matrix(text))
                except ValueError:
                    self.qr.delete("all")
            if not self.pairing.winfo_ismapped():
                self.pairing.grid()
        else:
            if self.hub_on.get() and self.ctl.hub_error:
                self.hub_status.set(self.ctl.hub_error)
                self.hub_status_lbl.configure(foreground="#b3261e")
            else:
                self.hub_status.set("Off. Switch it on to pair a phone or another computer with this one.")
                self.hub_status_lbl.configure(foreground=MUTED)
            self.pairing.grid_remove()
            self.qr_text = None
        sel = self.selected_device()
        self.dev_tree.delete(*self.dev_tree.get_children())
        devices = self.ctl.devices.devices()
        for d in devices:
            last = describe_ago(d["last_seen"]) if d.get("last_seen") else "not yet"
            self.dev_tree.insert("", "end", iid=d["device_id"], values=(tk_safe(d.get("name", "Device")), last))
        if sel and self.dev_tree.exists(sel):
            self.dev_tree.selection_set(sel)
        if not devices:
            self.dev_tree.insert("", "end", iid="__none__", values=("None yet", ""))
        self.fw_var.set(FIREWALL_HINT.format(port=port))
        self.refresh_client()

    # -- client side
    def refresh_client(self):
        client = self.ctl.client()
        state = ("paired", client.get("name"), bool(client.get("first_sync_done"))) if client else ("none",)
        if self.pairing_now:
            state = ("pairing",)
        if state != self.client_state:
            self.client_state = state
            for w in self.client_box.winfo_children():
                w.destroy()
            box = self.client_box
            if state[0] == "paired":
                ttk.Label(box, text=f"This computer syncs with {client.get('name')}.",
                          font=("TkDefaultFont", 10, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
                ttk.Label(box, textvariable=self.client_status, wraplength=520, justify="left").grid(
                    row=1, column=0, columnspan=3, sticky="w", pady=(4, 8))
                row = ttk.Frame(box)
                row.grid(row=2, column=0, columnspan=3, sticky="w")
                if state[2]:
                    ttk.Button(row, text="Sync now", command=self.sync_now).pack(side="left")
                else:
                    ttk.Button(row, text="Choose how to start…", command=self.first_sync).pack(side="left")
                ttk.Button(row, text="Stop syncing", command=self.unpair).pack(side="left", padx=6)
                ttk.Label(box, text="It syncs by itself when Quickpad starts, a few seconds after you save a change, "
                                    "and every two minutes.", foreground=MUTED, wraplength=520,
                          justify="left").grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 0))
            elif state[0] == "pairing":
                ttk.Label(box, text="Pairing…").grid(row=0, column=0, sticky="w")
            else:
                ttk.Label(box, text="Address of the other computer").grid(row=0, column=0, sticky="w", pady=2)
                ttk.Entry(box, textvariable=self.addr_var, width=30).grid(row=0, column=1, sticky="w", padx=8,
                                                                          pady=2)
                ttk.Label(box, text="Pairing code").grid(row=1, column=0, sticky="w", pady=2)
                ttk.Entry(box, textvariable=self.pair_code_var, width=12).grid(row=1, column=1, sticky="w", padx=8,
                                                                              pady=2)
                ttk.Button(box, text="Pair", command=self.pair).grid(row=1, column=2, sticky="w")
                ttk.Label(box, text="On the other computer, open Settings › Sync and switch on “Let phones and other "
                                    "computers sync with this computer”. It shows its address (like 192.168.1.20) "
                                    "and a pairing code.", foreground=MUTED, wraplength=520,
                          justify="left").grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))
        self.client_status.set(self.ctl.status_text())

    def pair(self):
        hosts, port, code = parse_hub_address(self.addr_var.get(), sync_port(self.settings()))
        code = normalise_code(self.pair_code_var.get()) or code
        if not hosts:
            messagebox.showinfo(APP, "Type the other computer's address first. It's shown in its Settings › Sync.",
                                parent=self.dlg)
            return
        if len(code) != 9:
            messagebox.showinfo(APP, "Type the 8-letter pairing code shown on the other computer (like ABCD-EFGH).",
                                parent=self.dlg)
            return
        if not self.panel.cfg_ok:
            messagebox.showwarning(APP, "Your buttons file couldn't be read, so syncing is switched off.",
                                   parent=self.dlg)
            return
        self.pairing_now = True
        self.refresh_client()
        device_id = self.ctl.devices.my_device_id()
        name = sync_name(self.settings())
        own_hub = self.ctl.devices.hub_id()

        def work():
            try:
                result = (pair_with_hub(hosts, port, code, device_id, name), None)
            except SyncError as e:
                result = (None, e)
            except Exception as e:  # noqa: BLE001
                result = (None, SyncError("problem", str(e)))
            self.panel.post(lambda: self.paired(result, hosts, port, own_hub))
        threading.Thread(target=work, daemon=True).start()

    def paired(self, result, hosts, port, own_hub):
        client, err = result
        self.pairing_now = False
        where = ", ".join(hosts)
        if err is None and client.get("hub_id") == own_hub:
            err = SyncError("self")
        if err is not None:
            if self.alive():
                self.refresh_client()
            text = {"bad code": "That pairing code didn't work. Check it, or click New code on the other computer "
                                "and type the new one.",
                    "locked": "Too many wrong codes were tried, so the other computer has paused pairing for 10 "
                              "minutes. Try again after that, with a new code.",
                    "unreachable": f"Couldn't reach {where} on port {port}. Check the address, that Quickpad is open "
                                   "there with sync switched on, and that both are on the same network.\n\n" +
                                   FIREWALL_HINT.format(port=port),
                    "self": "That's this computer's own address. Type the other computer's address."}.get(
                err.kind, f"Couldn't pair: {err}")
            messagebox.showerror(APP, text, parent=self.dlg if self.alive() else self.panel.root)
            return
        self.ctl.set_client(client)
        self.pair_code_var.set("")
        if self.alive():
            self.refresh_client()
        self.first_sync()

    def first_sync(self):
        client = self.ctl.client()
        if not client:
            return
        parent = self.dlg if self.alive() else self.panel.root
        mode = self.choose_first_sync(parent, client.get("name") or "the other computer",
                                      only_starter_buttons(self.panel.cfg))
        if mode:
            self.ctl.sync_now(mode, done=self.first_done)
            self.refresh_client()

    def choose_first_sync(self, parent, hub_name, fresh):
        return FirstSyncDialog.ask(parent, hub_name, fresh)

    def first_done(self, problem):
        client = self.ctl.client() or {}
        if self.alive():
            self.refresh_client()
        if problem:
            messagebox.showwarning(APP, f"Paired with {client.get('name', 'the other computer')}, but the first sync "
                                        f"didn't work: {self.ctl.status_text()}\n\nIt will keep trying by itself.",
                                   parent=self.dlg if self.alive() else self.panel.root)

    def sync_now(self):
        self.ctl.sync_now()
        self.refresh_client()

    def unpair(self):
        client = self.ctl.client() or {}
        if messagebox.askyesno(APP, f"Stop syncing this computer with {client.get('name', 'the other computer')}?\n\n"
                                    "The buttons here stay as they are.", parent=self.dlg):
            self.ctl.unpair()
            self.refresh_client()

    def save(self):
        """Settings › Save: take anything still being typed in the name or port boxes."""
        if self.ctl is not None:
            self.apply_name()
            self.apply_port()


# ================================================================ dialogs: folder chooser, password

def folder_places():
    """Quick-jump shortcuts for the folder chooser: home folders and any USB sticks / other disks."""
    home = os.path.expanduser("~")
    out = [("Home", home)]
    for name in ("Desktop", "Documents", "Downloads"):
        path = os.path.join(home, name)
        if os.path.isdir(path):
            out.append((name, path))
    roots = []
    if sys.platform.startswith("win"):
        roots = [(f"Drive {c}:", f"{c}:\\") for c in "DEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{c}:\\")]
    else:
        user = os.path.basename(home)
        bases = ["/Volumes"] if IS_MAC else [f"/media/{user}", f"/run/media/{user}", "/media", "/mnt"]
        for base in bases:
            try:
                for name in sorted(os.listdir(base)):
                    path = os.path.join(base, name)
                    if os.path.isdir(path) and os.access(path, os.R_OK):
                        roots.append((f"USB / disk: {name}", path))
            except OSError:
                pass
    seen = {p for _, p in out}
    return out + [(n, p) for n, p in roots if p not in seen]


class FolderChooser(tk.Toplevel):
    """Our own folder picker, because Tk's built-in one has a 'new folder' button that just goes back up."""

    def __init__(self, parent, title, prompt, start, ok_text):
        super().__init__(parent)
        self.title(f"{APP} — {title}")
        self.transient(parent)
        self.result = None
        self.geometry("640x600")
        self.minsize(540, 480)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        base = tkfont.nametofont("TkDefaultFont").actual("family")
        big, bold = tkfont.Font(family=base, size=12), tkfont.Font(family=base, size=12, weight="bold")

        body = ttk.Frame(self, padding=14)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=prompt, font=big, wraplength=580, justify="left").pack(anchor="w")

        places = ttk.Frame(body)
        places.pack(fill="x", pady=(10, 4))
        for i, (name, path) in enumerate(folder_places()):
            ttk.Button(places, text=name, command=lambda p=path: self.go(p)).grid(
                row=i // 3, column=i % 3, sticky="ew", padx=2, pady=2)
        for c in range(3):
            places.columnconfigure(c, weight=1)

        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=(8, 4))
        ttk.Button(bar, text="⬆  Up one folder", command=self.up).pack(side="left")
        ttk.Button(bar, text="＋  New folder…", command=self.new_folder).pack(side="right")
        self.here = tk.StringVar()
        ttk.Label(body, textvariable=self.here, font=bold, wraplength=580, justify="left").pack(anchor="w", pady=(4, 4))

        box = ttk.Frame(body)
        box.pack(fill="both", expand=True)
        self.lb = tk.Listbox(box, font=big, activestyle="none", exportselection=False, selectbackground=SOLID,
                             selectforeground=SOLID_TEXT, highlightthickness=2, highlightbackground=EDGE)
        sb = ttk.Scrollbar(box, orient="vertical", command=self.lb.yview)
        self.lb.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.lb.pack(side="left", fill="both", expand=True)
        self.lb.bind("<Double-Button-1>", lambda e: self.enter())
        self.lb.bind("<Return>", lambda e: self.enter())
        self.hint = ttk.Label(body, text="Double-click a folder to open it.", foreground=MUTED)
        self.hint.pack(anchor="w", pady=(4, 0))

        btns = ttk.Frame(body)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text=ok_text, command=self.ok).pack(side="right")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=8)
        self.bind("<Escape>", lambda e: self.destroy())

        self.cur = ""
        self.names = []
        self.go(start if start and os.path.isdir(start) else os.path.expanduser("~"))
        self.wait_visibility()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.lb.focus_set()

    def go(self, path):
        try:
            names = sorted((n for n in os.listdir(path) if not n.startswith(".") and os.path.isdir(os.path.join(path, n))),
                           key=str.lower)
        except OSError as e:
            messagebox.showwarning(APP, f"Can't open that folder:\n{e}", parent=self)
            return False
        self.cur, self.names = os.path.abspath(path), names
        self.here.set(self.cur)
        self.lb.delete(0, "end")
        for n in names:
            self.lb.insert("end", "▸  " + n)
        self.hint.config(text="Double-click a folder to open it." if names else "No folders in here. Use New folder… "
                                                                              "or pick this one.")
        return True

    def up(self):
        parent = os.path.dirname(self.cur.rstrip("\\/")) or self.cur
        if parent and parent != self.cur:
            self.go(parent)

    def enter(self):
        sel = self.lb.curselection()
        if sel:
            self.go(os.path.join(self.cur, self.names[sel[0]]))

    def new_folder(self):
        name = simpledialog.askstring(APP, "Name for the new folder:", initialvalue="Quickpad backups", parent=self)
        if not name:
            return
        name = name.strip()
        if not name or name in (".", "..") or any(c in name for c in '/\\:*?"<>|'):
            messagebox.showwarning(APP, "Please use a plain name (no / \\ : * ? \" < > | characters).", parent=self)
            return
        path = os.path.join(self.cur, name)
        try:
            os.makedirs(path, exist_ok=False)
        except FileExistsError:
            messagebox.showinfo(APP, f"There's already a folder called “{name}” here. Opening it.", parent=self)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't create the folder:\n{e}", parent=self)
            return
        self.go(path)

    def ok(self):
        self.result = self.cur
        self.destroy()


def choose_folder(parent, title, prompt, start="", ok_text="Use this folder"):
    """Show the folder chooser; returns the chosen folder or None."""
    dlg = FolderChooser(parent, title, prompt, start, ok_text)
    parent.wait_window(dlg)
    return dlg.result


class PasswordDialog(tk.Toplevel):
    def __init__(self, parent, title, prompt, confirm=False):
        super().__init__(parent)
        self.title(f"{APP} — {title}")
        self.transient(parent)
        self.result = None
        self.confirm = confirm
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        body = ttk.Frame(self, padding=16)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=prompt, wraplength=360, justify="left").grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(body, text="Password").grid(row=1, column=0, sticky="w", pady=(12, 0))
        self.a = ttk.Entry(body, show="•", width=26)
        self.a.grid(row=1, column=1, sticky="ew", pady=(12, 0), padx=(8, 0))
        self.b = None
        if confirm:
            ttk.Label(body, text="Again").grid(row=2, column=0, sticky="w", pady=(6, 0))
            self.b = ttk.Entry(body, show="•", width=26)
            self.b.grid(row=2, column=1, sticky="ew", pady=(6, 0), padx=(8, 0))
        self.msg = ttk.Label(body, text="", foreground="#b3261e")
        self.msg.grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 0))
        btns = ttk.Frame(body)
        btns.grid(row=4, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="OK", command=self.ok).pack(side="right")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=8)
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.wait_visibility()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.a.focus_set()

    def ok(self):
        pw = self.a.get()
        if self.confirm:
            if len(pw) < 4:
                self.msg.config(text="Please use at least 4 characters.")
                return
            if pw != self.b.get():
                self.msg.config(text="The two passwords don't match.")
                return
        elif not pw:
            return
        self.result = pw
        self.destroy()


def ask_password(parent, title, prompt, confirm=False):
    dlg = PasswordDialog(parent, title, prompt, confirm)
    parent.wait_window(dlg)
    return dlg.result


def backup_to_folder(parent, cfg, remember):
    """Export setup… (also the panel's Back up…): ask for a folder and save one complete, dated, verified setup file
    there (SPEC-3.3 §5). `remember` is the settings dict that keeps the last folder. Returns the folder used, or
    None."""
    folder = choose_folder(parent, "Export setup",
                           "Where should the setup file go? A USB stick, your OneDrive folder, anywhere you like. "
                           "Use New folder… to make a fresh one.", remember.get("last_backup_folder", ""),
                           "Save it here")
    if not folder:
        return None
    path = os.path.join(folder, f"Quickpad-setup-{datetime.datetime.now():%Y-%m-%d_%H%M%S}{SETUP_EXT}")
    try:
        fams, n = write_export(cfg, path)
    except OSError as e:
        messagebox.showerror(APP, f"Couldn't save the setup file to {folder}:\n{e}", parent=parent)
        return None
    remember["last_backup_folder"] = folder
    _, _, lists, flows = setup_counts(cfg)
    extra = "".join(f", {k} {w}{'s' if k != 1 else ''}" for k, w in ((lists, "saved list"), (flows, "workflow")) if k)
    messagebox.showinfo(APP, f"Saved {fams} families, {n} buttons{extra} and your settings to:\n{path}\n\n"
                             "To use them on another computer, install Quickpad there, copy this file across "
                             "and click Restore… on the panel.", parent=parent)
    return folder


def describe_setup_file(cfg, info):
    """'This file has 3 families, 40 buttons and 1 workflow (from Quickpad 3.3.0 on linux, 12 Oct 2026).'"""
    fams, n, lists, flows = setup_counts(cfg)
    parts = [f"{fams} famil{'ies' if fams != 1 else 'y'}", f"{n} button{'s' if n != 1 else ''}"]
    parts += [f"{k} {w}{'s' if k != 1 else ''}" for k, w in ((lists, "saved list"), (flows, "workflow")) if k]
    text = "This file has " + (", ".join(parts[:-1]) + " and " + parts[-1]) + "."
    try:
        when = datetime.datetime.fromisoformat(str(info.get("at", ""))).strftime("%d %b %Y").lstrip("0")
    except ValueError:
        when = ""
    if info.get("version"):
        text = text[:-1] + f" (saved by Quickpad {info['version']}" + \
               (f" on {info['platform']}" if info.get("platform") else "") + (f", {when}" if when else "") + ")."
    return text


class ImportChoice(tk.Toplevel):
    """Import setup: Replace everything, Merge, or Cancel, each explained in plain words. `result` is "replace",
    "merge" or None."""

    def __init__(self, parent, summary):
        super().__init__(parent)
        self.title(f"{APP} — Import setup")
        self.transient(parent)
        self.result = None
        body = ttk.Frame(self, padding=16)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=summary, wraplength=460, justify="left").pack(anchor="w")
        for value, title, text in (
                ("replace", "Replace everything",
                 "Use the buttons, saved lists, workflows and settings in the file instead of the ones here."),
                ("merge", "Merge",
                 "Keep what's here and add what's in the file. Where the same button was changed in both places, "
                 "the newer change wins.")):
            row = ttk.Frame(body)
            row.pack(fill="x", pady=(12, 0))
            ttk.Button(row, text=title, width=20, command=lambda v=value: self.pick(v)).pack(side="left", anchor="n")
            ttk.Label(row, text=text, wraplength=300, justify="left", foreground=MUTED).pack(side="left", padx=(10, 0))
        ttk.Label(body, text="Your current setup is backed up first either way.", foreground=MUTED).pack(
            anchor="w", pady=(14, 0))
        ttk.Button(body, text="Cancel", command=self.destroy).pack(anchor="e", pady=(10, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        try:
            self.attributes("-topmost", True)      # the panel may be on top of everything
        except tk.TclError:
            pass

    def pick(self, value):
        self.result = value
        self.destroy()


def ask_import_mode(parent, summary):
    dlg = ImportChoice(parent, summary)
    try:
        dlg.wait_visibility()
        dlg.grab_set()
    except tk.TclError:
        pass
    parent.wait_window(dlg)
    return dlg.result


def import_setup_file(parent, current, start=""):
    """Import setup… (also the panel's Restore…): pick a .quickpad setup file or an older .json backup, choose Replace
    everything or Merge, make a safety backup of the current setup, and work out the result (SPEC-3.3 §5). Returns
    (new config, "replace" | "merge"), or None if nothing should change. The caller saves and applies it."""
    start = start if start and os.path.isdir(start) else os.path.expanduser("~")
    path = filedialog.askopenfilename(parent=parent, title="Choose a Quickpad setup file or backup", initialdir=start,
                                      filetypes=[("Quickpad setup or backup", f"*{SETUP_EXT} *.json"),
                                                 ("All files", "*")])
    if not path:
        return None
    info = {}
    try:
        incoming = load_backup_file(path, info)
    except ValueError as e:
        messagebox.showerror(APP, f"Couldn't read {os.path.basename(path)}:\n{e}", parent=parent)
        return None
    mode = ask_import_mode(parent, describe_setup_file(incoming, info))
    if mode not in ("replace", "merge"):
        return None
    errors = write_backup(current)
    if errors and not messagebox.askyesno(
            APP, "Couldn't make the safety copy of your current setup:\n\n" + "\n".join(errors) +
                 "\n\nImport anyway?", parent=parent):
        return None
    return restore_into(current, incoming, mode == "replace"), mode


# ================================================================ panel

BACKUP_HOURS = {"daily": 24, "weekly": 168}


def button_look(colour):
    """(resting bg, resting text, hover bg, hover text, pressed bg, pressed text) for a button in `colour`."""
    if THEME == "contrast":
        hot = "#ffe600"
        return "#000000", "#ffffff", hot, "#000000", shade(hot, 0.3), "#000000"
    rest, rest_fg = (shade(colour, 0.66), "#ffffff") if THEME == "dark" else (tint(colour, 0.86), INK)
    press = shade(colour, 0.25)
    return rest, rest_fg, colour, contrast(colour), press, contrast(press)


def copy_button(b):
    """An exact copy of a button (name, everything it types and does, symbol, "Are you sure?"), minus its shortcut
    key, since two buttons can't share one. The copy is a new button, so it gets its own id."""
    dup = copy.deepcopy(b)
    dup.pop("shortcut", None)
    if "id" in dup:
        fresh_ids(dup, "button")
    return dup


class FamilyPicker(tk.Frame):
    """The family dropdown, made big and obvious: the current family on a bar in its own colour, a dark block with
    a large arrow, and a large, coloured menu. (A stock ttk combobox is small and easy to miss.)"""

    def __init__(self, parent, font, on_pick, bg, extra=None):
        super().__init__(parent, bg=bg)
        self.font, self.on_pick, self.families = font, on_pick, []
        self.extra = extra           # adds more to the menu (the panel's Workflows ▸)
        tk.Label(self, text="Show family:", bg=bg, fg=INK, anchor="w", font=("TkDefaultFont", 10, "bold")).pack(fill="x")
        self.box = tk.Frame(self, bg=EDGE, padx=2, pady=2, cursor="hand2", takefocus=1,
                            highlightthickness=3, highlightbackground=bg, highlightcolor=FOCUS_RING)
        self.box.pack(fill="x", pady=(3, 0))
        inner = tk.Frame(self.box, bg=SOLID)
        inner.pack(fill="x")
        self.name = tk.Label(inner, anchor="w", padx=12, pady=10, font=font, cursor="hand2")
        self.name.pack(side="left", fill="x", expand=True)
        self.arrow = tk.Label(inner, text="▼", bg=SOLID, fg=SOLID_TEXT, font=font, padx=18, cursor="hand2")
        self.arrow.pack(side="right", fill="y")
        for w in (self.box, inner, self.name, self.arrow):
            w.bind("<Button-1>", self.open)
        for key in ("<Return>", "<space>", "<Down>"):
            self.box.bind(key, self.open)

    def update_choices(self, families, current):
        """families: [(name, colour)]; current: the selected name (or ALL_FAMILIES)."""
        self.families = families
        colour = dict(families).get(current)
        self.name.config(text=current, bg=colour or CARD, fg=contrast(colour) if colour else INK)

    def open(self, _event=None):
        menu = tk.Menu(self, tearoff=0, font=self.font, activeborderwidth=0, bd=2, relief="solid")
        width, space = self.box.winfo_width() - 24, max(1, self.font.measure(" "))

        def item(name, colour, fg):
            pad = max(0, (width - self.font.measure(name)) // space)
            active = shade(colour, 0.35)
            menu.add_command(label="  " + name + " " * pad, command=lambda: self.on_pick(name), background=colour,
                             foreground=fg, activebackground=active, activeforeground=contrast(active))
        item(ALL_FAMILIES, CARD, INK)
        for name, colour in self.families:
            item(name, colour, contrast(colour))
        if self.extra:
            self.extra(menu)
        try:
            menu.tk_popup(self.box.winfo_rootx(), self.box.winfo_rooty() + self.box.winfo_height())
        finally:
            menu.grab_release()


class LockScreen(tk.Frame):
    """Covers the whole panel until the right password is typed. A casual lock, not encryption."""

    def __init__(self, panel):
        super().__init__(panel.root, bg=SOLID)
        self.panel = panel
        box = tk.Frame(self, bg=SOLID)
        box.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(box, text="Quickpad is locked", bg=SOLID, fg=SOLID_TEXT, font=("TkDefaultFont", 20, "bold")).pack(pady=(4, 12))
        self.entry = tk.Entry(box, show="•", font=("TkDefaultFont", 16), width=16, justify="center", relief="flat")
        self.entry.pack(ipady=6)
        self.msg = tk.Label(box, text="Type your password and press Enter", bg=SOLID, fg="#c9d1d9", font=("TkDefaultFont", 10))
        self.msg.pack(pady=(8, 8))
        ttk.Button(box, text="Unlock", command=self.try_unlock).pack(ipadx=14, ipady=3)
        self.entry.bind("<Return>", lambda e: self.try_unlock())
        self.place(x=0, y=0, relwidth=1, relheight=1)
        self.lift()
        self.update_idletasks()
        try:
            self.grab_set()          # nothing underneath can be clicked or typed into
        except tk.TclError:
            pass
        self.entry.focus_force()

    def try_unlock(self):
        if password_ok(self.panel.cfg["settings"], self.entry.get()):
            self.panel.unlock()
            return
        self.entry.delete(0, "end")
        self.msg.config(text="That isn't the right password. Try again.", fg="#ffb4ab")
        self.entry.config(state="disabled")
        self.after(1200, lambda: (self.entry.config(state="normal"), self.entry.focus_force()))


def rollbar_text(current_family):
    """What the rolled-up bar says. "click to open" is there because a slim coloured strip with just a name on it
    doesn't look like something that opens."""
    return f"▾   {APP}   ·   {current_family}   ·   click to open"


def make_root():
    """The panel's Tk root. className sets WM_CLASS ("quickpad", "Quickpad"); a bare tk.Tk() advertises "tk"/"Tk",
    and Cinnamon, GNOME and KDE match WM_CLASS against StartupWMClass in quickpad.desktop to pin, group and give an
    icon to a running window — without it, "keep in panel" had nothing to attach to."""
    return tk.Tk(className=APP)


class Panel:
    def __init__(self):
        self.hotkeys = None
        if GlobalHotkeys.possible():
            GlobalHotkeys.prepare()       # has to happen before Tk opens the display
        self.root = make_root()
        self.root.title(APP)
        self.root.minsize(PANEL_MIN_W, PANEL_MIN_H)
        self.fresh_install = not os.path.exists(CONFIG_PATH)
        self.cfg, self.cfg_ok = load_config()
        apply_theme(read_local_theme())
        self.bg = setup_style(self.root)
        self.base_family = tkfont.nametofont("TkDefaultFont").actual("family")
        self.fonts = {}
        self.backend = pick_backend()
        self.backend.window_setup(self.root)
        s = self.cfg["settings"]
        self.collapsed = set(s.get("collapsed", []))
        start = s.get("start_family", "")
        if start == ALL_FAMILIES or start in [f["name"] for f in self.cfg["families"]]:
            s["current_family"] = start
        self.vars = {}
        self.ui_queue = queue.Queue()
        self.busy = False
        self.editor = None
        self.settings_win = None
        self.locked = False
        self.lockscreen = None
        self.faded = False
        self.full_size = None
        self.wake_guard = 0.0        # clicks are ignored for a moment after the panel wakes up from fading
        self.last_active = time.time()
        self._self_iconify = False   # we minimise ourselves briefly on some Wayland setups; that isn't the user
        self._was_minimised = False
        self._save_pos_job = None
        self.shortcuts = {}
        self.btn_labels = []
        self.label_cols = {}
        self.hotkey_problems = {}
        self._hk_last = None
        self._hk_paused = False
        # The running workflow (SPEC-3.3 §4), this session only: {"id", "index" (the step), "auto" (the bar's Auto
        # tick), "back_to" (the family to show again when it ends)}, or None.
        self.flow = None
        self.find_text = ""                  # what is typed in the Find box ("" = show the chosen family as normal)
        self.find_matches = []
        self.last_typed = None               # what the last button typed, for "Undo last"
        self.status_job = None
        self.status_on = False
        self._find_quiet = False
        self.find_hinting = True
        self.instance = None                 # the "one copy only" guard, set by main()
        self.sync = SyncController(self)     # LAN sync: the hub, and syncing with another computer's hub
        self._last_error = (None, 0.0)       # (what, when): don't show the same problem over and over
        if GlobalHotkeys.possible():
            self.hotkeys = GlobalHotkeys(self.on_global_key)
            self.hotkeys.start()
        self.tracker = FocusTracker(self.backend)
        self.tracker.start()

        top = ttk.Frame(self.root, padding=(8, 8, 8, 6))
        top.pack(fill="x")
        self.top_frame = top
        top.columnconfigure((0, 1), weight=1)
        self.picker = FamilyPicker(top, self.font_for(None, extra=2), self.pick_family, self.bg, self.workflow_menu)
        self.picker.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        for i, (text, cmd) in enumerate([("Edit buttons", self.open_editor), ("Settings", self.open_settings),
                                         ("Back up…", self.backup_to_folder), ("Restore…", self.restore_backup)]):
            ttk.Button(top, text=text, command=cmd, style="Big.TButton").grid(
                row=1 + i // 2, column=i % 2, sticky="ew", padx=(0 if i % 2 == 0 else 3, 3 if i % 2 == 0 else 0), pady=3)

        self.make_cursor_bar(top).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(3, 0))

        self.find_var = tk.StringVar()
        self.find_shown = False              # False while the grey "Find a button…" hint is what's in the box
        self.find = ttk.Entry(top, textvariable=self.find_var, font=self.font_for(None, extra=-1))
        self.find.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(8, 0), ipady=3)
        self.find.bind("<FocusIn>", self.find_focus_in)
        self.find.bind("<FocusOut>", self.find_focus_out)
        self.find.bind("<Return>", self.find_enter)
        self.find.bind("<Escape>", self.find_clear)
        self.find.bind("<Down>", lambda e: (self.btn_labels[0].focus_set() if self.btn_labels else None, "break")[1])
        self.find_var.trace_add("write", self.find_changed)
        self.find_hint()

        # Footer: pin toggle on the left, version / update line on the right.
        self.pending = None      # (version, bytes) of a newer release, once found
        self.checking = False
        foot = ttk.Frame(self.root, padding=(8, 4))
        foot.pack(side="bottom", fill="x")
        self.foot_frame = foot
        self.foot_sep = ttk.Separator(self.root)
        self.foot_sep.pack(side="bottom", fill="x")
        self.pin_var = tk.BooleanVar(value=s["always_on_top"])
        ttk.Checkbutton(foot, text="Stay on top", variable=self.pin_var, command=self.pin_toggled,
                        takefocus=0).pack(side="left")
        self.foot = tk.Label(foot, anchor="e", cursor="hand2", font=("TkDefaultFont", 9), bg=self.bg)
        self.foot.pack(side="right")
        self.foot.bind("<Button-1>", lambda e: self.update_clicked())
        self.show_foot()

        # Buttons: a column that scrolls.
        wrap = ttk.Frame(self.root)
        wrap.pack(fill="both", expand=True, padx=(8, 0), pady=(2, 0))
        self.wrap = wrap
        # "Typed" confirmation with an Undo button; shown for a few seconds after a button runs.
        self.status = ttk.Frame(self.root, padding=(8, 4))
        self.status_text = tk.Label(self.status, anchor="w", bg=self.bg, fg=INK, font=self.font_for(None, extra=-1))
        self.status_text.pack(side="left", fill="x", expand=True)
        self.undo_btn = ttk.Button(self.status, text="Undo last", command=self.undo_last, takefocus=0)
        self.fix_btn = ttk.Button(self.status, text="Fix a word…", command=self.fix_last_heard, takefocus=0)
        self.fix_heard = None
        # The workflow bar (Back, Step 2 of 5, Next…), shown above the buttons while a workflow runs.
        self.flow_bar = tk.Frame(self.root, bg=self.bg)
        # The slim bar shown instead of everything else while rolled up (like TypeItIn).
        self.rolled = False
        self.rollbar = self.make_rollbar()
        self.scroll = ttk.Scrollbar(wrap, orient="vertical", takefocus=0)
        self.scroll.pack(side="right", fill="y")
        self.canvas = tk.Canvas(wrap, bg=self.bg, highlightthickness=0, bd=0, yscrollincrement=20,
                                yscrollcommand=self.scroll.set, takefocus=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll.config(command=self.canvas.yview)
        self.body = tk.Frame(self.canvas, bg=self.bg)
        self.canvas.create_window((0, 0), window=self.body, anchor="nw", tags="body")
        self.canvas.bind("<Configure>", self.on_canvas_resize)
        self.body.bind("<Configure>", lambda e: self.sync_scroll())
        self.root.bind_all("<MouseWheel>", self.on_wheel)
        self.root.bind_all("<Button-4>", self.on_wheel)
        self.root.bind_all("<Button-5>", self.on_wheel)
        self.root.bind_all("<KeyPress>", self.on_key)
        for ev in ("<Enter>", "<Motion>", "<ButtonPress>"):
            self.root.bind(ev, self.touch_activity, add="+")
        self.root.bind("<Configure>", self.on_configure, add="+")
        self.root.bind("<Unmap>", self.on_unmap, add="+")
        self.root.bind("<Map>", self.on_map, add="+")

        self.root.geometry(self.start_geometry())
        self.apply_pin()
        self.build()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)
        self.root.after(50, self.pump_ui)

        for msg in self.backend.problems():
            messagebox.showwarning(APP, msg)

        self.install_error_handlers()
        log.info("Quickpad %s started | Python %s | Tk %s | %s | %s | typing via %s | data %s", VERSION,
                 platform.python_version(), self.root.tk.call("info", "patchlevel"), platform.platform(),
                 os.environ.get("XDG_SESSION_TYPE", "?"), self.backend.name, CONFIG_DIR)
        self.root.after(3000, self.backup_tick)
        self.root.after(1000, self.idle_tick)
        self.root.after(300, self.maybe_show_first_run_wizard)
        self.root.after(1800, self.maybe_whats_new)
        self.root.after(6000, self.maybe_offer_dictation)
        if s.get("auto_update_check", True):
            self.root.after(4000, self.auto_check)
        self.root.after(1500, self.sync.start)
        if has_password(s) and s.get("lock_on_start"):
            self.lock()
        if not s.get("show_on_start", True):
            self._was_minimised = True
            self.root.iconify()

    # ---- fonts / sizes

    def font_for(self, size_key, extra=0):
        """A bold font for a button size key (None = the global text size), optionally `extra` points bigger."""
        key = size_key or self.cfg["settings"].get("text_size", "normal")
        pt = SIZES.get(key, SIZES["normal"])[0] + extra
        if pt not in self.fonts:
            self.fonts[pt] = tkfont.Font(family=self.base_family, size=pt, weight="bold")
        return self.fonts[pt]

    # ---- window position, fading, locking, backups (all driven by Settings)

    def geometry_string(self):
        """WxH+X+Y for saving. Must be root.geometry(): winfo_x/y ignore the window frame, so saving those made the
        panel creep down about one title bar every time it was closed and reopened."""
        self.root.update_idletasks()
        return self.root.geometry()

    def start_geometry(self):
        s = self.cfg["settings"]
        geo = s.get("fixed_geometry") if s.get("position_mode") == "fixed" and s.get("fixed_geometry") else s.get("geometry")
        return clamp_geometry(geo, self.root.winfo_screenwidth(), self.root.winfo_screenheight()) or PANEL_DEFAULT_GEOMETRY

    def on_configure(self, event):
        """Remember where the panel was left, a moment after it stops moving."""
        if event.widget is not self.root or self.faded:
            return
        if self._save_pos_job:
            self.root.after_cancel(self._save_pos_job)
        self._save_pos_job = self.root.after(1500, self.remember_position)

    def remember_position(self):
        self._save_pos_job = None
        if self.faded or not self.cfg_ok:
            return
        self.cfg["settings"]["geometry"] = self.geometry_string()
        try:
            save_config(self.cfg)
        except OSError:
            pass

    def editor_open(self):
        return self.editor is not None and self.editor.winfo_exists()

    def dialog_open(self):
        return self.settings_win is not None and self.settings_win.winfo_exists()

    def touch_activity(self, _event=None):
        self.last_active = time.time()
        if self.faded:
            self.unfade()

    def idle_tick(self):
        try:
            s = self.cfg["settings"]
            if not s.get("idle_fade", True) or self.editor_open() or self.dialog_open() or self.busy:
                self.last_active = time.time()
                if self.faded:
                    self.unfade()
            else:
                x, y = self.root.winfo_pointerxy()
                rx, ry = self.root.winfo_rootx(), self.root.winfo_rooty()
                if rx <= x < rx + self.root.winfo_width() and ry <= y < ry + self.root.winfo_height():
                    self.touch_activity()
                elif not self.faded and time.time() - self.last_active >= max(5, int(s.get("idle_seconds", 30))):
                    self.fade()
        except (tk.TclError, ValueError):
            pass
        self.root.after(1000, self.idle_tick)

    def fade(self):
        if self.faded:
            return
        s = self.cfg["settings"]
        self.faded = True
        self.full_size = (self.root.winfo_width(), self.root.winfo_height())
        try:
            self.root.attributes("-alpha", max(0.2, min(0.95, int(s.get("idle_opacity", 50)) / 100)))
        except (tk.TclError, ValueError):
            pass
        style = s.get("idle_style", "rollup")
        if style == "rollup":
            self.roll_up()
        elif style == "shrink":
            w, h = self.full_size
            self.root.minsize(150, 100)
            self.root.geometry(f"{max(220, int(w * 0.8))}x{max(160, int(h * 0.8))}")

    def make_rollbar(self):
        """The bar shown while rolled up. A user couldn't find Settings because this is all he saw of Quickpad after
        30 s idle, and nothing said it could be clicked: the text says so now, and right-click (or Control-click,
        as on the buttons) opens a small menu that reaches Settings and Edit buttons from here."""
        bar = tk.Label(self.root, anchor="w", padx=12, pady=6, cursor="hand2", font=self.font_for(None, extra=-1))
        bar.bind("<Button-1>", lambda e: self.touch_activity())
        bar.bind("<Button-3>", self.rollbar_menu)
        bar.bind("<Control-Button-1>", self.rollbar_menu)
        if IS_MAC:
            bar.bind("<Button-2>", self.rollbar_menu)
        return bar

    def rollbar_menu_items(self):
        """[(label, command)] for the rolled-up bar's menu; a label of None is a separator. Every item wakes the panel
        first so a dialog never opens over a slim bar."""
        def wake_then(fn):
            def go():
                self.touch_activity()
                fn()
            return go
        return [("Open Quickpad", wake_then(lambda: None)),
                ("Settings…", wake_then(self.open_settings)),
                ("Edit buttons…", wake_then(self.open_editor))]

    def rollbar_menu(self, event):
        if self.locked or self.busy:
            return "break"
        menu = tk.Menu(self.root, tearoff=0, font=self.font_for(None, extra=-1))
        for label, cmd in self.rollbar_menu_items():
            if label is None:
                menu.add_separator()
            else:
                menu.add_command(label=label, command=cmd)
        menu.add_separator()
        menu.add_checkbutton(label="Stay on top", variable=self.pin_var, command=self.pin_toggled)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def roll_up(self):
        """Collapse to a slim bar showing just the name and current family, like a rolled-up window."""
        cur = self.cfg["settings"].get("current_family", ALL_FAMILIES)
        colour = next((f.get("colour") for f in self.cfg["families"] if f["name"] == cur), None)
        step = self.flow_family()
        if step:
            cur, colour = step["name"], step.get("colour")
        self.rollbar.config(text=rollbar_text(cur), bg=colour or SOLID, fg=contrast(colour) if colour else SOLID_TEXT)
        for w in (self.top_frame, self.foot_frame, self.foot_sep, self.wrap, self.status, self.flow_bar):
            w.pack_forget()
        self.rollbar.pack(fill="x")
        self.rolled = True
        self.root.update_idletasks()
        self.root.minsize(150, 20)
        self.root.geometry(f"{self.full_size[0]}x{self.rollbar.winfo_reqheight()}")

    def unroll(self):
        self.rollbar.pack_forget()
        self.top_frame.pack(fill="x")
        self.foot_frame.pack(side="bottom", fill="x")
        self.foot_sep.pack(side="bottom", fill="x")
        self.wrap.pack(fill="both", expand=True, padx=(8, 0), pady=(2, 0))
        if self.status_on:
            self.status.pack(side="bottom", fill="x", before=self.wrap)
        if self.flow_bar.winfo_children():
            self.flow_bar.pack(fill="x", padx=8, pady=(0, 4), before=self.wrap)
        self.rolled = False

    def unfade(self):
        if not self.faded:
            return
        self.faded = False
        self.wake_guard = time.time() + 0.4      # the first click just wakes it; it can't hit a moved button
        try:
            self.root.attributes("-alpha", 1.0)
        except tk.TclError:
            pass
        if self.rolled:
            self.unroll()
        self.root.minsize(PANEL_MIN_W, PANEL_MIN_H)
        if self.full_size:
            w, h = self.full_size
            here = parse_geometry(self.root.geometry())
            x, y = (here[2], here[3]) if here else (0, 0)
            screen_h = self.root.winfo_screenheight()
            # Unrolling grows downwards; if that would run off the bottom of the screen, slide it up instead.
            pos = f"+{x}+{max(0, screen_h - h)}" if y + h > screen_h else ""
            self.root.geometry(f"{w}x{h}{pos}")

    def lock(self):
        if self.locked or not has_password(self.cfg["settings"]):
            return
        self.locked = True
        self.root.deiconify()
        self.lockscreen = LockScreen(self)

    def unlock(self):
        self.locked = False
        if self.lockscreen is not None:
            try:
                self.lockscreen.grab_release()
            except tk.TclError:
                pass
            self.lockscreen.destroy()
            self.lockscreen = None
        self.touch_activity()

    def on_unmap(self, event):
        if event.widget is self.root and not self._self_iconify and self.root.state() == "iconic":
            self._was_minimised = True

    def on_map(self, event):
        if event.widget is self.root and self._was_minimised:
            self._was_minimised = False
            s = self.cfg["settings"]
            if s.get("lock_on_restore") and has_password(s):
                self.lock()

    def backup_tick(self):
        """Automatic time-based backups, checked every ten minutes while Quickpad is running."""
        try:
            hours = BACKUP_HOURS.get(self.cfg["settings"].get("backup_schedule", "daily"))
            if hours and self.cfg_ok:
                age = latest_backup_age_hours()
                if age is None or age >= hours:
                    for err in write_backup(self.cfg):
                        print(f"{APP}: backup problem: {err}", file=sys.stderr)
        except Exception as e:  # noqa: BLE001
            print(f"{APP}: backup problem: {e}", file=sys.stderr)
        self.root.after(600_000, self.backup_tick)

    # ---- problems: log them, tell the user calmly, offer a report to send

    def install_error_handlers(self):
        self.root.report_callback_exception = lambda t, v, tb: self.on_error(t, v, tb)
        sys.excepthook = lambda t, v, tb: self.on_error(t, v, tb)
        threading.excepthook = lambda a: self.on_error(a.exc_type, a.exc_value, a.exc_traceback)

    def on_error(self, exc_type, exc, tb, what=""):
        """Safe from any thread. Always logged; shown at most once a minute per kind of problem."""
        if issubclass(exc_type, (KeyboardInterrupt, SystemExit)):
            return
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        log.error("%sUnhandled error:\n%s", (what + ": ") if what else "", text)
        kind, when = self._last_error
        sig = (exc_type.__name__, str(exc)[:80])
        if sig == kind and time.time() - when < 60:
            return
        self._last_error = (sig, time.time())
        self.post(lambda: self.show_error(text, what))

    def show_error(self, text, what=""):
        intro = f"{what} hit a problem, but Quickpad is still running." if what else "Something went wrong, but Quickpad is still running."
        if messagebox.askyesno(APP, intro + "\n\nThe details are saved. Copy a report so you can send it to Nick?",
                               parent=self.root):
            self.set_clipboard(support_report(self, text))

    def bring_to_front(self):
        """Another copy was started: show this one instead. A user on Linux Mint saw "nothing happens" — the panel
        was open on another workspace, or behind his mail program, and lift() alone can't change either (Cinnamon
        treats it as focus stealing). So also ask the window manager, the way buttons ask it to focus the target
        window; that request switches workspace and is honoured."""
        self.touch_activity()                     # un-rolls the bar too, so what comes to the front is the panel
        try:
            if self.root.state() in ("iconic", "withdrawn"):
                self.root.deiconify()
            wid = self.backend.own_window()
            if wid:
                self.backend.activate(wid)
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(400, self.apply_pin)
        except tk.TclError:
            pass
        except Exception:  # noqa: BLE001 — a backend that can't find the window must never stop the lift below
            log.exception("bring to front")

    # ---- shortcut keys that work in any program

    def collect_shortcuts(self):
        """Every button's shortcut key, whichever family is showing (the first button to claim a key keeps it)."""
        out = {}
        for f in self.cfg["families"]:
            for b in f["buttons"]:
                sc = normalise_shortcut(b.get("shortcut", ""))
                if sc:
                    out.setdefault(sc, b)
        return out

    def hotkeys_available(self):
        return self.hotkeys is not None

    def hotkeys_wanted(self):
        if not self.hotkeys or self._hk_paused or not self.cfg["settings"].get("global_hotkeys", True):
            return []
        return sorted(sc for sc in self.shortcuts if hotkey_eligible(sc))

    def sync_hotkeys(self, report=False):
        """Reserve the right system-wide keys. Done off the UI thread; `report` shows a message for any that another
        program already owns."""
        if not self.hotkeys:
            return
        want = self.hotkeys_wanted()
        if want == self._hk_last and not report:
            return
        self._hk_last = want

        def work():
            res = self.hotkeys.set_keys(want)
            self.hotkey_problems = {c: why for c, why in res.items() if why}
            if report and self.hotkey_problems:
                self.post(self.show_hotkey_problems)
        threading.Thread(target=work, daemon=True).start()

    def show_hotkey_problems(self):
        lines = []
        for sc, why in self.hotkey_problems.items():
            label = self.shortcuts.get(sc, {}).get("label", "a button")
            lines.append(f"  {sc}   ({label}): {why}")
        messagebox.showwarning(APP, "These shortcut keys can't work in other programs:\n\n" + "\n".join(lines) +
                                    "\n\nThey still work when Quickpad is the active window. Pick a different key "
                                    "in Edit buttons to fix it.", parent=self.root)

    def pause_hotkeys(self):
        """Release every system-wide key (while a dialog is waiting to record a new one)."""
        self._hk_paused = True
        if self.hotkeys:
            self.hotkeys.set_keys([])
            self._hk_last = []

    def resume_hotkeys(self):
        self._hk_paused = False
        self.sync_hotkeys()

    def on_global_key(self, combo):
        self.post(lambda: self.fire_shortcut(combo))          # called from the hotkey thread

    def fire_shortcut(self, combo):
        button = self.shortcuts.get(combo)
        if button:
            self.fire(button, hotkey=True)

    def on_key(self, event):
        """Shortcut keys set on buttons work whenever the panel is the active window."""
        self.touch_activity()
        try:
            if self.locked or event.widget.winfo_toplevel() is not self.root:
                return None
            if event.widget.winfo_class() in ("Entry", "TEntry", "Text", "TCombobox", "Spinbox", "TSpinbox", "Listbox"):
                return None
        except (tk.TclError, KeyError, AttributeError):
            return None
        sc = event_shortcut(event)
        button = self.shortcuts.get(sc)
        if button:
            self.fire(button)
            return "break"
        if sc == "ctrl+f":       # a button's own Ctrl+F shortcut (above) wins; otherwise this jumps to the Find box
            self.find.focus_set()
            return "break"
        if self.flow and sc in ("alt+right", "alt+left"):     # a running workflow's Next / Back
            self.flow_click("next" if sc == "alt+right" else "previous")
            return "break"
        return None

    # ---- Find box

    def find_hint(self):
        self._find_quiet = True
        self.find_hinting = True
        self.find_var.set("Find a button…")
        self.find.configure(foreground=MUTED)
        self._find_quiet = False

    def find_focus_in(self, _e=None):
        if self.find_hinting:
            self._find_quiet = True
            self.find_hinting = False
            self.find_var.set("")
            self.find.configure(foreground=INK)
            self._find_quiet = False

    def find_focus_out(self, _e=None):
        if not self.find_var.get().strip():
            self.find_reset()

    def find_changed(self, *_):
        if self._find_quiet or self.find_hinting:
            return
        text = self.find_var.get().strip()
        if text != self.find_text:
            self.find_text = text
            self.build()

    def find_reset(self):
        """Empty the Find box and go back to the normal list."""
        had = bool(self.find_text)
        self.find_text = ""
        self.find_hint()
        if had:
            self.build()

    def find_clear(self, _e=None):
        self.find_reset()
        self.root.focus_set()
        return "break"

    def find_enter(self, _e=None):
        """Enter presses the first matching button."""
        if self.find_matches:
            button = self.find_matches[0]
            self.find_reset()
            self.root.focus_set()
            self.fire(button)
        return "break"

    @staticmethod
    def button_matches(b, words):
        hay = (b.get("label", "") + " " + " ".join(str(st.get("value", "")) for st in b.get("steps", [])
                                                   if st.get("type") == "text")).lower()
        return all(w in hay for w in words)

    # ---- "Typed" confirmation and Undo last

    def show_status(self, text, undo=False, seconds=4, heard=None):
        if self.status_job:
            self.root.after_cancel(self.status_job)
            self.status_job = None
        self.status_text.config(text=text, wraplength=max(160, self.root.winfo_width() - 190))
        self.fix_heard = heard
        self.undo_btn.pack_forget()
        self.fix_btn.pack_forget()
        if undo:
            self.undo_btn.pack(side="right")
        if heard:
            self.fix_btn.pack(side="right", padx=(0, 4))
        self.status_on = True
        if not self.rolled:
            self.status.pack(side="bottom", fill="x", before=self.wrap)
        self.status_job = self.root.after(int(seconds * 1000), self.hide_status)

    def hide_status(self):
        self.status_job = None
        self.status_on = False
        self.last_typed = None
        self.status.pack_forget()

    def after_run(self, label, runner, aborted, button=None):
        n = runner.typed if runner.undoable else 0
        self.last_typed = {"n": n} if n > 0 else None
        name = tk_safe(label)
        if aborted:
            text = f"Stopped   {name}"
        elif runner.typed:
            text = f"Typed ✓   {name}"
        else:
            text = f"Done ✓   {name}"
        heard = runner.last_heard if not aborted and self.cfg["settings"].get("dictation_show_heard", True) else None
        if heard:
            text += "\nHeard: “" + tk_safe(heard[0][:160]) + ("…" if len(heard[0]) > 160 else "") + "”"
            if heard[2]:
                text += "  (" + ", ".join(f"{a} → {b or 'nothing'}" for a, b in heard[2][:3]) + ")"
        self.show_status(text, undo=bool(self.last_typed), seconds=25 if heard else 15 if self.last_typed else 4,
                         heard=heard)
        if not aborted:
            record_usage(label, runner.stats)
            # Only now, with the whole button done (never part way through it, and never after Cancel or a problem),
            # does a running workflow move on.
            self.workflow_after_button(button, getattr(runner, "wf_override", None))

    def fix_last_heard(self):
        """The "Fix a word…" button after a dictation typed without checking: teach a correction for next time."""
        heard = self.fix_heard
        if not heard:
            return
        self.hide_status()
        if teach_word(self.root, self, ""):
            self.show_status("Saved ✓  It will use that from the next dictation.", seconds=4)

    def undo_last(self):
        """Take back what the last button typed by pressing Backspace that many times in the other program."""
        info, self.last_typed = self.last_typed, None
        if not info or self.busy or self.locked:
            return
        self.hide_status()
        n = min(int(info["n"]), 5000)
        self.busy = True
        runner = Runner(self, self.tracker.last, 0)

        def work():
            try:
                runner.check_ready()
                with keys_released(self.backend):
                    runner.refocus()
                    self.backend.backspace(n)
                self.post(lambda: self.show_status("Undone ✓", seconds=3))
            except Abort:
                pass                 # check_ready has already said why
            except Exception:  # noqa: BLE001
                self.on_error(*sys.exc_info()[:3], what="Undo")
            finally:
                self.busy = False
        self.launch(work)

    def launch(self, work):
        """Run a button's work on its own thread. On some Wayland setups the panel steps out of the way first so the
        other program gets the keyboard back."""
        if self.backend.hide_to_refocus:
            self._self_iconify = True
            self.root.iconify()
            self.root.after(350, lambda: threading.Thread(target=work, daemon=True).start())
            self.root.after(500, self._restore_when_done)
        else:
            threading.Thread(target=work, daemon=True).start()

    # ---- right-click menu on a button

    def locate(self, b):
        for fi, f in enumerate(self.cfg["families"]):
            for bi, x in enumerate(f["buttons"]):
                if x is b:
                    return fi, bi
        return None, None

    def quick_menu(self, event, b):
        if self.locked or self.busy:
            return "break"
        fi, bi = self.locate(b)
        if fi is None:
            return "break"
        fams = self.cfg["families"]
        n = len(fams[fi]["buttons"])
        menu = tk.Menu(self.root, tearoff=0, font=self.font_for(None, extra=-1))
        menu.add_command(label="Edit this button…", command=lambda: self.open_editor(select=(fi, bi)))
        menu.add_command(label="Make a copy", command=lambda: self.quick_edit("copy", fi, bi))
        menu.add_separator()
        menu.add_command(label="Move up", command=lambda: self.quick_edit("up", fi, bi),
                         state="normal" if bi > 0 else "disabled")
        menu.add_command(label="Move down", command=lambda: self.quick_edit("down", fi, bi),
                         state="normal" if bi < n - 1 else "disabled")
        others = [(i, f["name"]) for i, f in enumerate(fams) if i != fi]
        if others:
            sub = tk.Menu(menu, tearoff=0, font=self.font_for(None, extra=-1))
            for i, name in others:
                sub.add_command(label=tk_safe(name), command=lambda i=i: self.quick_edit("move", fi, bi, i))
            menu.add_cascade(label="Move to another family", menu=sub)
            dup = tk.Menu(menu, tearoff=0, font=self.font_for(None, extra=-1))
            for i, name in others:
                dup.add_command(label=tk_safe(name), command=lambda i=i: self.quick_edit("copyto", fi, bi, i))
            menu.add_cascade(label="Copy to another family", menu=dup)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def quick_edit(self, what, fi, bi, target=None):
        if self.editor_open():
            messagebox.showinfo(APP, "Save or close the button editor first, then try again.", parent=self.editor)
            return
        if not self.cfg_ok:
            messagebox.showwarning(APP, "Your buttons file couldn't be read, so changes are switched off to avoid "
                                        "overwriting it.")
            return
        fam = self.cfg["families"][fi]
        buttons = fam["buttons"]
        if what == "copy":
            dup = copy_button(buttons[bi])       # two buttons can't share a shortcut key; the copy gets its own id
            dup["label"] = dup.get("label", "Button") + " (copy)"
            buttons.insert(bi + 1, dup)
            touch_family(fam)
        elif what in ("up", "down"):
            j = bi + (-1 if what == "up" else 1)
            if not 0 <= j < len(buttons):
                return
            buttons[bi], buttons[j] = buttons[j], buttons[bi]
            touch_family(fam)
        elif what == "move" and target is not None:
            moved = buttons.pop(bi)
            self.cfg["families"][target]["buttons"].append(moved)
            touch_button(moved)
            touch_family(fam)
            touch_family(self.cfg["families"][target])
        elif what == "copyto" and target is not None:
            self.cfg["families"][target]["buttons"].append(copy_button(buttons[bi]))
            touch_family(self.cfg["families"][target])
        try:
            save_config(self.cfg)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't save your buttons:\n{e}")
        self.build(keep_scroll=True)

    def hover_ok(self):
        return (self.cfg["settings"].get("hover_preview", True) and not self.locked and not self.busy
                and not self.faded and not self.rolled)

    # ---- first run

    def maybe_show_first_run_wizard(self):
        if not self.fresh_install or self.locked or self.dialog_open() or self.editor_open():
            return
        FirstRunWizard(self)

    # ---- what's new, look changes

    def maybe_whats_new(self):
        try:
            if self.locked:
                self.root.after(5000, self.maybe_whats_new)
                return
            seen = read_seen_version()
            if not seen:
                seen = "" if self.fresh_install else "2.4"    # an existing install from before this file existed
                if not seen:
                    write_seen_version()
                    return
            if seen == VERSION:
                return
            write_seen_version()
            entries = notes_since(seen)
            if entries:
                WhatsNewDialog(self.root, entries)
        except Exception:  # noqa: BLE001
            log.exception("what's-new window")

    def show_whats_new(self):
        WhatsNewDialog(self.root, WHATS_NEW[:3])

    def maybe_offer_dictation(self):
        """Once per computer, if dictation isn't set up (say after a double-click install, which can't set it up
        itself): offer to do it now."""
        try:
            if self.locked or self.dialog_open() or self.editor_open():
                self.root.after(30000, self.maybe_offer_dictation)
                return
            if os.path.exists(DICTATION_OFFERED_PATH) or engine_status()[0]:
                return
            with open(DICTATION_OFFERED_PATH, "w", encoding="utf-8") as f:
                f.write(VERSION)
            if messagebox.askyesno(APP, "Set up dictation on this computer now?\n\nQuickpad can listen and type what "
                                        "you say, worked out on this computer. Setting it up takes a few minutes and "
                                        "needs the internet. (You can also do it later in Settings > Dictation.)",
                                   parent=self.root):
                self.open_settings()
                if self.dialog_open():
                    self.settings_win.nb.select(self.settings_win.tabs["Dictation"])
                    self.settings_win.setup_dictation()
        except Exception:  # noqa: BLE001
            log.exception("dictation offer")

    def restart_self(self):
        """Start a fresh copy and close this one (used when the look changes)."""
        self.save_state()
        try:
            rest = [a for a in sys.argv[1:] if a not in ("--restart", "--child")]
            subprocess.Popen([sys.executable, os.path.abspath(__file__), "--restart", *rest], close_fds=True)
        except OSError as e:
            messagebox.showerror(APP, f"Quickpad couldn't restart itself: {e}\nPlease close it and start it again.")
            return
        self.quit()

    # ---- the button list

    def pump_ui(self):
        """Run UI requests from the button worker thread on the Tk thread."""
        try:
            while True:
                fn, box, done = self.ui_queue.get_nowait()
                try:
                    box["v"] = fn()
                except Exception as e:  # noqa: BLE001
                    box["e"] = e
                finally:
                    done.set()
        except queue.Empty:
            pass
        self.root.after(50, self.pump_ui)

    def apply_pin(self):
        self.pin_var.set(bool(self.cfg["settings"].get("always_on_top", True)))
        self.root.attributes("-topmost", self.pin_var.get())

    def pin_toggled(self):
        self.cfg["settings"]["always_on_top"] = bool(self.pin_var.get())
        self.root.attributes("-topmost", self.pin_var.get())
        if self.cfg_ok:
            try:
                save_config(self.cfg)
            except OSError:
                pass

    def family_names(self):
        return [f["name"] for f in self.cfg["families"]]

    def select_family(self, name):
        names = self.family_names()
        if name != ALL_FAMILIES and name not in names:
            match = [n for n in names if n.lower() == name.strip().lower()]
            if not match:
                return
            name = match[0]
        self.cfg["settings"]["current_family"] = name
        self.build()

    def pick_family(self, name):
        """A family chosen from the family list. Picking one while a workflow runs ends the workflow."""
        self.flow = None
        self.select_family(name)

    # ---- workflows (SPEC-3.3 §4): one group at a time, with Back and Next

    def workflow_menu(self, menu):
        """Workflows ▸ at the bottom of the family list: start one (the last one used comes first), or end it."""
        font = self.picker.font
        flows = self.cfg.get("workflows") or []
        last = workflow_by_id(self.cfg, self.cfg["settings"].get("last_workflow"))
        menu.add_separator()
        if last and not self.flow:
            menu.add_command(label="  ▶  Start " + tk_safe(last.get("name", "")),
                             command=lambda: self.start_workflow(last["id"]))
        sub = tk.Menu(menu, tearoff=0, font=font)
        for w in ([last] if last else []) + [w for w in flows if w is not last]:
            sub.add_command(label=("▶ " if w is last else "    ") + tk_safe(w.get("name", "")),
                            command=lambda i=w["id"]: self.start_workflow(i))
        if not flows:
            sub.add_command(label="No workflows yet", state="disabled")
        sub.add_separator()
        if self.flow:
            sub.add_command(label="End this workflow", command=self.end_workflow)
        sub.add_command(label="Make or change workflows…", command=lambda: self.open_editor(tab="workflows"))
        menu.add_cascade(label="  Workflows  ▸", menu=sub)

    def flow_family(self):
        """The family of the step the running workflow is on, or None if none is running. Ends the workflow if it
        was deleted or has no groups left, and moves off a step whose group was deleted."""
        if not self.flow:
            return None
        wf = workflow_by_id(self.cfg, self.flow["id"])
        index = workflow_step(self.cfg, wf, self.flow["index"], "stay") if wf else None
        if index is None:
            back, self.flow = self.flow["back_to"], None
            self.cfg["settings"]["current_family"] = back
            return None
        self.flow["index"] = index
        return family_by_id(self.cfg, wf["steps"][index].get("family_id"))

    def start_workflow(self, wid):
        wf = workflow_by_id(self.cfg, wid)
        if wf is None:
            return
        index = workflow_step(self.cfg, wf, -1, "first")
        if index is None:
            messagebox.showinfo(APP, f"The workflow “{wf.get('name', '')}” has no groups in it yet. Add its steps "
                                     "in Edit buttons › Workflows.", parent=self.root)
            return
        back = self.flow["back_to"] if self.flow else self.cfg["settings"].get("current_family", ALL_FAMILIES)
        self.flow = {"id": wid, "index": index, "auto": bool(wf.get("auto_advance", True)), "back_to": back}
        s = self.cfg["settings"]
        if s.get("last_workflow") != wid:
            s["last_workflow"] = wid             # only to offer it first next time
            if self.cfg_ok:
                try:
                    save_config(self.cfg)
                except OSError:
                    pass
        if self.find_text:
            self.find_reset()
        self.build()

    def end_workflow(self):
        if not self.flow:
            return
        back, self.flow = self.flow["back_to"], None
        self.cfg["settings"]["current_family"] = back if back in self.family_names() else ALL_FAMILIES
        self.build()

    def workflow_go(self, action):
        """Move the running workflow: "next", "previous", "first" or "stay"."""
        if not self.flow:
            return
        wf = workflow_by_id(self.cfg, self.flow["id"])
        index = workflow_step(self.cfg, wf, self.flow["index"], action) if wf else None
        if index is None:
            self.end_workflow()
            return
        if index != self.flow["index"] or action != "stay":
            self.flow["index"] = index
            self.build()

    def flow_click(self, action):
        """Back / Next / Start on the workflow bar (or Alt+Left / Alt+Right). Not while a button is running: it moves
        the workflow itself when it finishes."""
        if not self.busy and not self.locked:
            self.workflow_go(action)

    def workflow_after_button(self, button, override):
        """After a button finished properly: {Workflow name} starts that workflow; otherwise a running workflow does
        what the button's {NextStep}-style command or its own "After this button" choice says."""
        if isinstance(override, tuple):
            wf = find_workflow(self.cfg, override[1])
            if wf:
                self.start_workflow(wf["id"])
            else:
                self.show_status(f"There's no workflow called “{tk_safe(override[1])}”. Check the name in Edit "
                                 "buttons › Workflows.", seconds=8)
            return
        if not self.flow:
            return
        action = workflow_action((button or {}).get("after"), override, self.flow["auto"])
        if action != "stay":
            self.workflow_go(action)

    def show_flow_bar(self, step):
        """The bar above the buttons while a workflow runs (`step` = its current family), or nothing:
        Workflow name · Step 4 of 7 · Adjustments, then ◀ Back  Next ▶  ↺ Start  ✕ End, then the trail and Auto."""
        bar = self.flow_bar
        for w in bar.winfo_children():
            w.destroy()
        wf = workflow_by_id(self.cfg, self.flow["id"]) if (step and self.flow) else None
        if wf is None:
            bar.pack_forget()
            return
        index, live = self.flow["index"], workflow_live_steps(self.cfg, wf)
        pos = live.index(index)
        colour = step.get("colour", PALETTE[0])
        width = max(260, self.root.winfo_width() - 16)
        tk.Label(bar, text=f"{tk_safe(wf.get('name', ''))}  ·  Step {pos + 1} of {len(live)}  ·  "
                           f"{tk_safe(step.get('name', ''))}", bg=colour, fg=contrast(colour), anchor="w",
                 justify="left", padx=10, pady=4, font=self.font_for(None, extra=-1),
                 wraplength=width - 20).pack(fill="x")
        row = tk.Frame(bar, bg=self.bg)
        row.pack(fill="x", pady=(4, 0))
        for i, (text, action, ok) in enumerate([
                ("◀ Back", "previous", workflow_step(self.cfg, wf, index, "previous") != index),
                ("Next ▶", "next", workflow_step(self.cfg, wf, index, "next") != index),
                ("↺ Start", "first", index != live[0]),
                ("✕ End", None, True)]):
            b = ttk.Button(row, text=text, takefocus=0,
                           command=self.end_workflow if action is None else lambda a=action: self.flow_click(a))
            if not ok:
                b.state(["disabled"])
            b.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 3, 0))
            row.columnconfigure(i, weight=1, uniform="flow")
        low = tk.Frame(bar, bg=self.bg)
        low.pack(fill="x", pady=(2, 0))
        auto = tk.BooleanVar(value=self.flow["auto"])

        def auto_changed():
            if self.flow:
                self.flow["auto"] = bool(auto.get())
        ttk.Checkbutton(low, text="Auto", variable=auto, command=auto_changed, takefocus=0).pack(side="right")
        low.auto_var = auto                       # keep the variable alive with its checkbox
        names = [family_by_id(self.cfg, wf["steps"][i].get("family_id"))["name"] for i in live]
        measure = tkfont.nametofont("TkDefaultFont").measure
        trail = step_trail(names, pos, lambda t: measure(t) <= width - 90)
        if trail:
            tk.Label(low, text=tk_safe(trail), bg=self.bg, fg=MUTED, anchor="w").pack(side="left", fill="x",
                                                                                     expand=True)
        if not self.rolled and not bar.winfo_manager():
            bar.pack(fill="x", padx=8, pady=(0, 4), before=self.wrap)

    def sync_scroll(self):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def on_canvas_resize(self, event):
        self.canvas.itemconfigure("body", width=event.width - 8)
        self.fit_labels(event.width)

    def fit_labels(self, width):
        for lbl in self.btn_labels:
            cols = self.label_cols.get(lbl, 1)
            each = (width - 8 - 6 * (cols - 1)) / cols
            lbl.config(wraplength=max(60, int(each) - 2 * 12 - 2 * 2 - 6))

    def on_wheel(self, event):
        w = self.root.winfo_containing(event.x_root, event.y_root)
        path, canvas = str(w), str(self.canvas)
        if not (path == canvas or path.startswith(canvas + ".")):
            return
        up = event.num == 4 or getattr(event, "delta", 0) > 0
        self.canvas.yview_scroll(-3 if up else 3, "units")

    def build(self, keep_scroll=False):
        y = self.canvas.yview()[0] if keep_scroll else 0.0
        for w in self.body.winfo_children():
            w.destroy()
        self.btn_labels, self.label_cols = [], {}
        self.shortcuts = self.collect_shortcuts()
        names = self.family_names()
        current = self.cfg["settings"].get("current_family", ALL_FAMILIES)
        if current not in names:
            current = ALL_FAMILIES
        step = self.flow_family()            # while a workflow runs: just the family of the step it's on
        self.picker.font = self.font_for(None, extra=2)
        self.picker.name.config(font=self.picker.font)
        self.picker.arrow.config(font=self.picker.font)
        self.picker.update_choices([(f["name"], f.get("colour", PALETTE[0])) for f in self.cfg["families"]],
                                   step["name"] if step else current)

        words = self.find_text.lower().split()
        searching = bool(words)
        self.find_matches = []
        families = (self.cfg["families"] if (current == ALL_FAMILIES or searching)
                    else [f for f in self.cfg["families"] if f["name"] == current])
        if step and not searching:
            families = [step]
        self.show_flow_bar(step if not searching else None)
        if not searching and not any(f["buttons"] for f in families):
            tk.Label(self.body, text="No buttons here yet.\nClick Edit buttons to add some.", bg=self.bg, fg=INK,
                     justify="center", pady=24).pack(fill="x")
        single = (current != ALL_FAMILIES or step is not None) and not searching
        head = self.font_for(None, extra=-1)
        for f in families:
            shown = [b for b in f["buttons"] if not searching or self.button_matches(b, words)]
            if not shown:
                continue
            name, colour = f["name"], f.get("colour", PALETTE[0])
            closed = (not single) and not searching and name in self.collapsed
            if single:
                tk.Frame(self.body, bg=colour, height=6).pack(fill="x", pady=(2, 8))
            else:
                hdr = tk.Label(self.body, text=("▸  " if closed else "▾  ") + tk_safe(name), anchor="w", bg=colour,
                               fg=contrast(colour), font=head, padx=10, pady=5, cursor="arrow" if searching else "hand2")
                hdr.pack(fill="x", pady=(10, 6))
                if not searching:
                    hdr.bind("<Button-1>", lambda e, n=name: self.toggle(n))
            if closed:
                continue
            try:
                cols = max(1, min(4, int(f.get("columns", 1))))
            except (TypeError, ValueError):
                cols = 1
            size = f.get("size") if f.get("size") in SIZES else None
            grid = tk.Frame(self.body, bg=self.bg)
            grid.pack(fill="x")
            for c in range(cols):
                grid.columnconfigure(c, weight=1, uniform="col")
            for i, b in enumerate(shown):
                if searching:
                    self.find_matches.append(b)
                lbl = self.make_button(grid, b, colour, size, cols)
                lbl.grid(row=i // cols, column=i % cols, sticky="ew", pady=(0, 8),
                         padx=(0, 6 if i % cols < cols - 1 else 0))
        if searching and not self.find_matches:
            tk.Label(self.body, text=f"Nothing matches “{tk_safe(self.find_text)}”.", bg=self.bg, fg=INK,
                     justify="center", pady=24).pack(fill="x")
        self.root.update_idletasks()
        self.fit_labels(self.canvas.winfo_width())
        self.sync_scroll()
        self.canvas.yview_moveto(y)
        self.sync_hotkeys()

    def make_button(self, parent, b, colour, size_key, cols):
        """A button with a solid dark outline so its edges are unmistakable. Fills with the family colour on hover or
        keyboard focus. (A Label rather than tk.Button: macOS ignores button colours.) Tab moves between buttons,
        Enter / Space press the focused one."""
        rest, rest_fg, hot_bg, hot_fg, press_bg, press_fg = button_look(colour)
        pad = SIZES[size_key or self.cfg["settings"].get("text_size", "normal")][1]
        sc = normalise_shortcut(b.get("shortcut", ""))
        text = button_caption(b) + (f"    [{sc}]" if sc else "")
        lbl = tk.Label(parent, text=text, bg=rest, fg=rest_fg, font=self.font_for(size_key), anchor="w", justify="left",
                       padx=12, pady=pad, cursor="hand2", bd=0, takefocus=1,
                       highlightthickness=RING, highlightbackground=INK, highlightcolor=FOCUS_RING)
        self.btn_labels.append(lbl)
        self.label_cols[lbl] = cols

        def paint(bg, fg=rest_fg):
            lbl.config(bg=bg, fg=fg)

        def hot():
            paint(hot_bg, hot_fg)

        # A Control-click always opens the menu too, alongside the platform's normal right-click. On a touchpad
        # without a real right button (two-finger-tap emulation etc.), that emulation can occasionally deliver a
        # spurious Button-1 alongside the intended right-click, firing the button instead of showing the menu; a
        # Control-click uses button 1 itself, so it is never subject to that. Its button release must not press
        # the button, hence menu_click.
        menu_click = []

        def release(e):
            inside = 0 <= e.x < lbl.winfo_width() and 0 <= e.y < lbl.winfo_height()
            hot() if inside else paint(rest)
            if menu_click:
                menu_click.clear()
                return
            if inside:
                self.fire(b)

        def focus_in(_):
            hot()
            top, bottom = lbl.winfo_y() + lbl.master.winfo_y(), lbl.winfo_y() + lbl.master.winfo_y() + lbl.winfo_height()
            view = self.canvas.yview()
            total = max(1, self.body.winfo_height())
            if top < view[0] * total:
                self.canvas.yview_moveto(max(0, (top - 8) / total))
            elif bottom > view[1] * total:
                self.canvas.yview_moveto(min(1, (bottom + 8) / total - (view[1] - view[0])))

        lbl.bind("<Enter>", lambda e: hot())
        lbl.bind("<Leave>", lambda e: paint(rest) if self.root.focus_get() is not lbl else hot())
        lbl.bind("<ButtonPress-1>", lambda e: (menu_click.clear(), paint(press_bg, press_fg)))
        lbl.bind("<ButtonRelease-1>", release)
        lbl.bind("<FocusIn>", focus_in)
        lbl.bind("<FocusOut>", lambda e: paint(rest))
        lbl.bind("<Return>", lambda e: self.fire(b))
        lbl.bind("<space>", lambda e: self.fire(b))
        for ev in (("<Button-2>", "<Control-Button-1>") if IS_MAC else ("<Button-3>", "<Control-Button-1>")):
            lbl.bind(ev, lambda e, b=b, ev=ev: (menu_click.append(1) if ev == "<Control-Button-1>" else None,
                                                 self.quick_menu(e, b))[1])
        lbl.hover = HoverTip(lbl, lambda: preview_text(b.get("steps")), self.hover_ok)
        return lbl

    def toggle(self, name):
        self.collapsed.symmetric_difference_update({name})
        self.build(keep_scroll=True)

    def set_clipboard(self, text):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()

    def get_clipboard(self):
        return read_clipboard(self.root)

    def make_cursor_bar(self, parent):
        """Up a line / Down a line / Back to end (see cursor_buttons), in one row. They go through fire() like any
        button, so the other program gets the keyboard back first, but they never take the keyboard focus here."""
        bar = ttk.Frame(parent)
        bar.columnconfigure((0, 1, 2), weight=1, uniform="cursor")
        buttons = cursor_buttons()
        for i, b in enumerate(buttons):
            text = f"{b['mark']} {b['label']}" if b.get("mark") else b["label"]
            btn = ttk.Button(bar, text=text, style="Cursor.TButton", takefocus=0, command=lambda b=b: self.fire(b))
            btn.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 3, 3 if i < len(buttons) - 1 else 0))
            btn.hover = HoverTip(btn, lambda b=b: b["tip"], self.hover_ok)
        return bar

    def fire(self, button, hotkey=False):
        if self.locked or self.busy or not button.get("steps") or (time.time() < self.wake_guard and not hotkey):
            return
        if button.get("confirm") and not messagebox.askokcancel(APP, f"Run “{button.get('label', 'this button')}”?",
                                                               parent=self.root):
            return
        self.busy = True
        self.hide_status()
        steps = copy.deepcopy(button["steps"])
        delay = int(self.cfg["settings"].get("type_delay_ms", 8))
        runner = Runner(self, self.tracker.last, delay)
        label = button.get("label", "?")

        def work():
            aborted = False
            try:
                runner.run(steps)
            except Abort:
                aborted = True
            except Exception:  # noqa: BLE001
                self.on_error(*sys.exc_info()[:3], what=f"The button “{label}”")
                aborted = None
            finally:
                self.busy = False
            # A cursor button isn't an entry: no "Typed ✓" bar, nothing counted in Time saved, no workflow step.
            if aborted is not None and not button.get("cursor_nav"):
                self.post(lambda: self.after_run(label, runner, aborted, button))

        self.launch(work)

    def _restore_when_done(self):
        if self.busy:
            self.root.after(100, self._restore_when_done)
        else:
            self.root.deiconify()
            self._self_iconify = False

    # ---- one-click backup / restore

    def backup_to_folder(self):
        """Ask for a folder (with a working New folder button) and save one complete, dated backup file there."""
        if self.locked:
            return
        if self.editor_open() and self.editor.dirty:
            messagebox.showinfo(APP, "The editor has unsaved changes. Save them first so they're in the backup.",
                                parent=self.editor)
            return
        if backup_to_folder(self.root, self.cfg, self.cfg["settings"]) and self.cfg_ok:
            try:
                save_config(self.cfg)
            except OSError:
                pass

    def restore_backup(self):
        """Restore… / Import setup…: load a setup file or backup, replacing everything or merging it in."""
        if self.locked:
            return
        if self.editor is not None and self.editor.winfo_exists():
            messagebox.showinfo(APP, "Close the editor first (or use Import setup… inside it).", parent=self.editor)
            return
        if not self.cfg_ok:
            messagebox.showwarning(APP, "Your current buttons file couldn't be read, so restoring is switched off "
                                        "to avoid overwriting it. Fix or move that file first.")
            return
        got = import_setup_file(self.root, self.cfg, self.cfg["settings"].get("last_backup_folder", ""))
        if not got:
            return
        new, mode = got
        try:
            save_config(new)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't save the imported setup:\n{e}")
            return
        self.apply_config(new)
        messagebox.showinfo(APP, f"{'Replaced' if mode == 'replace' else 'Merged'}. You now have "
                                 f"{len(new['families'])} families and {count_buttons(new)} buttons.")

    # ---- updates

    def post(self, fn):
        """Run fn on the Tk thread without waiting for it."""
        self.ui_queue.put((fn, {}, threading.Event()))

    def show_foot(self, text=None):
        if text:
            self.foot.config(text=text, fg=MUTED)
        elif self.pending:
            self.foot.config(text=f"Update available: v{self.pending[0]}. Click to install", fg="#c2413b")
        else:
            self.foot.config(text=f"v{VERSION}  ·  Check for updates", fg=MUTED)

    def check_worker(self, silent):
        # Always post a result, or `checking` would stay set and block every later check.
        try:
            ver, data = fetch_latest_app() if getattr(sys, "frozen", False) else fetch_latest()
        except UpdateError as e:
            msg = str(e)
            self.post(lambda: self.update_checked(None, None, msg, silent))
            return
        except Exception as e:  # noqa: BLE001
            msg = f"The update check failed: {e}"
            self.post(lambda: self.update_checked(None, None, msg, silent))
            return
        self.post(lambda: self.update_checked(ver, data, None, silent))

    def auto_check(self):
        if not self.checking:
            self.checking = True
            threading.Thread(target=self.check_worker, args=(True,), daemon=True).start()

    def update_clicked(self):
        if self.checking:
            return
        if self.pending:
            self.offer_install()
            return
        self.checking = True
        self.show_foot("Checking for updates…")
        threading.Thread(target=self.check_worker, args=(False,), daemon=True).start()

    def update_checked(self, ver, data, error, silent):
        self.checking = False
        if error:
            self.show_foot()
            if not silent:
                messagebox.showwarning(APP, error)
            return
        if ver in bad_versions():
            self.show_foot()
            if not silent:
                messagebox.showinfo(APP, f"The newest version (v{ver}) didn't start properly on this computer earlier, so "
                                         "Quickpad is skipping it and staying on v" + VERSION + ".\n\nThe next release "
                                         "will be offered as normal.")
            return
        if version_tuple(ver) > version_tuple(VERSION):
            self.pending = (ver, data)
            self.show_foot()
            if not silent:
                self.offer_install()
        else:
            self.show_foot()
            if not silent:
                messagebox.showinfo(APP, f"You're up to date (v{VERSION}).")

    def offer_install(self):
        ver, data = self.pending
        if not messagebox.askyesno(APP, f"Quickpad v{ver} is available (you have v{VERSION}).\n\n"
                                        "Install it now? Quickpad will restart. Your buttons are kept."):
            return
        # Let the editor offer to save (or discard) unsaved changes first; Cancel there cancels the update.
        if self.editor is not None and self.editor.winfo_exists():
            self.editor.close()
            if self.editor.winfo_exists():
                return
        if getattr(sys, "frozen", False):
            self.offer_install_frozen(data)
            return
        try:
            path = apply_update(data)
        except UpdateError as e:
            messagebox.showerror(APP, str(e))
            return
        self.save_state()
        try:
            rest = [a for a in sys.argv[1:] if a not in ("--restart", "--child")]
            subprocess.Popen([sys.executable, path, "--restart", *rest], close_fds=True)
        except OSError as e:
            messagebox.showerror(APP, f"The update is installed, but Quickpad couldn't restart: {e}\n"
                                      "Please start it again yourself.")
            return
        self.root.destroy()

    def offer_install_frozen(self, data):
        """The frozen-Mac-build equivalent of the tail of offer_install(): stage the downloaded Quickpad.app.zip,
        hand off to its relauncher script, then quit so the script can safely replace the running bundle."""
        if not running_app_path():
            messagebox.showerror(APP, "Couldn't find Quickpad.app to update. Please download the newest version "
                                      "from quickpad.praxentislabs.com.au instead.")
            return
        try:
            script = stage_app_update(data)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't save the update: {e}")
            return
        self.save_state()
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["cmd", "/c", script], close_fds=True,
                                  creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
            else:
                subprocess.Popen(["/bin/bash", script], close_fds=True, start_new_session=True)
        except OSError as e:
            messagebox.showerror(APP, f"The update downloaded, but Quickpad couldn't hand off to install it: {e}\n"
                                      "Please download the newest version from quickpad.praxentislabs.com.au instead.")
            return
        self.root.destroy()

    def open_settings(self):
        if self.locked:
            return
        if self.editor_open():
            messagebox.showinfo(APP, "Close the button editor first, then open Settings.", parent=self.editor)
            return
        if self.dialog_open():
            self.settings_win.lift()
            self.settings_win.focus_force()
            return
        self.settings_win = SettingsDialog(self)

    def open_editor(self, select=None, tab=None):
        if self.locked:
            return
        if self.dialog_open():
            messagebox.showinfo(APP, "Close Settings first, then open the button editor.", parent=self.settings_win)
            return
        if self.editor is not None and self.editor.winfo_exists():
            self.editor.lift()
            self.editor.focus_force()
        else:
            self.editor = Editor(self, select)
        if tab == "workflows":
            self.editor.nb.select(self.editor.workflows_page)

    def apply_config(self, cfg):
        self.cfg = cfg
        self.cfg_ok = True
        self.apply_settings()

    def apply_settings(self):
        """Re-apply everything Settings controls (after Settings, a restore, or an editor save)."""
        self.apply_pin()
        self.build()

    def persist_ui_state(self):
        s = self.cfg["settings"]
        if not self.faded:
            s["geometry"] = self.geometry_string()
        names = set(self.family_names())
        s["collapsed"] = sorted(self.collapsed & names)

    def save_state(self):
        if self.cfg_ok:
            self.persist_ui_state()
            try:
                save_config(self.cfg)
            except OSError:
                pass

    def quit(self):
        self.save_state()
        if self.hotkeys:
            self.hotkeys.stop()
        if self.instance:
            self.instance.close()
        self.sync.stop()
        log.info("Quickpad closed")
        self.root.destroy()

    def run(self):
        self.root.mainloop()


# ================================================================ settings

class ShortcutDialog(tk.Toplevel):
    """'Press the keys you want' capture box for a button's shortcut."""

    def __init__(self, parent, prompt=None):
        super().__init__(parent)
        self.title(f"{APP} — Press a key")
        self.transient(parent)
        self.result = None
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        body = ttk.Frame(self, padding=20)
        body.pack()
        ttk.Label(body, text=prompt or "Press the key or keys you want\n(for example F5, or Ctrl+Alt+1).\n\nPress Esc to cancel.",
                  justify="center", font=("TkDefaultFont", 12)).pack()
        self.bind("<KeyPress>", self.key)
        self.wait_visibility()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.focus_force()

    def key(self, e):
        if e.keysym == "Escape":
            self.destroy()
            return
        sc = event_shortcut(e)
        if sc:
            self.result = sc
            self.destroy()


def ask_shortcut(parent, prompt=None):
    panel = panel_of(parent)
    if panel:
        panel.pause_hotkeys()          # otherwise a key that's already a shortcut would fire instead of being recorded
    try:
        dlg = ShortcutDialog(parent, prompt)
        parent.wait_window(dlg)
        return dlg.result
    finally:
        if panel:
            panel.resume_hotkeys()


TEXT_SIZE_NAMES = {"Small": "small", "Normal": "normal", "Large": "large", "Extra large": "xlarge"}
SCHEDULE_NAMES = {"Every day": "daily", "Every week": "weekly", "Only when I click Back up": "off"}


class ScrollPage(ttk.Frame):
    """A Settings page that scrolls when the screen is too short for it (a laptop with large text), and otherwise
    stretches to fill the tab exactly as a plain frame would. Build the page's widgets inside `.inner`."""

    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=APP_BG, takefocus=0)
        self.bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview, takefocus=0)
        self.canvas.configure(yscrollcommand=self.bar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = ttk.Frame(self.canvas)
        self.item = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.bind("<Configure>", lambda e: self.fit())
        self.inner.bind("<Configure>", lambda e: self.fit())
        # Added beside the panel's own wheel handling (bind_all is shared by the whole app), and taken out again when
        # the page goes, so a closed Settings window leaves nothing behind to call.
        self.wheel_ids = [(seq, self.canvas.bind_all(seq, self.wheel, add="+"))
                          for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>")]
        self.bind("<Destroy>", self.forget_wheel, add="+")

    def forget_wheel(self, e=None):
        if e is not None and e.widget is not self:
            return
        for seq, funcid in self.wheel_ids:
            try:
                script = self.tk.call("bind", "all", seq)
                kept = "\n".join(line for line in str(script).split("\n") if line.strip() and funcid not in line)
                self.tk.call("bind", "all", seq, kept)      # the command itself goes with the canvas
            except tk.TclError:
                pass
        self.wheel_ids = []

    def fit(self):
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        need = self.inner.winfo_reqheight()
        self.canvas.itemconfigure(self.item, width=max(1, cw), height=max(need, ch))
        self.canvas.configure(scrollregion=(0, 0, cw, max(need, ch)))
        if need > ch + 1:
            if not self.bar.winfo_ismapped():
                self.bar.pack(side="right", fill="y", before=self.canvas)
        elif self.bar.winfo_ismapped():
            self.bar.pack_forget()
            self.canvas.yview_moveto(0)

    def wheel(self, e):
        """Scroll this page when the wheel turns over it, unless it all fits (or a list inside is scrolling itself)."""
        if not self.bar.winfo_ismapped() or not self.winfo_ismapped():
            return
        w = self.winfo_containing(e.x_root, e.y_root)
        if w is None or not str(w).startswith(str(self)) or isinstance(w, (tk.Text, tk.Listbox, ttk.Treeview)):
            return
        step = -1 if (getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0) else 1
        self.canvas.yview_scroll(step * 3, "units")


TYPING_TEST_TEXT = ("The patient reports lower back pain that is better than last week. Sitting is easier and "
                    "sleep has improved. Review in two weeks and continue the home exercises.")


class TypingTest(tk.Toplevel):
    """Type a short clinical sentence; the clock starts at the first key. `wpm` is the result, or 0 if cancelled."""

    def __init__(self, parent):
        super().__init__(parent)
        self.wpm, self.started = 0, None
        self.title(f"{APP} — typing speed")
        self.transient(parent)
        self.attributes("-topmost", True)
        f = ttk.Frame(self, padding=14)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Type this as you normally would (don't rush), then press Enter:", wraplength=460).pack(anchor="w")
        tk.Label(f, text=TYPING_TEST_TEXT, wraplength=460, justify="left", font=("TkDefaultFont", 12), fg=INK,
                 bg=APP_BG, padx=8, pady=8).pack(fill="x", pady=8)
        self.box = tk.Text(f, width=58, height=4, wrap="word", font=("TkDefaultFont", 12))
        self.box.pack(fill="x")
        self.box.bind("<KeyPress>", self.key)
        self.box.bind("<Return>", lambda e: (self.finish(), "break")[1])
        self.note = ttk.Label(f, text="The clock starts when you press the first key.", foreground=MUTED)
        self.note.pack(anchor="w", pady=(6, 0))
        row = ttk.Frame(f)
        row.pack(fill="x", pady=(10, 0))
        ttk.Button(row, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(row, text="Done", command=self.finish).pack(side="right", padx=6)
        self.box.focus_set()
        self.grab_set()

    def key(self, e):
        if self.started is None and e.char and e.char.isprintable():
            self.started = time.monotonic()

    def finish(self):
        typed = self.box.get("1.0", "end-1c").strip()
        if self.started is None or len(typed) < 20:
            self.note.config(text="Type a bit more of the sentence first.")
            return
        wpm = typing_speed(TYPING_TEST_TEXT, typed, time.monotonic() - self.started)
        if wpm < 5:
            self.note.config(text="That didn't match the sentence closely enough. Try again.")
            return
        if messagebox.askyesno(APP, f"You type about {wpm} words a minute. Use that?", parent=self):
            self.wpm = min(200, wpm)
        self.destroy()


class SettingsDialog(tk.Toplevel):
    """One place for every setting. Save applies them all; Cancel throws the changes away. The action buttons
    (Back up now, Restore, data folder, password) act straight away."""

    def __init__(self, panel):
        super().__init__(panel.root)
        self.panel = panel
        s = panel.cfg["settings"]
        self.title(f"{APP} — Settings")
        # Nine tabs need about 880 px at normal text size, more with bigger system text; never more than the screen.
        sw, sh_ = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{min(880, sw - 40)}x{min(700, sh_ - 90)}")
        self.minsize(min(640, sw - 40), min(520, sh_ - 90))
        if s.get("always_on_top", True):
            self.attributes("-topmost", True)

        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        # Packed (and so given its space) before the notebook, so Save/Cancel are always visible at the
        # bottom of the window no matter the window size, instead of being squeezed off it by the notebook's
        # own expand=True claiming every pixel first.
        btns = ttk.Frame(outer)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        nb = ttk.Notebook(outer)
        nb.pack(fill="both", expand=True)
        tabs, pages = {}, {}
        for name in ("Window", "Buttons", "Dictation", "Vocabulary", "AI note", "Time saved", "Backup && data",
                     "Sync", "Password", "Help"):
            page = ScrollPage(nb)
            f = page.inner
            f.configure(padding=14)
            f.columnconfigure(1, weight=1)
            nb.add(page, text=name.replace("&&", "&"))
            tabs[name] = f
            pages[name] = page
        self.nb, self.tabs = nb, pages       # pages: what nb.select() takes; tabs: where each page's widgets go
        self.vars = {}

        def var(kind, key, default):
            v = {"b": tk.BooleanVar, "s": tk.StringVar, "i": tk.StringVar}[kind](value=(str(s.get(key, default)) if kind != "b" else bool(s.get(key, default))))
            self.vars[key] = v
            return v

        # ---- Window
        w = tabs["Window"]
        r = 0
        ttk.Checkbutton(w, text="Show the button window when Quickpad starts", variable=var("b", "show_on_start", True)).grid(
            row=r, column=0, columnspan=3, sticky="w", pady=2)
        r += 1
        self.autostart = tk.BooleanVar(value=autostart_enabled())
        cb = ttk.Checkbutton(w, text="Start Quickpad when I log in to this computer", variable=self.autostart)
        cb.grid(row=r, column=0, columnspan=3, sticky="w", pady=2)
        if not autostart_path():
            cb.state(["disabled"])
            ttk.Label(w, text="(not available on this system)", foreground=MUTED).grid(row=r, column=3, sticky="w")
        r += 1
        ttk.Checkbutton(w, text="Keep Quickpad on top of other windows", variable=var("b", "always_on_top", True)).grid(
            row=r, column=0, columnspan=3, sticky="w", pady=2)
        r += 1
        pos = ttk.LabelFrame(w, text="Where it opens", padding=10)
        pos.grid(row=r, column=0, columnspan=4, sticky="ew", pady=(10, 4))
        self.pos_mode = var("s", "position_mode", "last")
        ttk.Radiobutton(pos, text="Where I left it last time", value="last", variable=self.pos_mode).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(pos, text="Always in the spot I save here", value="fixed", variable=self.pos_mode).grid(row=1, column=0, sticky="w")
        self.fixed = s.get("fixed_geometry", "")
        self.fixed_txt = tk.StringVar()
        ttk.Button(pos, text="Save the current position", command=self.save_position).grid(row=1, column=1, padx=8)
        ttk.Label(pos, textvariable=self.fixed_txt, foreground=MUTED).grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(pos, text="Drag the panel where you want it first, then click Save the current position.",
                  foreground=MUTED, wraplength=520).grid(row=3, column=0, columnspan=2, sticky="w")
        self.show_fixed()
        r += 1
        ttk.Label(w, text="Text size").grid(row=r, column=0, sticky="w", pady=(10, 2))
        self.size_cb = ttk.Combobox(w, state="readonly", width=14, values=list(TEXT_SIZE_NAMES))
        self.size_cb.set(next((k for k, v in TEXT_SIZE_NAMES.items() if v == s.get("text_size", "normal")), "Normal"))
        self.size_cb.grid(row=r, column=1, sticky="w", pady=(10, 2))
        r += 1
        ttk.Label(w, text="Colours").grid(row=r, column=0, sticky="w", pady=(6, 2))
        self.theme_cb = ttk.Combobox(w, state="readonly", width=30, values=list(THEME_NAMES))
        self.saved_theme = read_local_theme()     # what was chosen, even if it hasn't been restarted into yet
        self.theme_cb.set(next((k for k, v in THEME_NAMES.items() if v == self.saved_theme), "Light (standard)"))
        self.theme_cb.grid(row=r, column=1, sticky="w", pady=(6, 2))
        if IS_MAC:
            self.theme_cb.state(["disabled"])
            ttk.Label(w, text="(follows your Mac)", foreground=MUTED).grid(row=r, column=2, sticky="w")
        r += 1
        fade = ttk.LabelFrame(w, text="When I haven't used it for a while", padding=10)
        fade.grid(row=r, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        ttk.Checkbutton(fade, text="Get out of the way (fade, and roll up)", variable=var("b", "idle_fade", True)).grid(
            row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(fade, text="After").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Spinbox(fade, from_=5, to=3600, width=6, textvariable=var("i", "idle_seconds", 30)).grid(row=1, column=1, sticky="w", pady=(6, 0), padx=4)
        ttk.Label(fade, text="seconds").grid(row=1, column=2, sticky="w", pady=(6, 0))
        ttk.Label(fade, text="How faint (%)").grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Spinbox(fade, from_=20, to=95, width=6, textvariable=var("i", "idle_opacity", 50)).grid(row=2, column=1, sticky="w", pady=(6, 0), padx=4)
        ttk.Label(fade, text="(100 = solid; lower = more see-through)", foreground=MUTED).grid(row=2, column=2, columnspan=2, sticky="w", pady=(6, 0))
        self.idle_style = tk.StringVar(value=s.get("idle_style", "rollup"))
        for i, (val, txt) in enumerate([("rollup", "Roll up to a slim bar (like TypeItIn)"), ("shrink", "Shrink a little"),
                                        ("fade", "Only fade, keep the size")]):
            ttk.Radiobutton(fade, text=txt, value=val, variable=self.idle_style).grid(row=3 + i, column=0, columnspan=4, sticky="w", pady=(6 if i == 0 else 0, 0))
        ttk.Label(fade, text="It opens again the moment you point at it.", foreground=MUTED).grid(row=6, column=0, columnspan=4, sticky="w", pady=(4, 0))

        # ---- Buttons
        b = tabs["Buttons"]
        ttk.Label(b, text="Start with this group showing").grid(row=0, column=0, sticky="w", pady=4)
        self.start_cb = ttk.Combobox(b, state="readonly", width=28,
                                     values=["The one I used last", ALL_FAMILIES] + panel.family_names())
        cur = s.get("start_family", "")
        self.start_cb.set("The one I used last" if not cur else cur)
        self.start_cb.grid(row=0, column=1, sticky="w", pady=4, padx=8)
        hk = ttk.Checkbutton(b, text="Let shortcut keys work in any program, not just when Quickpad is active",
                             variable=var("b", "global_hotkeys", True))
        hk.grid(row=4, column=0, columnspan=2, sticky="w", pady=(18, 2))
        ttk.Label(b, text="Works for keys that include Ctrl, Alt or Super (like Ctrl+Alt+1) and for F keys. Plain keys "
                          "such as x only ever work when Quickpad is the active window, so typing isn't hijacked. "
                          "Needs Linux with X11 (Linux Mint is fine).", foreground=MUTED, wraplength=520,
                  justify="left").grid(row=5, column=0, columnspan=2, sticky="w")
        if not panel.hotkeys_available():
            hk.state(["disabled"])
            ttk.Label(b, text="Not available on this system.", foreground="#b3261e").grid(row=6, column=0, columnspan=2, sticky="w")
        ttk.Label(b, text="Typing speed (ms per character)").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Spinbox(b, from_=0, to=200, width=6, textvariable=var("i", "type_delay_ms", 8)).grid(row=1, column=1, sticky="w", pady=4, padx=8)
        ttk.Label(b, text="Lower is faster. If some programs miss letters, try a higher number.", foreground=MUTED,
                  wraplength=520).grid(row=2, column=0, columnspan=2, sticky="w")
        ttk.Label(b, text="Button size, buttons per row, each button's name, text, shortcut key and \"ask before "
                          "running\" are set in Edit buttons: pick a group or a button on the left.",
                  foreground=MUTED, wraplength=520, justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(18, 0))
        ttk.Checkbutton(b, text="Show what a button will type when I point at it for a moment",
                        variable=var("b", "hover_preview", True)).grid(row=7, column=0, columnspan=2, sticky="w", pady=(18, 2))
        more = ttk.LabelFrame(b, text="Add buttons", padding=10)
        more.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        ttk.Button(more, text="Add starter clinical notes", command=self.add_starter).grid(row=0, column=0, sticky="w")
        ttk.Button(more, text="Import from a spreadsheet…", command=self.import_file).grid(row=0, column=1, sticky="w", padx=8)
        ttk.Label(more, text=STARTER_NOTES_HELP + " A spreadsheet needs a column for the button name and a "
                             "column for its text (a third column can name the group); save it as CSV.",
                  foreground=MUTED, wraplength=520, justify="left").grid(
            row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Button(more, text="Import from TypeItIn…", command=self.import_typeitin_file).grid(
            row=2, column=0, sticky="w", pady=(12, 0))
        ttk.Label(more, text="Choose TypeItIn's data file, datafile.enc, or one of its backups (datafile.enc.YYMMDD), "
                             "then tick the groups to bring in.",
                  foreground=MUTED, wraplength=520, justify="left").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        how = ttk.LabelFrame(b, text="How text goes into other programs", padding=10)
        how.grid(row=9, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        how.columnconfigure(1, weight=1)
        self.insert_method = tk.StringVar(value=s.get("insert_method", "type")
                                          if s.get("insert_method") in ("type", "paste", "auto") else "type")
        for i, (val, txt) in enumerate([("type", "Type it, letter by letter (the usual way)"),
                                        ("paste", "Paste it in (through the clipboard), everywhere"),
                                        ("auto", "Paste it in only for these programs:")]):
            ttk.Radiobutton(how, text=txt, value=val, variable=self.insert_method).grid(
                row=i, column=0, sticky="w", pady=1)
        self.paste_programs = var("s", "paste_programs", DEFAULT_PASTE_PROGRAMS)
        ttk.Entry(how, textvariable=self.paste_programs, width=24).grid(row=2, column=1, sticky="ew", padx=(6, 0))
        ttk.Label(how, text="If nothing appears when a button types into LibreOffice Writer, choose the last one "
                            "(it already lists LibreOffice). Keys like {Enter} and {Tab} are still pressed as usual, "
                            "and whatever was on the clipboard is put back afterwards. Help › Check my setup › "
                            "Typing test tries it out.",
                  foreground=MUTED, wraplength=520, justify="left").grid(row=3, column=0, columnspan=2, sticky="w",
                                                                        pady=(6, 0))

        self.build_dictation(tabs["Dictation"], s)
        self.build_vocabulary(tabs["Vocabulary"], s)
        self.build_ai(tabs["AI note"], s)
        self.build_time_saved(tabs["Time saved"], s)

        # ---- Backup & data
        d = tabs["Backup && data"]
        ttk.Label(d, text="Data folder").grid(row=0, column=0, sticky="w", pady=(0, 2))
        self.data_txt = tk.StringVar(value=CONFIG_DIR)
        ttk.Label(d, textvariable=self.data_txt, foreground=MUTED, wraplength=430).grid(row=0, column=1, sticky="w", padx=8)
        df = ttk.Frame(d)
        df.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 2))
        ttk.Button(df, text="Change…", command=self.change_data_folder).pack(side="left")
        ttk.Button(df, text="Use the standard folder", command=lambda: self.move_data(DEFAULT_DIR)).pack(side="left", padx=6)
        if PORTABLE:
            for wdg in df.winfo_children():
                wdg.state(["disabled"])
        ttk.Label(d, text="Your buttons and settings live here. Everyone who uses this folder shares them, so a "
                          "OneDrive or Dropbox folder lets two computers stay in step.", foreground=MUTED,
                  wraplength=540, justify="left").grid(row=2, column=0, columnspan=2, sticky="w", pady=(0, 10))
        ttk.Label(d, text="Automatic backup").grid(row=3, column=0, sticky="w", pady=4)
        self.sched_cb = ttk.Combobox(d, state="readonly", width=26, values=list(SCHEDULE_NAMES))
        self.sched_cb.set(next((k for k, v in SCHEDULE_NAMES.items() if v == s.get("backup_schedule", "daily")), "Every day"))
        self.sched_cb.grid(row=3, column=1, sticky="w", padx=8)
        ttk.Checkbutton(d, text="Also make a backup every time I save changes in the editor",
                        variable=var("b", "backup_on_save", True)).grid(row=4, column=0, columnspan=2, sticky="w", pady=2)
        ttk.Label(d, text="Also copy backups to").grid(row=5, column=0, sticky="w", pady=(8, 2))
        self.bdir = var("s", "backup_dir", "")
        ttk.Entry(d, textvariable=self.bdir).grid(row=5, column=1, sticky="ew", padx=8, pady=(8, 2))
        ttk.Button(d, text="Choose folder…", command=self.choose_backup_dir).grid(row=6, column=1, sticky="w", padx=8)
        self.last_txt = tk.StringVar(value=self.last_backup_text())
        ttk.Label(d, textvariable=self.last_txt, foreground=MUTED).grid(row=7, column=0, columnspan=2, sticky="w", pady=(10, 4))
        act = ttk.Frame(d)
        act.grid(row=8, column=0, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Button(act, text="Back up now", command=self.backup_now).pack(side="left")
        ttk.Button(act, text="Export setup…", command=self.backup_to_folder).pack(side="left", padx=6)
        ttk.Button(act, text="Import setup…", command=self.restore).pack(side="left")
        cloud = ttk.LabelFrame(d, text="Copy backups to the cloud", padding=10)
        cloud.grid(row=9, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        found = cloud_folders()
        if found:
            ttk.Label(cloud, text="These folders sync to the internet. Click one, then Save, and every backup is "
                                  "copied there too. (Button text only; never patient details.)",
                      foreground=MUTED, wraplength=520, justify="left").grid(row=0, column=0, sticky="w")
            for i, (name, folder) in enumerate(found):
                ttk.Button(cloud, text=f"Use my {name} folder", command=lambda f=folder, n=name: self.use_cloud(n, f)).grid(
                    row=1 + i, column=0, sticky="w", pady=(4, 0))
        else:
            ttk.Label(cloud, text="No Dropbox, Google Drive or OneDrive folder was found on this computer. Install "
                                  "one of those programs and it will appear here, or use Choose folder… above.",
                      foreground=MUTED, wraplength=520, justify="left").grid(row=0, column=0, sticky="w")

        self.sync_tab = SyncTab(tabs["Sync"], self)

        # ---- Help
        h = tabs["Help"]
        ttk.Label(h, text="If something isn't working, start here.", font=("TkDefaultFont", 11, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(h, text="Check my setup shows what's working and what isn't, on one screen you can photograph. Copy "
                          "support report puts the same details, plus the recent log, on the clipboard so you can paste "
                          "them into a message to Nick.", foreground=MUTED, wraplength=520, justify="left").grid(
            row=1, column=0, columnspan=2, sticky="w", pady=(4, 12))
        hf = ttk.Frame(h)
        hf.grid(row=2, column=0, columnspan=2, sticky="w")
        ttk.Button(hf, text="Check my setup…", command=lambda: DiagnosticsDialog(self, panel)).grid(row=0, column=0, padx=(0, 6), pady=3, sticky="ew")
        ttk.Button(hf, text="Copy support report", command=self.copy_report).grid(row=0, column=1, padx=(0, 6), pady=3, sticky="ew")
        ttk.Button(hf, text="Open my data folder", command=lambda: open_path(CONFIG_DIR)).grid(row=1, column=0, padx=(0, 6), pady=3, sticky="ew")
        ttk.Button(hf, text="Open the log file", command=lambda: open_path(LOG_PATH)).grid(row=1, column=1, padx=(0, 6), pady=3, sticky="ew")
        ttk.Button(hf, text="What's new…", command=panel.show_whats_new).grid(row=2, column=0, padx=(0, 6), pady=3, sticky="ew")
        ttk.Label(h, text=f"Quickpad version {VERSION}", foreground=MUTED).grid(row=3, column=0, columnspan=2, sticky="w", pady=(16, 0))
        ttk.Label(h, text=f"Buttons and settings: {CONFIG_DIR}", foreground=MUTED, wraplength=520, justify="left").grid(row=4, column=0, columnspan=2, sticky="w")

        # ---- Password
        p = tabs["Password"]
        self.pw_txt = tk.StringVar()
        ttk.Label(p, textvariable=self.pw_txt, font=("TkDefaultFont", 11, "bold")).grid(row=0, column=0, columnspan=2, sticky="w")
        pf = ttk.Frame(p)
        pf.grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 10))
        self.set_btn = ttk.Button(pf, text="Set password…", command=self.set_password)
        self.set_btn.pack(side="left")
        self.rm_btn = ttk.Button(pf, text="Remove password", command=self.remove_password)
        self.rm_btn.pack(side="left", padx=6)
        self.lock_start = var("b", "lock_on_start", False)
        self.lock_restore = var("b", "lock_on_restore", False)
        self.cb_start = ttk.Checkbutton(p, text="Ask for the password when Quickpad starts", variable=self.lock_start)
        self.cb_start.grid(row=2, column=0, columnspan=2, sticky="w", pady=2)
        self.cb_restore = ttk.Checkbutton(p, text="Ask for it when the window comes back after being minimised",
                                          variable=self.lock_restore)
        self.cb_restore.grid(row=3, column=0, columnspan=2, sticky="w", pady=2)
        ttk.Label(p, text="This keeps casual visitors out. It isn't encryption: someone who can open your computer's "
                          "files can remove it. If you forget it, close Quickpad and delete the password lines from "
                          "buttons.json in the data folder (see the README).", foreground=MUTED, wraplength=540,
                  justify="left").grid(row=4, column=0, columnspan=2, sticky="w", pady=(16, 0))
        self.refresh_password()

        ttk.Button(btns, text="Save", command=self.save).pack(side="right")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=8)
        self.bind("<Escape>", lambda e: self.destroy())
        self.update_idletasks()
        want = nb.winfo_reqwidth() + 30                  # wide enough for every tab name at this computer's text size
        if want > self.winfo_width():
            self.geometry(f"{min(want, sw - 40)}x{self.winfo_height()}")

    # ---- Dictation tab
    MIC_DEFAULT = "The computer's standard microphone"

    def build_dictation(self, t, s):
        self.dict_q = queue.Queue()                 # results from background work (setup, download, microphone list)
        self.dict_busy = False
        self.dict_stop = threading.Event()          # closing Settings stops a download part way
        self.dict_model = s.get("dictation_model", "") if model_info(s.get("dictation_model", "")) else ""
        self.info = machine_info()
        self.suggested, why = suggest_model(self.info)

        eng = ttk.LabelFrame(t, text="Dictation on this computer", padding=(10, 6))
        eng.grid(row=0, column=0, columnspan=2, sticky="ew")
        eng.columnconfigure(0, weight=1)
        self.eng_txt = tk.StringVar()
        ttk.Label(eng, textvariable=self.eng_txt, wraplength=400, justify="left").grid(row=0, column=0, sticky="w")
        self.eng_btn = ttk.Button(eng, text="Set up dictation…", command=self.setup_dictation)
        self.eng_btn.grid(row=0, column=1, sticky="ne", padx=(8, 0))
        ttk.Label(eng, text="Worked out on this computer: what you say is never sent anywhere or kept.",
                  foreground=MUTED, wraplength=540).grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))

        mf = ttk.LabelFrame(t, text="Speech model", padding=(10, 6))
        mf.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        mf.columnconfigure(0, weight=1)
        ttk.Label(mf, text=f"{describe_machine(self.info)} Suggested (★): {model_info(self.suggested)['name']}, because {why}.",
                  wraplength=540, justify="left").grid(row=0, column=0, columnspan=3, sticky="w")
        self.tree = ttk.Treeview(mf, columns=("size", "wait", "accuracy", "here"), height=len(WHISPER_MODELS),
                                 selectmode="browse")
        for col, text, width in (("#0", "Model", 112), ("size", "Size", 60), ("wait", "Wait per 30 s", 120),
                                 ("accuracy", "Accuracy", 88), ("here", "Status", 150)):
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, width=width, anchor="w", stretch=col == "here")
        for m in WHISPER_MODELS:
            self.tree.insert("", "end", iid=m["key"], text=m["name"])
        self.tree.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(6, 4))
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_model_note())
        self.model_note = tk.StringVar()
        ttk.Label(mf, textvariable=self.model_note, foreground=MUTED, wraplength=540, justify="left").grid(
            row=2, column=0, columnspan=3, sticky="w")
        self.use_btn = ttk.Button(mf, text="Use this one", command=self.use_model)
        self.use_btn.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.del_btn = ttk.Button(mf, text="Delete its download", command=self.delete_model)
        self.del_btn.grid(row=3, column=1, sticky="w", pady=(6, 0), padx=6)
        self.dl_bar = ttk.Progressbar(mf, maximum=100, length=160)
        self.dl_txt = self.model_note          # while setting up or downloading, progress shows where the note was

        lf = ttk.LabelFrame(t, text="Listening", padding=(10, 6))
        lf.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        lf.columnconfigure(1, weight=1)
        ttk.Label(lf, text="Microphone").grid(row=0, column=0, sticky="w")
        self.mic_cb = ttk.Combobox(lf, state="readonly", width=34)
        saved_mic = s.get("dictation_device", "")
        self.mic_cb["values"] = [self.MIC_DEFAULT] + ([saved_mic] if saved_mic else [])
        self.mic_cb.set(saved_mic or self.MIC_DEFAULT)
        self.mic_cb.grid(row=0, column=1, sticky="ew", padx=6)
        self.mic_btn = ttk.Button(lf, text="Test the microphone…", command=self.test_microphone)
        self.mic_btn.grid(row=0, column=2, sticky="e")
        ttk.Checkbutton(lf, text="Show me what it heard, so I can check and correct the words before they're typed",
                        variable=self.dict_var("b", "dictation_review", True, s)).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Checkbutton(lf, text="When typing straight away, show what it heard afterwards (with Fix a word)",
                        variable=self.dict_var("b", "dictation_show_heard", True, s)).grid(row=4, column=0, columnspan=3, sticky="w", pady=(2, 0))
        mx = ttk.Frame(lf)
        mx.grid(row=2, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Label(mx, text="Stop listening by itself after").pack(side="left")
        ttk.Spinbox(mx, from_=10, to=600, width=5, textvariable=self.dict_var("i", "dictation_max_seconds", 180, s)).pack(
            side="left", padx=4)
        ttk.Label(mx, text="seconds").pack(side="left")
        ttk.Label(lf, text="Words it should expect, and corrections, are on the Vocabulary tab.", foreground=MUTED).grid(
            row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.refresh_dictation()
        self.tree.selection_set(self.dict_model or self.suggested)
        self.tree.see(self.dict_model or self.suggested)
        if engine_status()[0]:
            self.load_microphones()
        self.after(100, self.poll_dictation)

    def dict_var(self, kind, key, default, s):
        v = tk.BooleanVar(value=bool(s.get(key, default))) if kind == "b" else tk.StringVar(value=str(s.get(key, default)))
        self.vars[key] = v
        return v

    def effective_model(self):
        return self.dict_model or self.suggested

    def refresh_dictation(self):
        ok, detail = engine_status()
        use = self.effective_model()
        if ok and model_downloaded(use):
            self.eng_txt.set(f"✓ Ready. The {model_info(use)['name']} model is in use.")
            self.eng_btn.config(text="Set up again…")
        elif ok:
            self.eng_txt.set(f"The engine is installed, but the {model_info(use)['name']} model isn't downloaded yet. "
                             "Click Use this one below (or Set up again).")
            self.eng_btn.config(text="Set up again…")
        else:
            self.eng_txt.set(detail + " Setting it up takes a few minutes and needs the internet.")
            self.eng_btn.config(text="Set up dictation…")
        for m in WHISPER_MODELS:
            k = m["key"]
            status = ("in use" if model_downloaded(k) else "not downloaded") if k == use else \
                "downloaded" if model_downloaded(k) else "suggested" if k == self.suggested else ""
            self.tree.item(k, values=(f"{m['bytes'] / 1_000_000:.0f} MB", describe_wait(estimate_wait(m, self.info)),
                                      m["accuracy"], ("★ " if k == self.suggested else "") + status))
        for w in (self.eng_btn, self.use_btn, self.del_btn, self.mic_btn):
            w.state(["disabled"] if self.dict_busy else ["!disabled"])
        if not self.dict_busy and not ok:
            self.mic_btn.state(["disabled"])
        self.show_model_note()

    def selected_model(self):
        sel = self.tree.selection()
        return sel[0] if sel else self.effective_model()

    def show_model_note(self):
        if self.dict_busy:
            return                             # the note line is showing progress
        key = self.selected_model()
        m = model_info(key)
        note = m["note"]
        if key != self.effective_model():
            note += (" Click Use this one to switch to it." if model_downloaded(key) else
                     f" Click Use this one to download it ({m['bytes'] / 1_000_000:.0f} MB) and switch to it.")
        self.model_note.set(note)
        if not self.dict_busy:
            self.del_btn.state(["!disabled"] if model_downloaded(key) and key != self.effective_model() else ["disabled"])

    def use_model(self):
        key = self.selected_model()
        if model_downloaded(key):
            self.dict_model = "" if key == self.suggested else key
            self.refresh_dictation()
            return
        self.start_dictation_job(lambda say, progress: download_model(key, progress, self.dict_stop.is_set),
                                 lambda: setattr(self, "dict_model", "" if key == self.suggested else key),
                                 f"Downloading the {model_info(key)['name']} model…")

    def delete_model(self):
        key = self.selected_model()
        if key == self.effective_model() or not model_downloaded(key):
            return
        if messagebox.askyesno(APP, f"Delete the downloaded {model_info(key)['name']} model? It can be downloaded "
                                    "again at any time.", parent=self):
            _quiet_remove(model_path(key))
            self.refresh_dictation()

    def setup_dictation(self):
        key = self.effective_model()
        self.start_dictation_job(lambda say, progress: setup_dictation(key, say, progress, self.dict_stop.is_set),
                                 self.load_microphones, "Setting up dictation…")

    def start_dictation_job(self, job, then, first_line):
        """Run setup or a download on a background thread; its messages come back through dict_q."""
        if self.dict_busy:
            return
        self.dict_busy = True
        self.dl_txt.set(first_line)
        self.dl_bar.grid(row=3, column=2, sticky="e", pady=(6, 0))
        self.dl_bar.config(mode="indeterminate", value=0)
        self.dl_bar.start(15)
        self.refresh_dictation()
        q = self.dict_q

        def progress(done, total):
            q.put(("progress", done, total))

        def work():
            try:
                job(lambda line: q.put(("say", line)), progress)
                q.put(("done", then, None))
            except Cancelled:
                q.put(("done", None, None))
            except DictationError as e:
                q.put(("done", None, str(e)))
            except Exception as e:  # noqa: BLE001
                log.exception("dictation setup failed")
                q.put(("done", None, f"Something went wrong: {e}\n\nDetails are in {DICTATION_LOG}"))
        threading.Thread(target=work, daemon=True).start()

    def poll_dictation(self):
        if not self.winfo_exists():
            return
        try:
            while True:
                msg = self.dict_q.get_nowait()
                if msg[0] == "say":
                    self.dl_txt.set(msg[1])
                elif msg[0] == "progress":
                    done, total = msg[1], msg[2]
                    if str(self.dl_bar.cget("mode")) != "determinate":
                        self.dl_bar.stop()
                        self.dl_bar.config(mode="determinate")
                    self.dl_bar.config(value=100 * done / max(1, total))
                    self.dl_txt.set(f"Downloading… {done / 1_000_000:.0f} of {total / 1_000_000:.0f} MB")
                elif msg[0] == "devices":
                    names = msg[1]
                    current = self.mic_cb.get()
                    self.mic_cb["values"] = [self.MIC_DEFAULT] + names
                    if current not in names:
                        self.mic_cb.set(self.MIC_DEFAULT if current == self.MIC_DEFAULT or not current else current)
                elif msg[0] == "ai":
                    self.ai_done(msg[1], msg[2])
                elif msg[0].startswith("local_"):
                    self.local_setup_message(msg)
                elif msg[0] == "done":
                    then, problem = msg[1], msg[2]
                    self.dict_busy = False
                    self.dl_bar.stop()
                    self.dl_bar.grid_remove()
                    if then:
                        then()
                    self.refresh_dictation()
                    if problem:
                        messagebox.showerror(APP, problem, parent=self)
        except queue.Empty:
            pass
        self.after(100, self.poll_dictation)

    def load_microphones(self):
        """Fill the microphone list from the dictation engine (it runs in its own process, so this is quick but
        not instant)."""
        if not engine_status()[0]:
            return
        q = self.dict_q

        def got(ev):
            if ev.get("event") == "devices":
                q.put(("devices", [n for n in ev.get("devices", []) if isinstance(n, str)]))
        try:
            DictationWorker(self.panel, "devices", got, {})
        except OSError:
            pass

    def current_dictation_settings(self):
        """The dictation settings as they are on screen now (for the microphone test), not as last saved."""
        s = dict(self.panel.cfg["settings"])
        s.update(dictation_model=self.dict_model, dictation_device=self.mic_device(),
                 dictation_words=self.vars["dictation_words"].get(), dictation_review=False,
                 dictation_max_seconds=30)
        return s

    def mic_device(self):
        mic = self.mic_cb.get()
        return "" if mic == self.MIC_DEFAULT else mic

    def test_microphone(self):
        s = self.current_dictation_settings()
        ready, why = dictation_state(s)
        if not ready:
            messagebox.showinfo(APP, why, parent=self)
            return

        def done(text):
            if text:
                messagebox.showinfo(APP, f"Quickpad heard:\n\n{text}\n\nIf that's right, dictation is working.", parent=self)
        DictateBox(self.panel, "Say a sentence, for example: the patient reports lower back pain. Then click Stop.",
                   s, on_done=done, stop_text="Stop  ▶")

    def destroy(self):
        if hasattr(self, "dict_stop"):
            self.dict_stop.set()
        super().destroy()

    # ---- Vocabulary tab: words to expect, "when it hears X type Y", and this session's recent dictations
    def build_vocabulary(self, t, s):
        t.columnconfigure(0, weight=1)
        t.rowconfigure(1, weight=1)       # spare height goes to the corrections list (kept compact for small screens)
        wf = ttk.LabelFrame(t, text="Words it should expect", padding=(10, 6))
        wf.grid(row=0, column=0, sticky="ew")
        wf.columnconfigure(1, weight=1)
        # The whole list is shown (it used to be one long line that scrolled sideways, which looked full), and kept
        # in step with the "dictation_words" setting. height=3 used to clip the default list's last line at the
        # bottom edge with no way to tell more was there; a scrollbar (as build_ai's Text box already has) makes
        # overflow reachable instead of silently cut off as the word list grows.
        words = self.dict_var("s", "dictation_words", DEFAULT_DICTATION_WORDS, s)
        self.words_box = tk.Text(wf, height=4, wrap="word", font=("TkDefaultFont", 10), undo=True, pady=3)
        wf.columnconfigure(3, weight=0)
        self.words_box.insert("1.0", words.get())
        self.words_box.edit_modified(False)
        self.words_box.grid(row=0, column=0, columnspan=4, sticky="ew")
        words_sb = ttk.Scrollbar(wf, orient="vertical", command=self.words_box.yview)
        words_sb.grid(row=0, column=4, sticky="ns")
        self.words_box.config(yscrollcommand=words_sb.set)
        self.words_box.bind("<<Modified>>", self.words_edited)
        words.trace_add("write", lambda *a: self.show_words())
        ttk.Label(wf, text="Add words").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.new_words = tk.StringVar()
        add = ttk.Entry(wf, textvariable=self.new_words)
        add.grid(row=1, column=1, sticky="ew", padx=6, pady=(6, 0))
        add.bind("<Return>", lambda e: self.add_words())
        ttk.Button(wf, text="Add", command=self.add_words).grid(row=1, column=2, sticky="w", pady=(6, 0))
        ttk.Button(wf, text="Put back the standard list…", command=self.reset_words).grid(
            row=1, column=3, sticky="e", padx=(12, 0), pady=(6, 0))
        ttk.Label(wf, text="Separate new words with commas (e.g. arthrostim, vibrostim). They go on the end; nothing is "
                           "removed. Words your corrections type are added automatically.",
                  foreground=MUTED, wraplength=760, justify="left").grid(row=2, column=0, columnspan=4, sticky="w", pady=(4, 0))

        ff = ttk.LabelFrame(t, text="Corrections: when it hears one thing, type another", padding=(10, 6))
        ff.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        ff.columnconfigure(0, weight=1)
        ff.rowconfigure(0, weight=1)
        self.fixes = clean_fixes(s.get("dictation_fixes"))
        self.fixes_at_open = {f["heard"].lower() for f in self.fixes}
        self.fix_tree = ttk.Treeview(ff, columns=("write",), height=3, selectmode="browse")
        self.fix_tree.heading("#0", text="When it hears", anchor="w")
        self.fix_tree.heading("write", text="Type instead", anchor="w")
        self.fix_tree.column("#0", width=240, anchor="w")
        self.fix_tree.column("write", width=300, anchor="w")
        self.fix_tree.grid(row=0, column=0, sticky="nsew")
        self.fix_tree.bind("<Double-1>", lambda e: self.edit_fix())
        row = ttk.Frame(ff)                 # buttons under the list, so a short screen can't hide them
        row.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Button(row, text="Add…", command=self.add_fix).pack(side="left")
        ttk.Button(row, text="Change…", command=self.edit_fix).pack(side="left", padx=6)
        ttk.Button(row, text="Remove", command=self.remove_fix).pack(side="left")
        ttk.Label(row, text="e.g. when it hears “arm”, type “leg”. Whole words only.", foreground=MUTED).pack(
            side="left", padx=(12, 0))
        self.fill_fixes()

        hf = ttk.LabelFrame(t, text="What it heard recently (this session only; never saved): pick one, select the "
                                    "wrong word, then Fix", padding=(10, 6))
        hf.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        hf.columnconfigure(0, weight=1)
        self.heard_list = tk.Listbox(hf, height=2, activestyle="none", exportselection=False)
        self.heard_list.grid(row=0, column=0, sticky="ew")
        self.heard_view = tk.Text(hf, height=2, wrap="word", font=("TkDefaultFont", 10))
        self.heard_view.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.heard_view.tag_configure("fixed", background="#fff1b8")
        ttk.Button(hf, text="Fix the selected word…", command=self.fix_from_heard).grid(row=1, column=1, sticky="n", padx=(8, 0))
        self.heard_items = list(getattr(self.panel, "heard_recent", []))
        for h in self.heard_items:
            self.heard_list.insert("end", f"{h['at']}   {h['heard'][:90]}")
        if not self.heard_items:
            self.heard_list.insert("end", "Nothing dictated yet since Quickpad started.")
        self.heard_list.bind("<<ListboxSelect>>", lambda e: self.show_heard_item())

    def words_edited(self, _e=None):
        if not self.words_box.edit_modified():
            return
        self.words_box.edit_modified(False)
        text = " ".join(self.words_box.get("1.0", "end-1c").split())
        if text != self.vars["dictation_words"].get():
            self._syncing = True
            self.vars["dictation_words"].set(text)
            self._syncing = False

    def show_words(self):
        if getattr(self, "_syncing", False):
            return
        self.words_box.delete("1.0", "end")
        self.words_box.insert("1.0", self.vars["dictation_words"].get())
        self.words_box.edit_modified(False)

    def add_words(self):
        """Put new words on the end of the list, skipping any already there. Nothing is removed."""
        current = self.vars["dictation_words"].get().strip()
        have = {w.strip().lower() for w in re.split(r"[,.:;]", current)}
        new = [w for w in (" ".join(x.split()) for x in self.new_words.get().split(",")) if w and w.lower() not in have]
        if new:
            self.vars["dictation_words"].set((current.rstrip(".").rstrip() + ", " if current else "Terms: ")
                                             + ", ".join(new) + ".")
        self.new_words.set("")

    def reset_words(self):
        if self.vars["dictation_words"].get().strip() == DEFAULT_DICTATION_WORDS or messagebox.askyesno(
                APP, "Put back Quickpad's standard list of words? Any words you've added to the list will be "
                     "removed. (Nothing changes until you click Save.)", parent=self):
            self.vars["dictation_words"].set(DEFAULT_DICTATION_WORDS)

    def fill_fixes(self):
        self.fix_tree.delete(*self.fix_tree.get_children())
        for i, f in enumerate(self.fixes):
            self.fix_tree.insert("", "end", iid=str(i), text=f["heard"], values=(f["write"] or "(nothing)",))

    def selected_fix(self):
        sel = self.fix_tree.selection()
        return int(sel[0]) if sel else None

    def add_fix(self, heard=""):
        dlg = TeachDialog(self, heard)
        self.wait_window(dlg)
        if dlg.result:
            self.fixes = [f for f in self.fixes if f["heard"].lower() != dlg.result["heard"].lower()] + [dlg.result]
            self.fill_fixes()

    def edit_fix(self):
        i = self.selected_fix()
        if i is None:
            return
        dlg = TeachDialog(self, self.fixes[i]["heard"], self.fixes[i]["write"])
        self.wait_window(dlg)
        if dlg.result:
            # Drop the entry being edited *and* any other entry that already has the new "heard" word —
            # same "replacing one for the same heard word" rule add_fix() follows — before appending the
            # edit. Without this, clean_fixes()'s keep-the-first-occurrence dedup could silently discard
            # either the edit itself or an unrelated entry, depending on list order.
            self.fixes = [f for j, f in enumerate(self.fixes)
                          if j != i and f["heard"].lower() != dlg.result["heard"].lower()]
            self.fixes.append(dlg.result)
            self.fixes = clean_fixes(self.fixes)
            self.fill_fixes()

    def remove_fix(self):
        i = self.selected_fix()
        if i is not None:
            del self.fixes[i]
            self.fill_fixes()

    def show_heard_item(self):
        sel = self.heard_list.curselection()
        if not sel or sel[0] >= len(self.heard_items):
            return
        h = self.heard_items[sel[0]]
        self.heard_view.delete("1.0", "end")
        self.heard_view.insert("1.0", h["heard"])
        for found, _ in h.get("changes", []):
            mark_words(self.heard_view, found, "fixed")

    def fix_from_heard(self):
        try:
            word = self.heard_view.get("sel.first", "sel.last").strip()
        except tk.TclError:
            word = ""
        self.add_fix(word)

    # ---- AI note tab
    def build_ai(self, t, s):
        t.columnconfigure(0, weight=1)
        t.rowconfigure(2, weight=1)
        ttk.Label(t, text="AI turns a Plaud summary or transcript (or what you dictate) into a note in the layout "
                          "below. You always check it before it goes into the record. Unless you choose your own "
                          "provider, the note is written on this computer and nothing leaves it.",
                  wraplength=680, justify="left").grid(row=0, column=0, sticky="w")
        provider = read_ai_provider()
        where = ttk.LabelFrame(t, text="Where the note is written", padding=(8, 6))
        where.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        where.columnconfigure(0, weight=1)
        self.ai_engine = tk.StringVar(value=provider["engine"])
        self.ai_engine_frames = {}
        choices = (("local", "On this computer: private, nothing leaves it (recommended)"),
                   ("anthropic", "My own Anthropic (Claude) key: sends the text over the internet, overseas"),
                   ("openai", "My own AI service (OpenAI-compatible): sends the text to that server"))
        for row, (value, label) in enumerate(choices):
            ttk.Radiobutton(where, text=label, value=value, variable=self.ai_engine,
                            command=self.engine_chosen).grid(row=2 * row, column=0, sticky="w")
            f = ttk.Frame(where, padding=(24, 2, 0, 6))
            f.grid(row=2 * row + 1, column=0, sticky="ew")
            f.columnconfigure(1, weight=1)
            self.ai_engine_frames[value] = f

        # On this computer: the model, whether it's set up, and Set up
        f = self.ai_engine_frames["local"]
        ttk.Label(f, text="Model").grid(row=0, column=0, sticky="w")
        key = provider["local_model"] if local_model_info(provider["local_model"]) else \
            suggest_local_model(machine_info())
        self.local_model_cb = ttk.Combobox(f, state="readonly", width=40, values=[m["name"] for m in LOCAL_MODELS])
        self.local_model_cb.set(local_model_info(key)["name"])
        self.local_model_cb.grid(row=0, column=1, sticky="w", padx=6)
        self.local_model_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_local_status())
        self.local_status = tk.StringVar()
        ttk.Label(f, textvariable=self.local_status, foreground=MUTED, wraplength=520,
                  justify="left").grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.local_setup_btn = ttk.Button(f, text="Set up…", command=self.start_local_setup)
        self.local_setup_btn.grid(row=0, column=2, sticky="e")
        self.local_bar = ttk.Progressbar(f, mode="indeterminate", length=300)
        self.local_bar.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        self.local_bar.grid_remove()
        self.local_busy = self.local_cancel = False

        # My own Claude key: the 3.3 controls
        f = self.ai_engine_frames["anthropic"]
        ttk.Label(f, text="Claude key").grid(row=0, column=0, sticky="w")
        self.ai_key = tk.StringVar()
        ttk.Entry(f, textvariable=self.ai_key, show="•").grid(row=0, column=1, sticky="ew", padx=6)
        link = ttk.Label(f, text="Get a key", foreground="#3b6fd4", cursor="hand2")
        link.grid(row=0, column=2, sticky="w")
        link.bind("<Button-1>", lambda e: webbrowser.open("https://console.anthropic.com/settings/keys"))
        self.ai_key_note = tk.StringVar()
        ttk.Label(f, textvariable=self.ai_key_note, foreground=MUTED).grid(row=1, column=1, columnspan=2, sticky="w",
                                                                          padx=6)
        self.refresh_ai_key()
        ttk.Label(f, text="Model").grid(row=2, column=0, sticky="w", pady=(4, 0))
        self.ai_model_cb = ttk.Combobox(f, state="readonly", values=[m[1] for m in CLAUDE_MODELS], width=44)
        current = s.get("ai_model") or DEFAULT_CLAUDE_MODEL
        self.ai_model_cb.set(next((m[1] for m in CLAUDE_MODELS if m[0] == current), CLAUDE_MODELS[0][1]))
        self.ai_model_cb.grid(row=2, column=1, sticky="w", padx=6, pady=(4, 0))
        self.ai_model_note = tk.StringVar()
        self.ai_model_cb.bind("<<ComboboxSelected>>", lambda e: self.show_ai_model_note())
        ttk.Label(f, textvariable=self.ai_model_note, foreground=MUTED).grid(row=3, column=1, columnspan=2,
                                                                            sticky="w", padx=6)
        self.show_ai_model_note()

        # My own OpenAI-compatible service
        f = self.ai_engine_frames["openai"]
        self.openai_url = tk.StringVar(value=provider["openai_url"])
        self.openai_model = tk.StringVar(value=provider["openai_model"])
        self.openai_key = tk.StringVar()
        for row, (label, var, show) in enumerate((("Server address", self.openai_url, ""),
                                                  ("Model name", self.openai_model, ""),
                                                  ("Key (if it needs one)", self.openai_key, "•"))):
            ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", pady=(0, 2))
            ttk.Entry(f, textvariable=var, show=show).grid(row=row, column=1, sticky="ew", padx=6, pady=(0, 2))
        saved = read_openai_key()
        ttk.Label(f, foreground=MUTED, wraplength=520, justify="left",
                  text=(f"A key is saved on this computer (ends …{saved[-4:]}). " if saved else "") +
                  "For example https://api.openai.com/v1, or a server in the clinic such as "
                  "http://192.168.1.20:11434/v1. Keys are kept on this computer only.").grid(
            row=3, column=1, sticky="w", padx=6)
        self.engine_chosen()

        inf = ttk.LabelFrame(t, text="Note layout and instructions", padding=(8, 6))
        inf.grid(row=2, column=0, sticky="nsew", pady=(10, 0))
        inf.columnconfigure(0, weight=1)
        inf.rowconfigure(1, weight=1)
        # Generic SOAP and FOAMING SOAP are built in and shown read-only; Custom is the person's own text, kept even
        # while one of the others is chosen, so switching back to it brings it back.
        lay = ttk.Frame(inf)
        lay.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 6))
        ttk.Label(lay, text="Layout").pack(side="left")
        layout = s.get("ai_layout")
        if layout not in AI_LAYOUTS:         # same rules as ai_instructions()
            layout = ("custom" if (s.get("ai_instructions") or "").strip() else "foaming") if layout is None else "soap"
        self.ai_custom = (s.get("ai_instructions") or "").strip()
        self.ai_layout = layout
        self.ai_layout_cb = ttk.Combobox(lay, state="readonly", width=30, values=[v[0] for v in AI_LAYOUTS.values()])
        self.ai_layout_cb.set(AI_LAYOUTS[layout][0])
        self.ai_layout_cb.pack(side="left", padx=6)
        self.ai_layout_cb.bind("<<ComboboxSelected>>", lambda e: self.layout_chosen())
        self.ai_layout_note = ttk.Label(lay, foreground=MUTED)
        self.ai_layout_note.pack(side="left")
        self.ai_text = tk.Text(inf, height=8, wrap="word", font=("TkDefaultFont", 10), undo=True)
        self.ai_text.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(inf, orient="vertical", command=self.ai_text.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.ai_text.config(yscrollcommand=sb.set)
        self.show_ai_layout()
        row = ttk.Frame(inf)
        row.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        ttk.Button(row, text="Make my own from this one", command=self.reset_ai_text).pack(side="left")
        self.ai_try_btn = ttk.Button(row, text="Try it on a made-up consult…", command=self.try_ai)
        self.ai_try_btn.pack(side="left", padx=6)
        self.ai_consent_btn = ttk.Button(row, text="Ask again before sending notes away", command=self.revoke_ai)
        self.ai_consent_btn.pack(side="right")
        if not ai_consent_hosts():
            self.ai_consent_btn.state(["disabled"])
        ttk.Label(t, text="Safety rules are always added: use only what's in the consult, never invent findings, and "
                          "mark red flags (FLAG:) and anything unclear (CHECK:).", foreground=MUTED, wraplength=680,
                  justify="left").grid(row=3, column=0, sticky="w", pady=(6, 0))

    def engine_chosen(self):
        for value, f in self.ai_engine_frames.items():
            if value == self.ai_engine.get():
                f.grid()
            else:
                f.grid_remove()
        if self.ai_engine.get() == "local":
            self.refresh_local_status()

    def chosen_local_model(self):
        name = self.local_model_cb.get()
        return next((m["key"] for m in LOCAL_MODELS if m["name"] == name), LOCAL_MODELS[0]["key"])

    def dialog_ai_provider(self):
        """The provider as chosen in this window (not saved yet)."""
        return {"engine": self.ai_engine.get(), "local_model": self.chosen_local_model(),
                "openai_url": self.openai_url.get().strip(), "openai_model": self.openai_model.get().strip()}

    def refresh_local_status(self):
        if self.local_busy:
            return
        m = local_model_info(self.chosen_local_model())
        ready, why = local_ai_state(self.dialog_ai_provider())
        if ready:
            self.local_status.set(f"Ready. {m['note']}")
            self.local_setup_btn.config(text="Set up…")
            self.local_setup_btn.state(["disabled"])
        else:
            self.local_status.set("Not set up yet. " + (why if "antivirus" in why or "can't run" in why or
                                                        "newer Linux" in why else
                                  f"Set up downloads it once (about {_gb(m['bytes'])} GB). {m['note']}"))
            self.local_setup_btn.config(text="Set up…")
            self.local_setup_btn.state(["!disabled"])

    def start_local_setup(self):
        """Download the engine and model on a background thread; messages come back through dict_q."""
        if self.local_busy:
            self.local_cancel = True                 # the button reads Cancel while it runs
            return
        key, q = self.chosen_local_model(), self.dict_q
        self.local_busy, self.local_cancel = True, False
        self.local_setup_btn.config(text="Cancel")
        self.local_bar.config(mode="indeterminate", value=0)
        self.local_bar.grid()
        self.local_bar.start(15)

        def work():
            problem = ""
            try:
                setup_local_ai(key, say=lambda m: q.put(("local_say", m)),
                               progress=lambda d, n: q.put(("local_progress", d, n)),
                               cancelled=lambda: self.local_cancel)
            except Cancelled:
                problem = ""
            except AIError as e:
                problem = str(e)
            except Exception as e:  # noqa: BLE001
                log.exception("local AI setup failed")
                problem = f"Something went wrong: {e}"
            q.put(("local_done", problem))
        threading.Thread(target=work, daemon=True).start()

    def local_setup_message(self, msg):
        if msg[0] == "local_say":
            self.local_status.set(msg[1])
        elif msg[0] == "local_progress":
            done, total = msg[1], msg[2]
            if str(self.local_bar.cget("mode")) != "determinate":
                self.local_bar.stop()
                self.local_bar.config(mode="determinate")
            self.local_bar.config(value=100 * done / max(1, total))
            self.local_status.set(f"Downloading… {done / 1_000_000:.0f} of {total / 1_000_000:.0f} MB")
        elif msg[0] == "local_done":
            self.local_busy = False
            self.local_bar.stop()
            self.local_bar.grid_remove()
            self.refresh_local_status()
            if msg[1]:
                messagebox.showerror(APP, msg[1], parent=self)

    def refresh_ai_key(self):
        saved = read_claude_key()
        self.ai_key_note.set(f"A key is saved on this computer (ends …{saved[-4:]}). Type a new one to replace it."
                             if saved else "No key yet. Paste one here; it's kept on this computer only.")

    def show_ai_model_note(self):
        name = self.ai_model_cb.get()
        self.ai_model_note.set(next((m[2] for m in CLAUDE_MODELS if m[1] == name), ""))

    def chosen_ai_model(self):
        name = self.ai_model_cb.get()
        return next((m[0] for m in CLAUDE_MODELS if m[1] == name), DEFAULT_CLAUDE_MODEL)

    def keep_custom_text(self):
        if self.ai_layout == "custom":
            self.ai_custom = self.ai_text.get("1.0", "end-1c").strip()[:20000]

    def show_ai_layout(self):
        """Fill the box for the chosen layout: the built-in text (read-only), or the custom text to edit."""
        custom = self.ai_layout == "custom"
        self.ai_text.config(state="normal")
        self.ai_text.delete("1.0", "end")
        self.ai_text.insert("1.0", self.ai_custom if custom else AI_LAYOUTS[self.ai_layout][1])
        self.ai_text.edit_reset()
        self.ai_text.config(state="normal" if custom else "disabled",
                            foreground=INK if custom else MUTED)
        self.ai_layout_note.config(text="Type your own layout and instructions below." if custom else
                                   "Built in. To change it, click Make my own from this one.")

    def layout_chosen(self):
        self.keep_custom_text()
        name = self.ai_layout_cb.get()
        new = next((k for k, v in AI_LAYOUTS.items() if v[0] == name), "soap")
        if new == "custom" and not self.ai_custom:
            self.ai_custom = AI_LAYOUTS[self.ai_layout][1]      # start from the layout that was showing
        self.ai_layout = new
        self.show_ai_layout()

    def reset_ai_text(self):
        """Make my own from this one: copy the layout showing into Custom, ready to change."""
        if self.ai_layout != "custom":
            if self.ai_custom and not messagebox.askyesno(
                    APP, "This replaces the custom instructions you typed before. Go ahead?", parent=self):
                return
            self.ai_custom = AI_LAYOUTS[self.ai_layout][1]
            self.ai_layout = "custom"
            self.ai_layout_cb.set(AI_LAYOUTS["custom"][0])
            self.show_ai_layout()
        self.ai_text.focus_set()

    def current_ai_settings(self):
        self.keep_custom_text()
        return {"ai_model": self.chosen_ai_model(), "ai_layout": self.ai_layout, "ai_instructions": self.ai_custom}

    def save_ai_provider(self):
        """Kept on this computer (ai-provider.json), never in the buttons file. An address that would send consult
        text unencrypted over the internet isn't saved: the AI note stays as it was."""
        p = self.dialog_ai_provider()
        if p["engine"] == "openai":
            ok, url, problem = check_openai_url(p["openai_url"])
            if not ok or not p["openai_model"]:
                messagebox.showwarning(APP, (problem or "Type the model name.") + "\n\nThe AI note setting wasn't "
                                       "changed.", parent=self)
                p = dict(read_ai_provider(), local_model=p["local_model"])
            else:
                p["openai_url"] = url
        try:
            write_ai_provider(p)
            if self.openai_key.get().strip():
                write_openai_key(self.openai_key.get())
        except OSError as e:
            messagebox.showwarning(APP, f"Couldn't save the AI note setting: {e}", parent=self)

    def try_ai(self):
        """Write a note from a made-up consult with the choices in this window, before saving them. It's not patient
        text, so it doesn't need the agreement real notes need before being sent away."""
        p = self.dialog_ai_provider()
        settings, q = self.current_ai_settings(), self.dict_q
        if p["engine"] == "anthropic":
            key = self.ai_key.get().strip() or read_claude_key()
            if not key:
                messagebox.showinfo(APP, "Paste a Claude key first.", parent=self)
                return
            write = lambda: claude_write_note(AI_NOTE_SAMPLE, settings, key)  # noqa: E731
        elif p["engine"] == "openai":
            ok, url, problem = check_openai_url(p["openai_url"])
            if not ok or not p["openai_model"]:
                messagebox.showinfo(APP, problem or "Type the model name first.", parent=self)
                return
            key = self.openai_key.get().strip() or read_openai_key()
            write = lambda: openai_write_note(AI_NOTE_SAMPLE, settings, url, p["openai_model"], key)  # noqa: E731
        else:
            ready, why = local_ai_state(p)
            if not ready:
                messagebox.showinfo(APP, why, parent=self)
                return
            write = lambda: ai_write_note(AI_NOTE_SAMPLE, settings, p)  # noqa: E731
        self.ai_try_btn.state(["disabled"])
        self.ai_try_btn.config(text="Writing…")

        def work():
            try:
                q.put(("ai", write(), None))
            except AIError as e:
                q.put(("ai", None, str(e)))
            except Exception as e:  # noqa: BLE001
                log.exception("AI test failed")
                q.put(("ai", None, f"Something went wrong: {e}"))
        threading.Thread(target=work, daemon=True).start()

    def ai_done(self, note, problem):
        self.ai_try_btn.state(["!disabled"])
        self.ai_try_btn.config(text="Try it on a made-up consult…")
        if problem:
            messagebox.showerror(APP, problem, parent=self)
        else:
            messagebox.showinfo(APP, f"Made-up consult:\n{AI_NOTE_SAMPLE}\n\nThe note:\n\n{note}", parent=self)

    def revoke_ai(self):
        set_ai_consent(False)
        self.ai_consent_btn.state(["disabled"])
        messagebox.showinfo(APP, "Quickpad will ask again before it sends a note to an AI provider from this "
                                 "computer. Notes written on this computer don't need asking.", parent=self)

    # ---- Time saved tab
    def build_time_saved(self, t, s):
        t.columnconfigure(1, weight=1)
        self.ts_big = tk.StringVar()
        self.ts_forecast = tk.StringVar()
        self.ts_detail = tk.StringVar()
        tk.Label(t, textvariable=self.ts_big, font=("TkDefaultFont", 15, "bold"), fg="#1a7f37", bg=APP_BG,
                 justify="left", anchor="w", wraplength=680).grid(row=0, column=0, columnspan=3, sticky="ew")
        tk.Label(t, textvariable=self.ts_forecast, font=("TkDefaultFont", 12), fg=INK, bg=APP_BG, justify="left",
                 anchor="w", wraplength=680).grid(row=1, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Label(t, textvariable=self.ts_detail, foreground=MUTED, wraplength=680, justify="left").grid(
            row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))
        sf = ttk.LabelFrame(t, text="How it's worked out", padding=(10, 6))
        sf.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(12, 0))
        ttk.Label(sf, text="My typing speed").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(sf, from_=5, to=200, width=5, textvariable=self.dict_var("i", "typing_wpm", 40, s),
                    command=self.refresh_time_saved).grid(row=0, column=1, sticky="w", padx=6)
        ttk.Label(sf, text="words a minute").grid(row=0, column=2, sticky="w")
        ttk.Button(sf, text="Measure my typing…", command=self.measure_typing).grid(row=0, column=3, sticky="w", padx=(12, 0))
        ttk.Label(sf, text="Clinic days a week").grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Spinbox(sf, from_=1, to=7, width=5, textvariable=self.dict_var("i", "clinic_days", 5, s),
                    command=self.refresh_time_saved).grid(row=1, column=1, sticky="w", padx=6, pady=(4, 0))
        ttk.Label(sf, text="Working weeks a year").grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Spinbox(sf, from_=1, to=52, width=5, textvariable=self.dict_var("i", "weeks_per_year", 48, s),
                    command=self.refresh_time_saved).grid(row=2, column=1, sticky="w", padx=6, pady=(4, 0))
        ttk.Label(sf, text="Time saved = the words Quickpad typed, dictated or wrote for you at your typing speed, "
                           "minus the time spent talking, plus a second and a half for each key it pressed for you. "
                           "The forecast is your average clinic day over the last four weeks. Counted on this computer "
                           "only; what was typed is never recorded.", foreground=MUTED, wraplength=640,
                  justify="left").grid(row=3, column=0, columnspan=4, sticky="w", pady=(8, 0))
        for key in ("typing_wpm", "clinic_days", "weeks_per_year"):
            self.vars[key].trace_add("write", lambda *a: self.refresh_time_saved())
        self.refresh_time_saved()

    def time_settings(self):
        out = {}
        for key, lo, hi, default in (("typing_wpm", 5, 200, 40), ("clinic_days", 1, 7, 5), ("weeks_per_year", 1, 52, 48)):
            try:
                out[key] = max(lo, min(hi, int(self.vars[key].get())))
            except (ValueError, tk.TclError):
                out[key] = default
        return out

    def refresh_time_saved(self):
        if not hasattr(self, "ts_big"):
            return
        t = time_saved_summary(load_usage(), self.time_settings())
        c = t["counts"]
        if not t["all_days_used"]:
            self.ts_big.set("Start using your buttons and this fills in.")
            self.ts_forecast.set("Every button, dictation and AI note is counted as time you didn't spend typing.")
            self.ts_detail.set("")
            return
        self.ts_big.set(f"You've saved {describe_duration(t['all_time'])} so far"
                        f" ({describe_duration(t['today'])} today, {describe_duration(t['week_so_far'])} this week).")
        consults = int(t["per_year"] // (15 * 60))
        pace = f"about {describe_duration(t['per_week'])} a week, {describe_duration(t['per_month'])} a month and " \
               f"{describe_duration(t['per_year'])} a year"
        self.ts_forecast.set(f"At this pace that's {pace}" + (f": room for about {consults} more 15-minute consults "
                                                               "a year." if consults >= 2 else ".")
                             + ("" if t["days_used"] >= 5 else "  (Early days: this gets more accurate as you use it.)"))
        top = ", ".join(f"{tk_safe(name)} ({n})" for name, n in t["top"][:3])
        self.ts_detail.set(f"Buttons used {int(c['runs'])} times · {int(c['words'])} words typed for you · "
                           f"{int(c['dictated_words'])} words dictated · {int(c['ai_notes'])} AI notes "
                           f"({int(c['ai_words'])} words) · {int(c['actions'])} keys pressed for you"
                           + (f"\nMost used: {top}" if top else ""))

    def measure_typing(self):
        dlg = TypingTest(self)
        self.wait_window(dlg)
        if dlg.wpm:
            self.vars["typing_wpm"].set(str(dlg.wpm))

    # ---- small helpers
    def add_starter(self):
        panel = self.panel
        if not panel.cfg_ok:
            messagebox.showwarning(APP, "Your buttons file couldn't be read, so adding buttons is switched off.", parent=self)
            return
        if add_starter_notes(panel.cfg):
            touch_layout(panel.cfg)
            try:
                save_config(panel.cfg)
            except OSError as e:
                messagebox.showerror(APP, f"Couldn't save your buttons:\n{e}", parent=self)
                return
            panel.build()
            messagebox.showinfo(APP, "Added a group called “Clinical notes”. Look for it in the family list. Change "
                                     "any wording in Edit buttons.", parent=self)
        else:
            messagebox.showinfo(APP, "You already have a group called “Clinical notes”, so nothing was added.", parent=self)

    def import_file(self):
        panel = self.panel
        if not panel.cfg_ok:
            messagebox.showwarning(APP, "Your buttons file couldn't be read, so adding buttons is switched off.", parent=self)
            return
        path = filedialog.askopenfilename(parent=self, title="Choose a spreadsheet saved as CSV",
                                          initialdir=os.path.expanduser("~"),
                                          filetypes=[("CSV or text", "*.csv *.tsv *.txt"), ("All files", "*")])
        if not path:
            return
        try:
            fams = import_csv_buttons(path)
        except ValueError as e:
            messagebox.showerror(APP, f"Couldn't read {os.path.basename(path)}:\n{e}", parent=self)
            return
        total = sum(len(f["buttons"]) for f in fams)
        if not messagebox.askyesno(APP, f"Add {total} buttons in {len(fams)} group(s) from {os.path.basename(path)}?\n\n"
                                        "Your current buttons are kept.", parent=self):
            return
        write_backup(panel.cfg)
        have = {f["name"] for f in panel.cfg["families"]}
        for f in fams:
            if f["name"] in have:
                f["name"] += " (imported)"
            panel.cfg["families"].append(f)
        touch_layout(panel.cfg)
        try:
            save_config(panel.cfg)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't save your buttons:\n{e}", parent=self)
            return
        panel.build()
        messagebox.showinfo(APP, f"Added {total} buttons.", parent=self)

    def import_typeitin_file(self):
        panel = self.panel
        if not panel.cfg_ok:
            messagebox.showwarning(APP, "Your buttons file couldn't be read, so adding buttons is switched off.", parent=self)
            return
        path = filedialog.askopenfilename(parent=self, title="Choose TypeItIn's data file (datafile.enc)",
                                          initialdir=os.path.expanduser("~"),
                                          filetypes=[("TypeItIn data", "datafile* *.enc*"), ("All files", "*")])
        if not path:
            return
        self.configure(cursor="watch")
        self.update_idletasks()
        try:
            fams, unsupported = import_typeitin(path)
        except ValueError as e:
            messagebox.showerror(APP, f"Couldn't read {os.path.basename(path)}:\n{e}", parent=self)
            return
        finally:
            self.configure(cursor="")
        picked = choose_groups(self, fams)
        if not picked:
            return
        fams = [fams[i] for i in picked]
        total = sum(len(f["buttons"]) for f in fams)
        problems = write_backup(panel.cfg)
        if problems and not messagebox.askyesno(
                APP, "Couldn't make a backup of your buttons first:\n" + "\n".join(problems) +
                "\n\nAdd the TypeItIn buttons anyway?", parent=self):
            return
        have = {f["name"] for f in panel.cfg["families"]} | {ALL_FAMILIES}
        for f in fams:
            base, n = f["name"], 1
            while f["name"] in have:
                f["name"] = f"{base} (TypeItIn)" if n == 1 else f"{base} (TypeItIn {n})"
                n += 1
            have.add(f["name"])
        before, layout = list(panel.cfg["families"]), dict(panel.cfg.get("layout", {}))
        panel.cfg["families"].extend(fams)
        touch_layout(panel.cfg)
        try:
            save_config(panel.cfg)
        except OSError as e:
            panel.cfg["families"][:] = before
            panel.cfg["layout"] = layout
            messagebox.showerror(APP, f"Couldn't save your buttons, so nothing was added:\n{e}", parent=self)
            return
        panel.build()
        used = {w for f in fams for b in f["buttons"] for w in typeitin_only(b["steps"][0]["value"])}
        note = ""
        if used:
            note = ("\n\nA few buttons use TypeItIn commands Quickpad can't run (" + ", ".join(sorted(used)) +
                    "). They were brought in unchanged; those parts will be typed as written, so check them in "
                    "Edit buttons.")
        backed = "" if problems else ", and a backup was made first"
        messagebox.showinfo(APP, f"Added {total} buttons in {len(fams)} group(s). Your other buttons are kept"
                                 f"{backed}.{note}", parent=self)

    def use_cloud(self, name, folder):
        self.bdir.set(cloud_backup_dir(folder))
        if SCHEDULE_NAMES.get(self.sched_cb.get()) == "off":
            self.sched_cb.set(next(k for k, v in SCHEDULE_NAMES.items() if v == "daily"))
        messagebox.showinfo(APP, f"Backups will also be copied to\n{cloud_backup_dir(folder)}\n\n"
                                 "Click Save to keep this. It is copied when you back up and once a day.", parent=self)

    def copy_report(self):
        self.panel.set_clipboard(support_report(self.panel))
        messagebox.showinfo(APP, "Copied. Paste it into an email or message to Nick.", parent=self)

    def show_fixed(self):
        g = parse_geometry(self.fixed)
        self.fixed_txt.set(f"Saved spot: {g[2]} across, {g[3]} down." if g else "No spot saved yet.")

    def save_position(self):
        self.panel.unfade()
        self.fixed = self.panel.geometry_string()
        self.pos_mode.set("fixed")
        self.show_fixed()

    def last_backup_text(self):
        files = sorted(glob.glob(os.path.join(LOCAL_BACKUP_DIR, "quickpad-backup-*.json")))
        if not files:
            return "No automatic backup made yet."
        when = datetime.datetime.fromtimestamp(os.path.getmtime(files[-1]))
        return f"Last automatic backup: {when:%a %d %b, %I:%M %p}".replace(" 0", " ")

    def refresh_password(self):
        on = has_password(self.panel.cfg["settings"])
        self.pw_txt.set("A password is set." if on else "No password is set.")
        self.set_btn.config(text="Change password…" if on else "Set password…")
        for wdg in (self.rm_btn, self.cb_start, self.cb_restore):
            wdg.state(["!disabled"] if on else ["disabled"])

    # ---- immediate actions
    def choose_backup_dir(self):
        d = choose_folder(self, "Backup folder", "Choose a folder that should also receive a copy of every backup "
                          "(for example your OneDrive folder). Use New folder… to make one.", self.bdir.get(), "Use this folder")
        if d:
            self.bdir.set(d)

    def backup_now(self):
        cfg = copy.deepcopy(self.panel.cfg)
        cfg["settings"]["backup_dir"] = self.bdir.get().strip()
        errors = write_backup(cfg)
        self.last_txt.set(self.last_backup_text())
        if errors:
            messagebox.showerror(APP, "Some backups failed:\n\n" + "\n".join(errors), parent=self)
        else:
            messagebox.showinfo(APP, "Backed up to:\n\n" + "\n".join(backup_dirs(cfg)), parent=self)

    def backup_to_folder(self):
        backup_to_folder(self, self.panel.cfg, self.panel.cfg["settings"])

    def restore(self):
        self.destroy()
        self.panel.restore_backup()

    def set_password(self):
        st = self.panel.cfg["settings"]
        if has_password(st):
            old = ask_password(self, "Change password", "Type your current password first.")
            if old is None:
                return
            if not password_ok(st, old):
                messagebox.showerror(APP, "That isn't the current password.", parent=self)
                return
        new = ask_password(self, "Set password", "Choose a password for Quickpad. Write it down somewhere safe.", confirm=True)
        if new is None:
            return
        st["password_salt"], st["password_hash"] = hash_password(new)
        self.persist()
        self.refresh_password()
        messagebox.showinfo(APP, "Password set. Tick when you want it asked for, then click Save.", parent=self)

    def remove_password(self):
        st = self.panel.cfg["settings"]
        attempt = ask_password(self, "Remove password", "Type your current password to remove it.")
        if attempt is None:
            return
        if not password_ok(st, attempt):
            messagebox.showerror(APP, "That isn't the right password.", parent=self)
            return
        st["password_salt"] = st["password_hash"] = ""
        st["lock_on_start"] = st["lock_on_restore"] = False
        self.lock_start.set(False)
        self.lock_restore.set(False)
        self.persist()
        self.refresh_password()

    def persist(self):
        if self.panel.cfg_ok:
            try:
                save_config(self.panel.cfg)
            except OSError as e:
                messagebox.showerror(APP, f"Couldn't save:\n{e}", parent=self)

    def change_data_folder(self):
        new = choose_folder(self, "Data folder", "Where should Quickpad keep your buttons and settings? Use New "
                            "folder… to make one.", CONFIG_DIR, "Keep my data here")
        if new:
            self.move_data(new)

    def move_data(self, new):
        panel = self.panel
        if os.path.abspath(new) == os.path.abspath(CONFIG_DIR):
            return
        target = os.path.join(new, "buttons.json")
        use_theirs = False
        if os.path.exists(target):
            ans = messagebox.askyesnocancel(
                APP, "That folder already has Quickpad buttons in it.\n\nYes = use the ones that are already there\n"
                     "No = replace them with this computer's buttons (the old ones are kept as buttons.json.bak)\n"
                     "Cancel = do nothing", parent=self)
            if ans is None:
                return
            use_theirs = bool(ans)
        write_backup(panel.cfg)                  # a safety copy in the current location first
        old_dir, old_cfg = CONFIG_DIR, panel.cfg
        try:
            use_data_dir(new)
            if use_theirs:
                new_cfg, ok = load_config()
                if not ok:
                    raise OSError("the buttons in that folder couldn't be read")
            else:
                save_config(old_cfg)
                new_cfg = old_cfg
        except OSError as e:
            use_data_dir(old_dir)
            messagebox.showerror(APP, f"Couldn't switch to that folder:\n{e}", parent=self)
            return
        self.data_txt.set(CONFIG_DIR)
        self.last_txt.set(self.last_backup_text())
        if use_theirs:
            panel.apply_config(new_cfg)
        messagebox.showinfo(APP, f"Your buttons and settings are now kept in:\n{CONFIG_DIR}", parent=self)

    # ---- Save
    def save(self):
        v = self.vars
        try:
            speed = max(0, min(200, int(v["type_delay_ms"].get())))
            secs = max(5, min(3600, int(v["idle_seconds"].get())))
            opac = max(20, min(95, int(v["idle_opacity"].get())))
            listen = max(10, min(600, int(v["dictation_max_seconds"].get())))
        except ValueError:
            messagebox.showerror(APP, "Typing speed, seconds, how faint and how long to listen need to be whole "
                                      "numbers.", parent=self)
            return
        panel = self.panel
        s = panel.cfg["settings"]
        new_theme = THEME_NAMES.get(self.theme_cb.get(), "light")
        theme_changed = (not IS_MAC) and new_theme != self.saved_theme
        if theme_changed:
            write_local_theme(new_theme)
        s.update(
            show_on_start=bool(v["show_on_start"].get()), always_on_top=bool(v["always_on_top"].get()),
            position_mode=self.pos_mode.get(), fixed_geometry=self.fixed,
            text_size=TEXT_SIZE_NAMES.get(self.size_cb.get(), "normal"),
            idle_fade=bool(v["idle_fade"].get()), idle_seconds=secs, idle_opacity=opac,
            idle_style=self.idle_style.get() if self.idle_style.get() in ("rollup", "shrink", "fade") else "rollup",
            type_delay_ms=speed, global_hotkeys=bool(v["global_hotkeys"].get()),
            start_family="" if self.start_cb.get() == "The one I used last" else self.start_cb.get(),
            backup_schedule=SCHEDULE_NAMES.get(self.sched_cb.get(), "daily"), backup_on_save=bool(v["backup_on_save"].get()),
            backup_dir=self.bdir.get().strip(),
            lock_on_start=bool(v["lock_on_start"].get()) and has_password(s),
            lock_on_restore=bool(v["lock_on_restore"].get()) and has_password(s),
            dictation_model=self.dict_model, dictation_device=self.mic_device(),
            dictation_review=bool(v["dictation_review"].get()), dictation_max_seconds=listen,
            dictation_words=" ".join(v["dictation_words"].get().split())[:1000],
            dictation_show_heard=bool(v["dictation_show_heard"].get()),
            insert_method=self.insert_method.get() if self.insert_method.get() in ("type", "paste", "auto") else "type",
            paste_programs=self.paste_programs.get().strip() or DEFAULT_PASTE_PROGRAMS,
            # Keep corrections taught with Fix a word while this window was open; removals made here still stick.
            dictation_fixes=clean_fixes(self.fixes + [f for f in clean_fixes(s.get("dictation_fixes"))
                                                      if f["heard"].lower() not in self.fixes_at_open]),
            **self.time_settings(), **self.current_ai_settings(),
        )
        new_key = self.ai_key.get().strip()
        if new_key:
            try:
                write_claude_key(new_key)
            except OSError as e:
                problem_key = f"Couldn't save the Claude key: {e}"
                messagebox.showwarning(APP, problem_key, parent=self)
        self.save_ai_provider()
        if s["position_mode"] == "fixed" and not parse_geometry(s["fixed_geometry"]):
            s["position_mode"] = "last"
        problem = ""
        if bool(self.autostart.get()) != autostart_enabled():
            try:
                set_autostart(bool(self.autostart.get()))
            except OSError as e:
                problem = f"Saved, but couldn't change starting at login:\n{e}"
        self.sync_tab.save()
        self.persist()
        panel.apply_settings()
        self.destroy()
        if problem:
            messagebox.showwarning(APP, problem, parent=panel.root)
        if theme_changed and messagebox.askyesno(APP, "The new colours need Quickpad to restart.\n\nRestart it now?",
                                                 parent=panel.root):
            panel.restart_self()


# ================================================================ saved lists
# A saved list is a named set of choices kept with the buttons (SPEC-3.3 §3.3). Any button can pick from it with
# {List:Side} or tick several with {MultiList:Side}, so one list ("Side", "Body region") serves many buttons and is
# changed in one place. Edited on the Saved lists tab of Edit buttons.

LIST_REF_RE = re.compile(r"\{(\s*)(multilist|list)(\s*):([^{}]*)\}", re.I)


def find_saved_list(cfg, name):
    """The saved list called `name` (case and spaces at either end don't matter), or None."""
    want = str(name).strip().lower()
    return next((x for x in (cfg or {}).get("lists") or [] if str(x.get("name", "")).strip().lower() == want), None)


def list_item_line(it):
    """One item as a line in the Saved lists editor: `Label`, or `Label=>value` when they differ."""
    label, value = str(it.get("label", "")), it.get("value")
    if value is None or value == label:
        return label
    if value.rstrip() == label:            # a plain item that types a space at the end ("FU = ")
        return value
    return f"{label}=>{value}"


def parse_list_lines(text):
    """The Saved lists editor's text (one item per line, `Label=>value` allowed) as list items."""
    items = []
    for line in text.split("\n"):
        if not line.strip():
            continue
        it = macro_item(line)          # keeps a trailing space in what's typed ("FU = ")
        items.append({"label": it["label"]} if it["value"] == it["label"] else it)
    return items


def list_users(cfg, name):
    """(buttons, other saved lists) that pick from the saved list `name`."""
    want = str(name).strip().lower()

    def uses(text):
        return any(m.group(4).strip().lower() == want for m in LIST_REF_RE.finditer(str(text)))
    buttons = [b for f in cfg.get("families", []) for b in f.get("buttons", [])
               if any(st.get("type") == "text" and uses(st.get("value", "")) for st in b.get("steps", []))]
    lists = [x for x in cfg.get("lists", []) if str(x.get("name", "")).strip().lower() != want
             and any(uses(it.get("value", it.get("label", ""))) for it in x.get("items", []))]
    return buttons, lists


def rename_list_refs(cfg, old, new):
    """After a saved list is renamed: rewrite {List:Old} / {MultiList:Old} to the new name in every button and every
    other saved list, touching each one changed. Returns how many buttons changed."""
    want = str(old).strip().lower()

    def swap(text):
        return LIST_REF_RE.sub(lambda m: "{" + m.group(1) + m.group(2) + m.group(3) + ":" + new + "}"
                               if m.group(4).strip().lower() == want else m.group(0), text)
    changed = 0
    for f in cfg.get("families", []):
        for b in f.get("buttons", []):
            hit = False
            for st in b.get("steps", []):
                if st.get("type") == "text" and isinstance(st.get("value"), str):
                    new_text = swap(st["value"])
                    if new_text != st["value"]:
                        st["value"], hit = new_text, True
            if hit:
                touch_button(b)
                changed += 1
    for x in cfg.get("lists", []):
        hit = False
        for it in x.get("items", []):
            for k in ("label", "value"):
                if isinstance(it.get(k), str) and LIST_REF_RE.search(it[k]):
                    new_text = swap(it[k])
                    if new_text != it[k]:
                        it[k], hit = new_text, True
        if hit:
            touch_list(x)
    return changed


# ================================================================ workflows
# A workflow is an ordered list of steps, each pointing at a family by id (the same family may come up more than
# once), so a consult can go Symptoms › Objective › Adjustments › Adjustments › Treatment… one group at a time
# (SPEC-3.3 §4). The engine only ever tracks the step *index*: never the family's name, which can change. Which
# workflow is running, and which step it is on, belongs to this computer and this session only.

WORKFLOW_COMMANDS = {"nextstep": "next", "previousstep": "previous", "stay": "stay", "workflowstart": "first"}
AFTER_NAMES = {"default": "Use the workflow's setting", "stay": "Stay on this step", "next": "Go to the next step",
               "previous": "Go back a step", "first": "Go to the first step"}
MISSING_GROUP = "(missing group)"


def family_by_id(cfg, fid):
    return next((f for f in (cfg or {}).get("families") or [] if fid and f.get("id") == fid), None)


def workflow_by_id(cfg, wid):
    return next((w for w in (cfg or {}).get("workflows") or [] if wid and w.get("id") == wid), None)


def find_workflow(cfg, name):
    """The workflow called `name` (case and spaces at either end don't matter), or None."""
    want = " ".join(str(name).split()).lower()
    return next((w for w in (cfg or {}).get("workflows") or []
                 if " ".join(str(w.get("name", "")).split()).lower() == want), None)


def workflow_live_steps(cfg, wf):
    """Indexes of the steps whose family still exists: Next and Back skip the others."""
    return [i for i, st in enumerate((wf or {}).get("steps") or [])
            if isinstance(st, dict) and family_by_id(cfg, st.get("family_id"))]


def workflow_step(cfg, wf, index, action):
    """The step index after `action` ("next", "previous", "first" or "stay") from step `index`, skipping steps whose
    family is gone. Next past the last step goes back to the first if the workflow loops, otherwise stays; Back at
    the first step stays. None if no step has a family any more."""
    live = workflow_live_steps(cfg, wf)
    if not live:
        return None
    if action == "first":
        return live[0]
    if action == "next":
        later = [i for i in live if i > index]
        if later:
            return later[0]
        if wf.get("loop", True):
            return live[0]
    elif action == "previous":
        earlier = [i for i in live if i < index]
        if earlier:
            return earlier[-1]
    if index in live:                                  # stay (or nowhere further to go)
        return index
    later = [i for i in live if i > index]             # this step's family was deleted: the next one that's there
    return later[0] if later else live[-1]


def workflow_action(after, override, auto):
    """What a workflow does after a button finished: a {NextStep}-style command in the button wins (the last one),
    else the button's own "After this button" choice; "default" moves on only when moving on automatically is on."""
    action = override or after or "default"
    if action not in ("stay", "next", "previous", "first"):
        action = "next" if auto else "stay"
    return action


def workflows_using(cfg, fid):
    """Workflows with at least one step showing family `fid`."""
    return [w for w in (cfg or {}).get("workflows") or []
            if any(isinstance(st, dict) and st.get("family_id") == fid for st in w.get("steps") or [])]


def drop_family_from_workflows(cfg, fid):
    """A family is being deleted: take its steps out of every workflow (touching each one changed)."""
    for w in workflows_using(cfg, fid):
        w["steps"] = [st for st in w["steps"] if not (isinstance(st, dict) and st.get("family_id") == fid)]
        touch_workflow(w)


def step_trail(names, current, fits):
    """The compact trail under the workflow bar: `Symptoms › Objective › [Adjustments] › Treatment`, falling back to
    first words and then initials (`S › O › [A] › T`) when `fits(text)` says it's too wide. "" if nothing fits."""
    def initial(n):
        n = n.strip()
        return n[:1].upper() if n else "?"
    for short in (lambda n: n, lambda n: (n.split() or ["?"])[0][:12], initial):
        text = " › ".join(f"[{short(n)}]" if i == current else short(n) for i, n in enumerate(names))
        if fits(text):
            return text
    return ""


def rename_workflow_refs(cfg, old, new):
    """After a workflow is renamed: rewrite {Workflow Old} to the new name in every button. Returns how many
    buttons changed."""
    want = " ".join(str(old).split()).lower()
    pattern = re.compile(r"\{(\s*)(workflow)(\s+)([^{}]*)\}", re.I)

    def swap(text):
        return pattern.sub(lambda m: "{" + m.group(1) + m.group(2) + m.group(3) + new + "}"
                           if " ".join(m.group(4).split()).lower() == want else m.group(0), text)
    changed = 0
    for f in cfg.get("families", []):
        for b in f.get("buttons", []):
            hit = False
            for st in b.get("steps", []):
                if st.get("type") == "text" and isinstance(st.get("value"), str):
                    new_text = swap(st["value"])
                    if new_text != st["value"]:
                        st["value"], hit = new_text, True
            if hit:
                touch_button(b)
                changed += 1
    return changed


class ListsPane(ttk.Frame):
    """The Saved lists tab in Edit buttons: make, rename and delete lists, and type their items one per line.
    Works on the editor's own copy of the buttons, so nothing is kept until Save changes, like everything else there."""

    def __init__(self, parent, editor):
        super().__init__(parent, padding=(0, 8, 0, 0))
        self.editor = editor
        self.loading = False
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        left.rowconfigure(0, weight=1)
        self.names = tk.Listbox(left, width=28, exportselection=False, activestyle="none", font=("TkDefaultFont", 11))
        self.names.grid(row=0, column=0, sticky="ns")
        self.names.bind("<<ListboxSelect>>", lambda e: self.show())
        tools = ttk.Frame(left)
        tools.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        for i, (txt, cmd) in enumerate([("New list", self.new_list), ("Rename…", self.rename), ("Delete", self.delete)]):
            ttk.Button(tools, text=txt, command=cmd).grid(row=0, column=i, sticky="ew", padx=1)
            tools.columnconfigure(i, weight=1)

        right = ttk.Frame(self)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        self.heading = ttk.Label(right, font=("TkDefaultFont", 11, "bold"))
        self.heading.grid(row=0, column=0, sticky="w")
        ttk.Label(right, text="The choices, one on each line:").grid(row=1, column=0, sticky="w", pady=(8, 4))
        box = ttk.Frame(right)
        box.grid(row=2, column=0, sticky="nsew")
        box.columnconfigure(0, weight=1)
        box.rowconfigure(0, weight=1)
        self.items = tk.Text(box, width=50, height=12, wrap="none", undo=True, font=("TkFixedFont", 11))
        isb = ttk.Scrollbar(box, orient="vertical", command=self.items.yview)
        self.items.configure(yscrollcommand=isb.set)
        self.items.grid(row=0, column=0, sticky="nsew")
        isb.grid(row=0, column=1, sticky="ns")
        self.items.bind("<<Modified>>", self.items_changed)
        self.used = ttk.Label(right, foreground=MUTED, wraplength=520, justify="left")
        self.used.grid(row=3, column=0, sticky="w", pady=(6, 0))
        ttk.Label(right, text="To show one thing in the list but type another, write  Label=>what to type,  for "
                              "example  Both sides=>bilateral.  A choice can press keys ({Enter}, {Tab}) or open "
                              "another list, just like a button.\n\nIn a button, {List:Side} picks one from the list "
                              "called Side, and {MultiList:Side} lets you tick several (typed as “a, b and c”).",
                  foreground=MUTED, wraplength=520, justify="left").grid(row=4, column=0, sticky="w", pady=(10, 0))
        self.refresh()

    @property
    def lists(self):
        return self.editor.cfg.setdefault("lists", [])

    def selected(self):
        sel = self.names.curselection()
        return sel[0] if sel and sel[0] < len(self.lists) else None

    def refresh(self, select=None):
        if select is None:
            select = self.selected()
        self.names.delete(0, "end")
        for x in self.lists:
            self.names.insert("end", tk_safe(x.get("name", "")))
        if self.lists:
            i = min(select or 0, len(self.lists) - 1)
            self.names.selection_set(i)
            self.names.see(i)
        self.show()

    def show(self):
        i = self.selected()
        self.loading = True
        try:
            self.items.delete("1.0", "end")
            if i is None:
                self.heading.config(text="No saved lists yet. Click New list to make one.")
                self.items.configure(state="disabled")
                self.used.config(text="")
                return
            lst = self.lists[i]
            self.items.configure(state="normal")
            self.heading.config(text=tk_safe(f"Saved list: {lst['name']}"))
            self.items.insert("1.0", "\n".join(list_item_line(it) for it in lst.get("items", [])))
            self.items.edit_reset()
            self.items.edit_modified(False)
            self.show_used(lst)
        finally:
            self.loading = False

    def show_used(self, lst):
        buttons, lists = list_users(self.editor.cfg, lst["name"])
        n = len(buttons)
        text = (f"Used by {n} button{'s' if n != 1 else ''}" if n else "No buttons use this list yet") + \
               (" and the list" + ("s " if len(lists) > 1 else " ") + ", ".join(x["name"] for x in lists) if lists else "") + \
               ".  In a button:  {List:" + lst["name"] + "}"
        self.used.config(text=tk_safe(text))

    def items_changed(self, _e=None):
        if self.loading or not self.items.edit_modified():
            return
        self.items.edit_modified(False)
        i = self.selected()
        if i is None:
            return
        lst = self.lists[i]
        lst["items"] = parse_list_lines(self.items.get("1.0", "end-1c"))
        touch_list(lst)
        self.editor.touch()

    def ask_name(self, title, prompt, current=""):
        name = simpledialog.askstring(f"{APP} — {title}", prompt, initialvalue=current, parent=self)
        if name is None:
            return None
        name = " ".join(name.split())
        if not name or any(c in name for c in "{}:"):
            messagebox.showinfo(APP, "A list name can't be empty or contain { } or :.", parent=self)
            return None
        other = find_saved_list(self.editor.cfg, name)
        if other is not None and other.get("name") != current:
            messagebox.showinfo(APP, f"There's already a list called “{other['name']}”.", parent=self)
            return None
        return name

    def new_list(self):
        base, n, name = "New list", 1, "New list"
        while find_saved_list(self.editor.cfg, name):
            n += 1
            name = f"{base} {n}"
        name = self.ask_name("New list", "What should the list be called? (for example Side, or Body region)", name)
        if not name:
            return
        self.lists.append({"id": new_id("list"), "updated": now_ms(), "name": name, "items": []})
        touch_layout(self.editor.cfg)
        self.editor.touch()
        self.refresh(len(self.lists) - 1)
        self.items.focus_set()

    def rename(self):
        i = self.selected()
        if i is None:
            return
        lst = self.lists[i]
        old = lst["name"]
        name = self.ask_name("Rename list", f"New name for “{old}”:", old)
        if not name or name == old:
            return
        lst["name"] = name
        touch_list(lst)
        n = rename_list_refs(self.editor.cfg, old, name)
        self.editor.touch()
        self.refresh(i)
        if n:
            messagebox.showinfo(APP, f"Renamed. {n} button{'s were' if n != 1 else ' was'} changed to use the new "
                                     "name, so they keep working.", parent=self)

    def delete(self):
        i = self.selected()
        if i is None:
            return
        lst = self.lists[i]
        buttons, lists = list_users(self.editor.cfg, lst["name"])
        users = len(buttons) + len(lists)
        warn = ""
        if users:
            what = (f"{len(buttons)} button{'s' if len(buttons) != 1 else ''}" if buttons else "") + \
                   (" and " if buttons and lists else "") + \
                   (f"{len(lists)} other list{'s' if len(lists) != 1 else ''}" if lists else "")
            warn = (f"\n\n{what} use{'s' if users == 1 else ''} this list. If you delete it, they will stop "
                    "with a message when they get to it.")
        if not messagebox.askyesno(APP, f"Delete the saved list “{lst['name']}”?{warn}", parent=self):
            return
        tombstone(self.editor.cfg, lst)
        del self.lists[i]
        touch_layout(self.editor.cfg)
        self.editor.touch()
        self.refresh(max(0, i - 1))


class WorkflowsPane(ttk.Frame):
    """The Workflows tab in Edit buttons (SPEC-3.3 §4): make, rename, copy and delete workflows, and set out each one's
    steps, one family per step (a family can be used more than once). Works on the editor's own copy of the buttons,
    so nothing is kept until Save changes, like everything else there."""

    def __init__(self, parent, editor):
        super().__init__(parent, padding=(0, 8, 0, 0))
        self.editor = editor
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        left.rowconfigure(0, weight=1)
        self.names = tk.Listbox(left, width=28, exportselection=False, activestyle="none", font=("TkDefaultFont", 11))
        self.names.grid(row=0, column=0, sticky="ns")
        self.names.bind("<<ListboxSelect>>", lambda e: self.show())
        tools = ttk.Frame(left)
        tools.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        for i, (txt, cmd) in enumerate([("New workflow", self.new_workflow), ("Rename…", self.rename),
                                        ("Duplicate", self.duplicate), ("Delete", self.delete)]):
            ttk.Button(tools, text=txt, command=cmd).grid(row=i // 2, column=i % 2, sticky="ew", padx=1, pady=1)
        tools.columnconfigure((0, 1), weight=1)

        right = ttk.Frame(self)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        self.heading = ttk.Label(right, font=("TkDefaultFont", 11, "bold"))
        self.heading.grid(row=0, column=0, sticky="w")
        self.intro = ttk.Label(right, text="The steps, in order. Each step shows one group on the panel; a group can "
                                           "come up more than once.", foreground=MUTED, wraplength=520,
                               justify="left")
        self.intro.grid(row=1, column=0, sticky="w", pady=(6, 4))
        self.page = ScrollPage(right)
        self.page.grid(row=2, column=0, sticky="nsew")
        self.rows = self.page.inner
        self.add_btn = ttk.Button(right, text="Add step", command=self.add_step)
        self.add_btn.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.loop = tk.BooleanVar()
        self.auto = tk.BooleanVar()
        self.loop_cb = ttk.Checkbutton(right, text="Loop back to the first step", variable=self.loop,
                                       command=self.options_changed)
        self.loop_cb.grid(row=4, column=0, sticky="w", pady=(10, 0))
        self.auto_cb = ttk.Checkbutton(right, text="Move on automatically after each button", variable=self.auto,
                                       command=self.options_changed)
        self.auto_cb.grid(row=5, column=0, sticky="w")
        ttk.Label(right, text="Start a workflow from the family list on the panel (Workflows ▸ at the bottom). While "
                              "it runs, the panel shows one group at a time, with Back and Next. A button can stay on "
                              "its step, or go back, whatever the setting above: pick its “After this button” choice "
                              "on the Buttons tab.", foreground=MUTED, wraplength=520, justify="left").grid(
            row=6, column=0, sticky="w", pady=(10, 0))
        self.refresh()

    @property
    def workflows(self):
        return self.editor.cfg.setdefault("workflows", [])

    def selected(self):
        sel = self.names.curselection()
        return sel[0] if sel and sel[0] < len(self.workflows) else None

    def current(self):
        i = self.selected()
        return None if i is None else self.workflows[i]

    def refresh(self, select=None):
        if select is None:
            select = self.selected()
        self.names.delete(0, "end")
        for w in self.workflows:
            self.names.insert("end", tk_safe(w.get("name", "")))
        if self.workflows:
            i = min(select or 0, len(self.workflows) - 1)
            self.names.selection_set(i)
            self.names.see(i)
        self.show()

    def family_choices(self):
        """(names shown in each step's dropdown, matching family ids)."""
        fams = self.editor.cfg.get("families") or []
        return [tk_safe(f.get("name", "")) for f in fams], [f.get("id") for f in fams]

    def show(self):
        for w in self.rows.winfo_children():
            w.destroy()
        wf = self.current()
        state = ["!disabled"] if wf else ["disabled"]
        for w in (self.add_btn, self.loop_cb, self.auto_cb):
            w.state(state)
        if wf is None:
            self.heading.config(text="No workflows yet. Click New workflow to make one.")
            self.loop.set(False)
            self.auto.set(False)
            return
        self.heading.config(text=tk_safe(f"Workflow: {wf.get('name', '')}"))
        self.loop.set(bool(wf.get("loop", True)))
        self.auto.set(bool(wf.get("auto_advance", True)))
        names, ids = self.family_choices()
        steps = wf.setdefault("steps", [])
        if not steps:
            ttk.Label(self.rows, text="No steps yet. Click Add step.", foreground=MUTED).grid(row=0, column=0,
                                                                                         sticky="w")
        for i, st in enumerate(steps):
            ttk.Label(self.rows, text=f"{i + 1}.", width=3).grid(row=i, column=0, sticky="w", pady=1)
            cb = ttk.Combobox(self.rows, state="readonly", width=30, values=names)
            fid = st.get("family_id")
            if fid in ids:
                cb.current(ids.index(fid))
            else:
                cb.set(MISSING_GROUP)
            cb.grid(row=i, column=1, sticky="w", pady=1, padx=(0, 6))
            cb.bind("<<ComboboxSelected>>", lambda e, i=i, cb=cb: self.step_family(i, cb.current()))
            for c, (txt, cmd, ok) in enumerate([("▲", lambda i=i: self.move_step(i, -1), i > 0),
                                                ("▼", lambda i=i: self.move_step(i, 1), i < len(steps) - 1),
                                                ("Remove", lambda i=i: self.remove_step(i), True)]):
                b = ttk.Button(self.rows, text=txt, width=3 if len(txt) == 1 else 8, command=cmd)
                if not ok:
                    b.state(["disabled"])
                b.grid(row=i, column=2 + c, sticky="w", padx=1, pady=1)
        self.page.fit()

    def changed(self, wf, layout=False):
        touch_workflow(wf)
        if layout:
            touch_layout(self.editor.cfg)
        self.editor.touch()

    def step_family(self, i, choice):
        wf = self.current()
        _, ids = self.family_choices()
        if wf is None or not 0 <= choice < len(ids):
            return
        wf["steps"][i] = {**wf["steps"][i], "family_id": ids[choice]}
        self.changed(wf)
        self.show()

    def add_step(self):
        wf = self.current()
        _, ids = self.family_choices()
        if wf is None:
            return
        if not ids:
            messagebox.showinfo(APP, "Make a family on the Buttons tab first: each step shows one family.",
                                parent=self)
            return
        steps = wf.setdefault("steps", [])
        # the family after the last step's, so S, O, A, P can be added with a few clicks
        last = steps[-1].get("family_id") if steps else None
        nxt = ids[(ids.index(last) + 1) % len(ids)] if last in ids else ids[0]
        steps.append({"family_id": nxt})
        self.changed(wf)
        self.show()

    def move_step(self, i, d):
        wf = self.current()
        if wf is None or not 0 <= i + d < len(wf["steps"]):
            return
        s = wf["steps"]
        s[i], s[i + d] = s[i + d], s[i]
        self.changed(wf)
        self.show()

    def remove_step(self, i):
        wf = self.current()
        if wf is None or not 0 <= i < len(wf["steps"]):
            return
        del wf["steps"][i]
        self.changed(wf)
        self.show()

    def options_changed(self):
        wf = self.current()
        if wf is None:
            return
        wf["loop"], wf["auto_advance"] = bool(self.loop.get()), bool(self.auto.get())
        self.changed(wf)

    def ask_name(self, title, prompt, current=""):
        name = simpledialog.askstring(f"{APP} — {title}", prompt, initialvalue=current, parent=self)
        if name is None:
            return None
        name = " ".join(name.split())
        if not name or any(c in name for c in "{}"):
            messagebox.showinfo(APP, "A workflow name can't be empty or contain { or }.", parent=self)
            return None
        other = find_workflow(self.editor.cfg, name)
        if other is not None and other.get("name") != current:
            messagebox.showinfo(APP, f"There's already a workflow called “{other['name']}”.", parent=self)
            return None
        return name

    def unused_name(self, base):
        name, n = base, 1
        while find_workflow(self.editor.cfg, name):
            n += 1
            name = f"{base} {n}"
        return name

    def new_workflow(self):
        name = self.ask_name("New workflow", "What should the workflow be called? (for example Standard visit)",
                             self.unused_name("New workflow"))
        if not name:
            return
        self.workflows.append({"id": new_id("workflow"), "updated": now_ms(), "name": name, "loop": True,
                               "auto_advance": True, "steps": []})
        touch_layout(self.editor.cfg)
        self.editor.touch()
        self.refresh(len(self.workflows) - 1)

    def rename(self):
        i = self.selected()
        if i is None:
            return
        wf = self.workflows[i]
        old = wf.get("name", "")
        name = self.ask_name("Rename workflow", f"New name for “{old}”:", old)
        if not name or name == old:
            return
        wf["name"] = name
        n = rename_workflow_refs(self.editor.cfg, old, name)
        self.changed(wf)
        self.refresh(i)
        if n:
            messagebox.showinfo(APP, f"Renamed. {n} button{'s were' if n != 1 else ' was'} changed to use the new "
                                     "name, so they keep working.", parent=self)

    def duplicate(self):
        i = self.selected()
        if i is None:
            return
        dup = fresh_ids(copy.deepcopy(self.workflows[i]), "workflow")
        dup["name"] = self.unused_name(f"{dup.get('name', 'Workflow')} (copy)")
        self.workflows.insert(i + 1, dup)
        touch_layout(self.editor.cfg)
        self.editor.touch()
        self.refresh(i + 1)

    def delete(self):
        i = self.selected()
        if i is None:
            return
        wf = self.workflows[i]
        if not messagebox.askyesno(APP, f"Delete the workflow “{wf.get('name', '')}”? Its groups and buttons are "
                                        "not touched.", parent=self):
            return
        tombstone(self.editor.cfg, wf)
        del self.workflows[i]
        touch_layout(self.editor.cfg)
        self.editor.touch()
        self.refresh(max(0, i - 1))


# ================================================================ editor

class Editor(tk.Toplevel):
    def __init__(self, panel, select=None):
        super().__init__(panel.root)
        self.panel = panel
        self.cfg = copy.deepcopy(panel.cfg)
        self.base_doc = sync_doc(panel.cfg)      # what this working copy started from (see merge_editor_changes)
        self.dirty = False
        self.steps_lb = None
        self.title(f"{APP} — Editor")
        self.geometry("900x600")
        if panel.cfg["settings"]["always_on_top"]:
            self.attributes("-topmost", True)

        outer = ttk.Frame(self, padding=10)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(1, weight=1)
        outer.rowconfigure(0, weight=1)
        # Tabs: the buttons themselves, and the saved lists that buttons can pick from with {List:Name}.
        self.nb = ttk.Notebook(outer)
        self.nb.grid(row=0, column=0, columnspan=2, sticky="nsew")
        page = ttk.Frame(self.nb, padding=(0, 8, 0, 0))
        page.columnconfigure(1, weight=1)
        page.rowconfigure(0, weight=1)
        self.nb.add(page, text="Buttons")
        self.lists_page = ListsPane(self.nb, self)
        self.nb.add(self.lists_page, text="Saved lists")
        self.workflows_page = WorkflowsPane(self.nb, self)
        self.nb.add(self.workflows_page, text="Workflows")
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.tab_changed())

        left = ttk.Frame(page)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        left.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(left, show="tree", selectmode="browse")
        self.tree.column("#0", width=280)  # 250 clipped longer button names (a real user's list, v3.1.3 report)
        sb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.grid(row=0, column=0, sticky="ns")
        sb.grid(row=0, column=1, sticky="ns")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_detail())
        self.tree.bind("<Delete>", lambda e: self.delete())

        tools = ttk.Frame(left)
        tools.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        for i, (txt, cmd) in enumerate([
            ("New family", self.add_family), ("New button", self.add_button), ("Duplicate", self.duplicate),
            ("Move up", lambda: self.move(-1)), ("Move down", lambda: self.move(1)), ("Delete", self.delete),
        ]):
            ttk.Button(tools, text=txt, command=cmd).grid(row=i // 3, column=i % 3, sticky="ew", padx=1, pady=1)
        for c in range(3):
            tools.columnconfigure(c, weight=1)

        self.detail = ttk.Frame(page)
        self.detail.grid(row=0, column=1, sticky="nsew")

        # save / close row (typing speed, stay-on-top, backup folder etc. now live in Settings on the panel)
        row1 = ttk.Frame(outer)
        row1.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Label(row1, text="Typing speed, position, fading, password and backup options are under Settings on the panel.",
                  foreground=MUTED, wraplength=480, justify="left").pack(side="left")
        ttk.Button(row1, text="Close", command=self.close).pack(side="right")
        ttk.Button(row1, text="Save changes", command=self.save).pack(side="right", padx=6)

        # backups row
        row2 = ttk.LabelFrame(outer, text="Backups", padding=(8, 6))
        row2.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(row2, text="Export setup…", command=self.export).pack(side="left")
        ttk.Button(row2, text="Import setup…", command=self.import_).pack(side="left", padx=6)
        ttk.Button(row2, text="Back up now", command=self.backup_now).pack(side="left")

        where = "Portable mode: buttons stored beside quickpad.py" if PORTABLE else f"Buttons stored in {CONFIG_DIR}"
        ttk.Label(outer, text=f"Typing via {panel.backend.name}.  {where}.  A dated backup is made every time you save.",
                  foreground=MUTED, wraplength=640, justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))

        self.bind("<Control-s>", lambda e: self.save())
        if IS_MAC:
            self.bind("<Command-s>", lambda e: self.save())
        self.protocol("WM_DELETE_WINDOW", self.close)
        cur = panel.cfg["settings"].get("current_family")
        names = [f["name"] for f in self.cfg["families"]]
        start = f"f{names.index(cur)}" if cur in names else ("f0" if names else None)
        if select and 0 <= select[0] < len(self.cfg["families"]) and 0 <= select[1] < len(self.cfg["families"][select[0]]["buttons"]):
            start = f"f{select[0]}b{select[1]}"
        self.refresh_tree(start)

    def touch(self):
        """Something was changed and not saved yet (the title says so). The touch_* helpers stamp what changed."""
        if not self.dirty:
            self.dirty = True
            self.title(f"{APP} — Editor (unsaved)")

    def tab_changed(self):
        """Coming back to Buttons after renaming a saved list: the buttons' text may have been rewritten."""
        try:
            tab = self.nb.index(self.nb.select())
        except tk.TclError:
            return
        if tab == 0 and hasattr(self, "tree"):
            sel = self.tree.selection()
            self.refresh_tree(sel[0] if sel else None)
        elif tab == 1:
            self.lists_page.refresh()
        elif tab == 2 and hasattr(self, "workflows_page"):
            self.workflows_page.refresh()     # families may have been added, renamed or deleted meanwhile

    def selected(self):
        sel = self.tree.selection()
        if not sel:
            return None, None
        fi, _, bi = sel[0][1:].partition("b")
        return int(fi), (int(bi) if bi else None)

    def refresh_tree(self, select=None):
        self.tree.delete(*self.tree.get_children())
        for fi, f in enumerate(self.cfg["families"]):
            fid = f"f{fi}"
            self.tree.tag_configure(fid, foreground=f.get("colour", PALETTE[0]), font=("TkDefaultFont", 10, "bold"))
            self.tree.insert("", "end", iid=fid, text=tk_safe(f["name"]), open=True, tags=(fid,))
            for bi, b in enumerate(f["buttons"]):
                self.tree.insert(fid, "end", iid=f"{fid}b{bi}", text=button_caption(b))
        if select and self.tree.exists(select):
            self.tree.selection_set(select)
            self.tree.focus(select)
            self.tree.see(select)
        else:
            self.show_detail()

    # ---- tree actions
    def add_family(self):
        fams = self.cfg["families"]
        fams.append({"id": new_id("family"), "updated": now_ms(), "name": "New family",
                     "colour": PALETTE[len(fams) % len(PALETTE)], "buttons": []})
        touch_layout(self.cfg)
        self.touch()
        self.refresh_tree(f"f{len(fams) - 1}")

    def add_button(self):
        fams = self.cfg["families"]
        fi, bi = self.selected()
        if fi is None:
            if not fams:
                fams.append({"id": new_id("family"), "updated": now_ms(), "name": "General", "colour": PALETTE[0],
                             "buttons": []})
                touch_layout(self.cfg)
            fi = len(fams) - 1
        buttons = fams[fi]["buttons"]
        pos = bi + 1 if bi is not None else len(buttons)
        buttons.insert(pos, {"id": new_id("button"), "updated": now_ms(), "label": "New button", "steps": [],
                             "after": "default"})
        touch_family(fams[fi])
        self.touch()
        self.refresh_tree(f"f{fi}b{pos}")

    def duplicate(self):
        fi, bi = self.selected()
        if fi is None:
            return
        fams = self.cfg["families"]
        if bi is None:
            dup = fresh_ids(copy.deepcopy(fams[fi]), "family")
            dup["name"] += " (copy)"
            fams.insert(fi + 1, dup)
            touch_layout(self.cfg)
            target = f"f{fi + 1}"
        else:
            dup = fresh_ids(copy.deepcopy(fams[fi]["buttons"][bi]), "button")
            dup["label"] += " (copy)"
            fams[fi]["buttons"].insert(bi + 1, dup)
            touch_family(fams[fi])
            target = f"f{fi}b{bi + 1}"
        self.touch()
        self.refresh_tree(target)

    def move(self, d):
        fi, bi = self.selected()
        if fi is None:
            return
        fams = self.cfg["families"]
        items, i = (fams, fi) if bi is None else (fams[fi]["buttons"], bi)
        j = i + d
        if not 0 <= j < len(items):
            return
        items[i], items[j] = items[j], items[i]
        if bi is None:
            touch_layout(self.cfg)
        else:
            touch_family(fams[fi])
        self.touch()
        self.refresh_tree(f"f{j}" if bi is None else f"f{fi}b{j}")

    def delete(self):
        fi, bi = self.selected()
        if fi is None:
            return
        fams = self.cfg["families"]
        if bi is None:
            f = fams[fi]
            extra = f" and its {len(f['buttons'])} button(s)" if f["buttons"] else ""
            flows = workflows_using(self.cfg, f.get("id"))
            warn = ""
            if flows:
                names, s_ = ", ".join(f"“{w.get('name', '')}”" for w in flows), "s" if len(flows) > 1 else ""
                warn = (f"\n\nIt is a step in the workflow{s_} {names}. If you delete it, those steps are taken out "
                        f"of the workflow{s_}.")
            if not messagebox.askyesno(APP, f"Delete the family “{f['name']}”{extra}?{warn}", parent=self):
                return
            drop_family_from_workflows(self.cfg, f.get("id"))
            tombstone(self.cfg, f)
            del fams[fi]
            touch_layout(self.cfg)
            target = f"f{min(fi, len(fams) - 1)}" if fams else None
        else:
            b = fams[fi]["buttons"][bi]
            if not messagebox.askyesno(APP, f"Delete the button “{b['label']}”?", parent=self):
                return
            tombstone(self.cfg, b)
            del fams[fi]["buttons"][bi]
            touch_family(fams[fi])
            left = len(fams[fi]["buttons"])
            target = f"f{fi}b{min(bi, left - 1)}" if left else f"f{fi}"
        self.touch()
        self.refresh_tree(target)

    # ---- backups
    def export(self):
        """Back up to a folder of your choice (the chooser has a working New folder button)."""
        if backup_to_folder(self, self.cfg, self.panel.cfg["settings"]) and self.panel.cfg_ok:
            try:
                save_config(self.panel.cfg)
            except OSError:
                pass

    def import_(self):
        """Import setup…: a .quickpad setup file or an older .json backup, replacing everything or merging it in."""
        got = import_setup_file(self, self.cfg, self.panel.cfg["settings"].get("last_backup_folder", ""))
        if not got:
            return
        self.cfg, mode = got
        if mode == "replace":   # a replace brings the file's settings too, but never the ones that belong to this computer
            self.panel.cfg["settings"].update({k: copy.deepcopy(v) for k, v in self.cfg["settings"].items()
                                               if k not in MACHINE_SETTINGS})
        self.touch()
        self.save(backup=False)
        self.refresh_tree("f0" if self.cfg["families"] else None)
        self.lists_page.refresh()

    def backup_now(self):
        errors = write_backup(self.cfg)
        if errors:
            messagebox.showerror(APP, "Some backups failed:\n\n" + "\n".join(errors), parent=self)
        else:
            messagebox.showinfo(APP, "Backed up to:\n\n" + "\n".join(backup_dirs(self.cfg)), parent=self)

    def fit_to_content(self):
        """Grow the window (never shrink it) so nothing is cut off, as far as the screen allows."""
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        cur_w = self.winfo_width() if self.winfo_width() > 1 else 900
        cur_h = self.winfo_height() if self.winfo_height() > 1 else 600
        need_w, need_h = self.winfo_reqwidth() + 8, self.winfo_reqheight() + 8
        w, h = min(max(cur_w, need_w), sw - 60), min(max(cur_h, need_h), sh - 110)
        if (w, h) != (cur_w, cur_h):
            self.geometry(f"{w}x{h}")
        self.minsize(min(need_w, w), min(need_h, h))

    # ---- detail panes
    def show_detail(self):
        for w in self.detail.winfo_children():
            w.destroy()
        self.steps_lb = None
        fi, bi = self.selected()
        if fi is None:
            ttk.Label(self.detail, text="Select a family or button on the left, or create a new one.").pack(anchor="w")
        elif bi is None:
            self.family_detail(fi)
        else:
            self.button_detail(fi, bi)
        self.fit_to_content()

    def family_detail(self, fi):
        f = self.cfg["families"][fi]
        iid = f"f{fi}"
        d = self.detail
        d.columnconfigure(1, weight=1)
        ttk.Label(d, text="Family", font=("TkDefaultFont", 11, "bold")).grid(row=0, column=0, columnspan=3,
                                                                           sticky="w", pady=(0, 10))
        ttk.Label(d, text="Name").grid(row=1, column=0, sticky="w", padx=(0, 10))
        name = tk.StringVar(value=f["name"])
        ttk.Entry(d, textvariable=name, width=34).grid(row=1, column=1, columnspan=2, sticky="ew", pady=3)

        def on_name(*_):
            f["name"] = name.get()
            self.tree.item(iid, text=f["name"])
            touch_family(f)
            self.touch()
        name.trace_add("write", on_name)

        ttk.Label(d, text="Colour").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=(8, 0))
        row = ttk.Frame(d)
        row.grid(row=2, column=1, columnspan=2, sticky="w", pady=(8, 0))
        swatch = tk.Label(row, width=4, bg=f["colour"], relief="solid", bd=1)
        swatch.pack(side="left", padx=(0, 10))

        def set_colour(c):
            f["colour"] = c
            swatch.config(bg=c)
            self.tree.tag_configure(iid, foreground=c)
            touch_family(f)
            self.touch()
        for c in PALETTE:
            s = tk.Label(row, width=2, bg=c, cursor="hand2")
            s.pack(side="left", padx=1)
            s.bind("<Button-1>", lambda e, c=c: set_colour(c))

        def pick():
            c = colorchooser.askcolor(color=f["colour"], parent=self, title=f"{APP} — Family colour")[1]
            if c:
                set_colour(c)
        ttk.Button(row, text="Custom…", command=pick).pack(side="left", padx=(10, 0))

        keys = list(SIZE_NAMES)
        ttk.Label(d, text="Button size").grid(row=3, column=0, sticky="w", padx=(0, 10), pady=(12, 0))
        size_cb = ttk.Combobox(d, state="readonly", width=26, values=[SIZE_NAMES[k] for k in keys])
        size_cb.current(keys.index(f.get("size", "")) if f.get("size", "") in keys else 0)
        size_cb.grid(row=3, column=1, columnspan=2, sticky="w", pady=(12, 0))

        def on_size(_):
            f["size"] = keys[size_cb.current()]
            touch_family(f)
            self.touch()
        size_cb.bind("<<ComboboxSelected>>", on_size)

        ttk.Label(d, text="Buttons per row").grid(row=4, column=0, sticky="w", padx=(0, 10), pady=(8, 0))
        cols = tk.StringVar(value=str(f.get("columns", 1)))
        ttk.Spinbox(d, from_=1, to=4, width=5, textvariable=cols).grid(row=4, column=1, sticky="w", pady=(8, 0))

        def on_cols(*_):
            try:
                f["columns"] = max(1, min(4, int(cols.get())))
            except ValueError:
                return
            touch_family(f)
            self.touch()
        cols.trace_add("write", on_cols)

        n = len(f["buttons"])
        ttk.Label(d, text=f"{n} button{'s' if n != 1 else ''} in this family. Pick it from the dropdown on the panel "
                          "to show only these buttons, or use {Group " + f["name"] + "} in a button.",
                  foreground=MUTED, wraplength=520).grid(row=5, column=0, columnspan=3, sticky="w", pady=(14, 0))

    def button_detail(self, fi, bi):
        fams = self.cfg["families"]
        b = fams[fi]["buttons"][bi]
        iid = f"f{fi}b{bi}"
        d = self.detail
        d.columnconfigure(1, weight=1)
        d.rowconfigure(7, weight=1)
        ttk.Label(d, text="Button", font=("TkDefaultFont", 11, "bold")).grid(row=0, column=0, columnspan=3,
                                                                           sticky="w", pady=(0, 10))
        ttk.Label(d, text="Label").grid(row=1, column=0, sticky="w", padx=(0, 10))
        label = tk.StringVar(value=b["label"])
        ttk.Entry(d, textvariable=label).grid(row=1, column=1, sticky="ew", pady=3)

        def on_label(*_):
            b["label"] = label.get()
            self.tree.item(iid, text=button_caption(b))
            touch_button(b)
            self.touch()
        label.trace_add("write", on_label)

        ttk.Label(d, text="Family").grid(row=2, column=0, sticky="nw", padx=(0, 10), pady=(3, 0))
        famrow = ttk.Frame(d)
        famrow.grid(row=2, column=1, sticky="w", pady=3)
        fam_line = ttk.Frame(famrow)
        fam_line.pack(side="top", anchor="w")
        # The family used to be a dropdown that silently *moved* the button when changed. Users never read it as a
        # move control ("I don't see any way to move a button"), so the family is now just shown, and moving and
        # copying are two explicit, labelled rows below it.
        ttk.Label(fam_line, text=tk_safe(fams[fi]["name"]), font=("TkDefaultFont", 10, "bold")).pack(side="left")
        ttk.Label(fam_line, text="   Symbol").pack(side="left")
        icon_cb = ttk.Combobox(fam_line, state="readonly", width=4, values=["none"] + ICONS)
        icon_cb.set(b.get("icon") if b.get("icon") in ICONS else "none")
        icon_cb.pack(side="left", padx=(4, 0))

        def on_icon(_):
            b["icon"] = "" if icon_cb.get() == "none" else icon_cb.get()
            self.tree.item(iid, text=button_caption(b))
            touch_button(b)
            self.touch()
        icon_cb.bind("<<ComboboxSelected>>", on_icon)

        others = [(i, f["name"]) for i, f in enumerate(fams) if i != fi]
        if others:
            # Same results as the panel's right-click "Move to another family" / "Copy to another family", for
            # anyone who edits buttons through this dialog instead. Each on its own line (rather than tacked onto
            # fam_line) so they don't widen the dialog past what fits on a small screen — an earlier version did
            # exactly that and the control couldn't be seen at all.
            line = ttk.Frame(famrow)
            line.pack(side="top", anchor="w", pady=(4, 0))
            ttk.Label(line, text="Other family").pack(side="left")
            other_cb = ttk.Combobox(line, state="readonly", width=16, values=[tk_safe(name) for _, name in others])
            other_cb.current(0)
            other_cb.pack(side="left", padx=(4, 0))

            def on_move_to():
                target_fi = others[other_cb.current()][0]
                fams[target_fi]["buttons"].append(fams[fi]["buttons"].pop(bi))
                touch_button(b)
                touch_family(fams[fi])
                touch_family(fams[target_fi])
                self.touch()
                # Jump to the button in its new family — its old tree entry no longer exists.
                self.refresh_tree(f"f{target_fi}b{len(fams[target_fi]['buttons']) - 1}")

            def on_copy_to():
                target_fi = others[other_cb.current()][0]
                fams[target_fi]["buttons"].append(copy_button(b))
                touch_family(fams[target_fi])
                self.touch()
                # Jump to the new copy, same as Duplicate and Move do — otherwise the target family's tree entry
                # never appears until something else happens to rebuild it.
                self.refresh_tree(f"f{target_fi}b{len(fams[target_fi]['buttons']) - 1}")

            # One line, one dropdown, two buttons: Move takes it out of this family, Copy leaves it here too. Kept
            # to a single line so the Steps box below keeps its height on a laptop screen.
            ttk.Button(line, text="Move", width=6, command=on_move_to).pack(side="left", padx=(4, 0))
            ttk.Button(line, text="Copy", width=6, command=on_copy_to).pack(side="left", padx=(4, 0))
        else:
            ttk.Label(famrow, text="Make another family to move or copy buttons into.",
                      foreground=MUTED).pack(side="top", anchor="w", pady=(4, 0))

        ttk.Label(d, text="Shortcut key").grid(row=3, column=0, sticky="w", padx=(0, 10))
        srow = ttk.Frame(d)
        srow.grid(row=3, column=1, sticky="w", pady=3)
        sc_txt = tk.StringVar(value=normalise_shortcut(b.get("shortcut", "")) or "none")
        ttk.Label(srow, textvariable=sc_txt, width=16, relief="solid", padding=(6, 3)).pack(side="left")
        hint = tk.StringVar()
        ttk.Label(d, textvariable=hint, foreground=MUTED, wraplength=520, justify="left").grid(
            row=4, column=1, columnspan=2, sticky="w")

        def refresh_hint():
            sc = normalise_shortcut(b.get("shortcut", ""))
            panel, on = self.panel, self.panel.cfg["settings"].get("global_hotkeys", True)
            if not sc:
                hint.set("Optional. Press this key to run the button.")
            elif not panel.hotkeys_available():
                hint.set("Works when Quickpad is the active window. (Shortcut keys that work in any program need "
                         "Linux with X11.)")
            elif not hotkey_eligible(sc):
                hint.set("Only works when Quickpad is the active window. To make it work in any program, use Ctrl or "
                         "Alt with a key (for example ctrl+alt+1) or an F key.")
            elif not on:
                hint.set("Works when Quickpad is the active window. (Any-program shortcuts are switched off in Settings.)")
            else:
                hint.set("Works in any program.")
        refresh_hint()

        def set_shortcut():
            sc = ask_shortcut(self)
            if not sc:
                return
            used = [x["label"] for fam in fams for x in fam["buttons"] if x is not b and normalise_shortcut(x.get("shortcut", "")) == sc]
            if used:
                messagebox.showwarning(APP, f"“{used[0]}” already uses {sc}. Whichever comes first on the panel wins.", parent=self)
            b["shortcut"] = sc
            sc_txt.set(sc)
            refresh_hint()
            touch_button(b)
            self.touch()

        def clear_shortcut():
            b["shortcut"] = ""
            sc_txt.set("none")
            refresh_hint()
            touch_button(b)
            self.touch()
        ttk.Button(srow, text="Set…", command=set_shortcut).pack(side="left", padx=6)
        ttk.Button(srow, text="Clear", command=clear_shortcut).pack(side="left")

        confirm = tk.BooleanVar(value=bool(b.get("confirm")))

        def on_confirm(*_):
            b["confirm"] = bool(confirm.get())
            touch_button(b)
            self.touch()
        confirm.trace_add("write", on_confirm)
        opts = ttk.Frame(d)
        opts.grid(row=5, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Checkbutton(opts, text="Ask “Are you sure?” before running this button", variable=confirm).pack(
            side="top", anchor="w")
        # What a running workflow does once this button has finished (SPEC-3.3 §4)
        after_line = ttk.Frame(opts)
        after_line.pack(side="top", anchor="w", pady=(4, 0))
        ttk.Label(after_line, text="After this button (in a workflow)").pack(side="left")
        keys = list(AFTER_NAMES)
        after_cb = ttk.Combobox(after_line, state="readonly", width=26, values=[AFTER_NAMES[k] for k in keys])
        after_cb.current(keys.index(b.get("after")) if b.get("after") in keys else 0)
        after_cb.pack(side="left", padx=(6, 0))

        def on_after(_):
            b["after"] = keys[after_cb.current()]
            touch_button(b)
            self.touch()
        after_cb.bind("<<ComboboxSelected>>", on_after)
        self.after_cb = after_cb

        ttk.Label(d, text="Steps, run top to bottom. Most buttons need just one Type text step.").grid(
            row=6, column=0, columnspan=3, sticky="w", pady=(14, 4))
        box = ttk.Frame(d)
        box.grid(row=7, column=0, columnspan=3, sticky="nsew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        lb = tk.Listbox(box, activestyle="none", exportselection=False, font=("TkFixedFont", 10), height=6)
        lsb = ttk.Scrollbar(box, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=lsb.set)
        lb.grid(row=0, column=0, sticky="nsew")
        lsb.grid(row=0, column=1, sticky="ns")
        lb.bind("<Double-Button-1>", lambda e: self.edit_step(b))
        self.steps_lb = lb

        ctrl = ttk.Frame(d)
        ctrl.grid(row=8, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        for i, (txt, cmd) in enumerate([
            ("Add text", lambda: self.add_step(b, "text")),
            ("Add keys", lambda: self.add_step(b, "key")),
            ("Add wait", lambda: self.add_step(b, "delay")),
            ("Test in 3 s", lambda: self.test_button(b)),
            ("Edit step", lambda: self.edit_step(b)),
            ("Move up", lambda: self.move_step(b, -1)),
            ("Move down", lambda: self.move_step(b, 1)),
            ("Remove", lambda: self.remove_step(b)),
        ]):
            ttk.Button(ctrl, text=txt, command=cmd).grid(row=i // 4, column=i % 4, sticky="ew", padx=2, pady=2)
        for c in range(4):
            ctrl.columnconfigure(c, weight=1)
        self.fill_steps(b)

    def test_button(self, b):
        if not b["steps"]:
            return
        messagebox.showinfo(APP, "Click into the place you want it typed. It runs 3 seconds after you press OK.", parent=self)
        self.panel.root.after(3000, lambda: self.panel.fire(b))

    # ---- steps
    def fill_steps(self, b, select=None):
        lb = self.steps_lb
        lb.delete(0, "end")
        for s in b["steps"]:
            lb.insert("end", describe(s))
        if not b["steps"]:
            lb.insert("end", "(no steps yet — click Add text)")
            lb.itemconfig(0, foreground=MUTED)
        elif select is not None and 0 <= select < len(b["steps"]):
            lb.selection_set(select)
            lb.see(select)

    def step_index(self, b):
        sel = self.steps_lb.curselection()
        return sel[0] if sel and sel[0] < len(b["steps"]) else None

    def add_step(self, b, kind):
        default = {"text": "", "key": "", "delay": 200}[kind]
        res = StepDialog(self, {"type": kind, "value": default}).result
        if res:
            i = self.step_index(b)
            pos = i + 1 if i is not None else len(b["steps"])
            b["steps"].insert(pos, res)
            touch_button(b)
            self.touch()
            self.fill_steps(b, pos)

    def edit_step(self, b):
        i = self.step_index(b)
        if i is None:
            return
        res = StepDialog(self, copy.deepcopy(b["steps"][i])).result
        if res:
            b["steps"][i] = res
            touch_button(b)
            self.touch()
            self.fill_steps(b, i)

    def move_step(self, b, d):
        i = self.step_index(b)
        if i is None or not 0 <= i + d < len(b["steps"]):
            return
        s = b["steps"]
        s[i], s[i + d] = s[i + d], s[i]
        touch_button(b)
        self.touch()
        self.fill_steps(b, i + d)

    def remove_step(self, b):
        i = self.step_index(b)
        if i is None:
            return
        del b["steps"][i]
        touch_button(b)
        self.touch()
        self.fill_steps(b, min(i, len(b["steps"]) - 1))

    # ---- save / close
    def save(self, backup=True):
        # A sync may have changed the saved buttons while this window was open: combine, don't overwrite.
        synced_in = merge_editor_changes(getattr(self, "base_doc", None), self.cfg, self.panel.cfg)
        # Settings are edited in the Settings dialog, so always keep the panel's current ones.
        s = self.cfg["settings"] = copy.deepcopy(self.panel.cfg["settings"])
        self.panel.persist_ui_state()
        s["geometry"] = self.panel.cfg["settings"]["geometry"]
        s["collapsed"] = self.panel.cfg["settings"]["collapsed"]
        s["current_family"] = self.panel.cfg["settings"].get("current_family", ALL_FAMILIES)
        try:
            save_config(self.cfg)
        except OSError as e:
            messagebox.showerror(APP, f"Couldn't save to {CONFIG_PATH}:\n{e}", parent=self)
            return False
        self.base_doc = sync_doc(self.cfg)
        errors = write_backup(self.cfg) if (backup and s.get("backup_on_save", True)) else []
        self.panel.apply_config(copy.deepcopy(self.cfg))
        if synced_in:                            # show what arrived from the other devices too
            sel = self.tree.selection()
            self.refresh_tree(sel[0] if sel else None)
            self.lists_page.refresh()
        self.panel.sync_hotkeys(report=True)
        self.attributes("-topmost", s["always_on_top"])
        self.dirty = False
        self.title(f"{APP} — Editor")
        if errors:
            messagebox.showwarning(APP, "Saved, but the backup folder couldn't be written:\n\n" + "\n".join(errors),
                                   parent=self)
        return True

    def close(self):
        if self.dirty:
            ans = messagebox.askyesnocancel(APP, "Save your changes before closing?", parent=self)
            if ans is None or (ans and not self.save()):
                return
        self.destroy()


class StepDialog(tk.Toplevel):
    def __init__(self, parent, step):
        super().__init__(parent)
        self.title(f"{APP} — Step")
        self.transient(parent)
        self.result = None
        self.orig = step
        self.w = None

        body = ttk.Frame(self, padding=12)
        body.pack(fill="both", expand=True)
        self.kind = tk.StringVar(value=step.get("type", "text"))
        row = ttk.Frame(body)
        row.pack(fill="x")
        for k, txt in (("text", "Type text"), ("key", "Press keys"), ("delay", "Wait")):
            ttk.Radiobutton(row, text=txt, value=k, variable=self.kind, command=self.render).pack(side="left", padx=(0, 14))
        self.area = ttk.Frame(body)
        self.area.pack(fill="both", expand=True, pady=10)
        btns = ttk.Frame(body)
        btns.pack(fill="x")
        ttk.Button(btns, text="OK", command=self.ok).pack(side="right")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=6)
        self.bind("<Escape>", lambda e: self.destroy())

        self.render()
        self.wait_visibility()
        self.grab_set()
        self.w.focus_set()
        self.wait_window()

    def record(self):
        sc = ask_shortcut(self, "Press the key or combination to add to this step.\n\nPress Esc to cancel.")
        if sc:
            cur = self.w.get().strip()
            self.w.set((cur + " " + sc).strip())

    def insert_command(self, snippet):
        self.w.insert("insert", snippet)
        # Select the example argument so it can be typed over, e.g. "One,Two,Three" in {List One,Two,Three}.
        inner = snippet[1:-1]
        name, _, arg = inner.partition(" ")
        if arg and "=" not in inner:
            start = self.w.index(f"insert-{len(arg) + 1}c")
            self.w.tag_remove("sel", "1.0", "end")
            self.w.tag_add("sel", start, f"insert-1c")
            self.w.mark_set("insert", f"insert-1c")
        self.w.focus_set()

    def render(self):
        for w in self.area.winfo_children():
            w.destroy()
        k = self.kind.get()
        val = self.orig.get("value", "") if k == self.orig.get("type") else ""
        hint = {"foreground": "#666"}
        if k == "text":
            top = ttk.Frame(self.area)
            top.pack(fill="x")
            ttk.Label(top, text="Text to type. Use {Enter} or a real new line to break lines.").pack(side="left")
            mb = ttk.Menubutton(top, text="Insert command ▾")
            menu = tk.Menu(mb, tearoff=0)
            subs = {}
            for label, snippet, desc in COMMANDS:
                if label is None:
                    menu.add_separator()
                    continue
                target, group = menu, COMMAND_GROUPS.get(snippet)
                if group:
                    if group not in subs:
                        subs[group] = tk.Menu(menu, tearoff=0)
                        menu.add_cascade(label=group, menu=subs[group])
                    target = subs[group]
                target.add_command(label=f"{label}    {snippet}", command=lambda s=snippet: self.insert_command(s))
            mb["menu"] = menu
            mb.pack(side="right")
            self.w = tk.Text(self.area, width=58, height=10, wrap="word", undo=True, font=("TkFixedFont", 11))
            self.w.pack(fill="both", expand=True, pady=(6, 0))
            self.w.insert("1.0", str(val))
            ttk.Label(self.area, text="e.g.  123 Example St{Enter}Suburb SA 5000",
                      **hint).pack(anchor="w", pady=(6, 0))
            self.unbind("<Return>")
        elif k == "key":
            ttk.Label(self.area, text="Keys to press in the program you were using, e.g. Tab, Return, F5 or ctrl+s.\n"
                                      "Use + only to hold ctrl, alt or shift with a key (ctrl+s). Put a SPACE between "
                                      "keys pressed one after another (Tab Tab Return).", justify="left").pack(anchor="w")
            row = ttk.Frame(self.area)
            row.pack(anchor="w", pady=6, fill="x")
            self.w = ttk.Combobox(row, values=KEY_PRESETS, width=36)
            self.w.set(str(val))
            self.w.pack(side="left")
            ttk.Button(row, text="Record a key…", command=self.record).pack(side="left", padx=8)
            ttk.Label(self.area, text="Examples: ctrl+shift+t   |   Tab Tab Return   |   F5   |   z x  (z, then x)\n"
                                      "Modifiers: ctrl, shift, alt, cmd (⌘ on Mac, Win key on Windows, Super on Linux).\n"
                                      "Record a key…: click it, then press the key or combination yourself.",
                      justify="left", **hint).pack(anchor="w")
            self.bind("<Return>", lambda e: self.ok())
        else:
            ttk.Label(self.area, text="Pause before the next step (milliseconds):").pack(anchor="w")
            self.w = ttk.Spinbox(self.area, from_=0, to=60000, increment=50, width=10)
            self.w.set(str(val if val != "" else 200))
            self.w.pack(anchor="w", pady=4)
            self.bind("<Return>", lambda e: self.ok())
        self.w.focus_set()

    def ok(self):
        k = self.kind.get()
        if k == "text":
            v = self.w.get("1.0", "end-1c")
            if not v:
                messagebox.showinfo(APP, "Enter some text to type.", parent=self)
                return
        elif k == "key":
            v = " ".join(self.w.get().split())
            if not v:
                messagebox.showinfo(APP, "Enter the keys to press, e.g. ctrl+s.", parent=self)
                return
            problem = validate_keys(v)
            if problem:
                messagebox.showinfo(APP, problem, parent=self)
                return
        else:
            try:
                v = max(0, int(float(self.w.get())))
            except ValueError:
                messagebox.showinfo(APP, "Enter the wait as a number of milliseconds.", parent=self)
                return
        self.result = {"type": k, "value": v}
        self.destroy()


class FirstRunWizard(tk.Toplevel):
    """Shown once, the first time Quickpad runs on a computer (Panel.fresh_install), instead of leaving a new user
    to find Settings on their own: where to keep buttons, whether to bring existing ones across, dictation, then a
    short tour. Every page hands off to existing, already-tested machinery (choose_folder/use_data_dir,
    setup_dictation, Panel.restore_backup, Settings > Buttons) rather than reimplementing any of it."""

    PAGES = ("welcome", "folder", "import", "dictation", "tour")

    def __init__(self, panel):
        super().__init__(panel.root)
        self.panel = panel
        self.step = 0
        self.dict_busy = False
        self.dict_q = queue.Queue()
        self.dict_stop = threading.Event()

        self.title(f"Welcome to {APP}")
        self.configure(bg=APP_BG)
        self.geometry("560x440")
        self.minsize(520, 400)
        self.transient(panel.root)
        self.protocol("WM_DELETE_WINDOW", self.finish)
        self.bind("<Escape>", lambda e: self.finish())

        self.body = ttk.Frame(self, padding=20)
        self.body.pack(fill="both", expand=True)
        nav = ttk.Frame(self, padding=(20, 0, 20, 16))
        nav.pack(side="bottom", fill="x")
        self.back_btn = ttk.Button(nav, text="Back", command=self.go_back)
        self.back_btn.pack(side="left")
        self.next_btn = ttk.Button(nav, text="Next", style="Big.TButton", command=self.go_next)
        self.next_btn.pack(side="right")

        self.render()
        self.grab_set()
        self.focus_force()

    # ---- navigation

    def render(self):
        for w in self.body.winfo_children():
            w.destroy()
        getattr(self, f"page_{self.PAGES[self.step]}")()
        self.back_btn.state(["disabled"] if self.step == 0 else ["!disabled"])
        self.next_btn.config(text="Get started" if self.step == len(self.PAGES) - 1 else "Next")

    def go_back(self):
        if self.step > 0:
            self.step -= 1
            self.render()

    def go_next(self):
        if self.PAGES[self.step] == "dictation":
            self._mark_dictation_offered()
        if self.step >= len(self.PAGES) - 1:
            self.finish()
            return
        self.step += 1
        self.render()

    def finish(self):
        self.dict_stop.set()
        self.destroy()

    def _mark_dictation_offered(self):
        try:
            with open(DICTATION_OFFERED_PATH, "w", encoding="utf-8") as f:
                f.write(VERSION)
        except OSError:
            pass

    # ---- welcome

    def page_welcome(self):
        ttk.Label(self.body, text=f"Welcome to {APP}", font=("TkDefaultFont", 16, "bold")).pack(anchor="w")
        ttk.Label(self.body, text="A few quick questions before your buttons are ready. Everything here can be "
                                  "changed again later in Settings.", foreground=MUTED, wraplength=480,
                  justify="left", padding=(0, 10, 0, 0)).pack(anchor="w")

    # ---- data folder

    def page_folder(self):
        ttk.Label(self.body, text="Where should your buttons live?", font=("TkDefaultFont", 14, "bold")).pack(anchor="w")
        ttk.Label(self.body, text="Buttons, settings and backups are kept here. Pick a synced folder (Dropbox, "
                                  "OneDrive, a network drive) to share them with another computer.",
                  foreground=MUTED, wraplength=480, justify="left", padding=(0, 8, 0, 14)).pack(anchor="w")
        self.folder_var = tk.StringVar(value=CONFIG_DIR)
        ttk.Entry(self.body, textvariable=self.folder_var, state="readonly").pack(fill="x")
        ttk.Button(self.body, text="Choose a different folder…", command=self.choose_data_folder).pack(
            anchor="w", pady=(10, 0))

    def choose_data_folder(self):
        new = choose_folder(self, "Data folder", "Where should Quickpad keep your buttons, settings and backups? "
                            "Use New folder… to make one.", CONFIG_DIR, "Keep my data here")
        if not new or os.path.abspath(new) == os.path.abspath(CONFIG_DIR):
            return
        old_dir = CONFIG_DIR
        try:
            use_data_dir(new)
            fresh = not os.path.exists(CONFIG_PATH)   # before load_config(), which creates it if missing
            cfg, ok = load_config()
            if not ok:
                raise OSError("the buttons in that folder couldn't be read")
        except OSError as e:
            use_data_dir(old_dir)
            messagebox.showerror(APP, f"Couldn't switch to that folder:\n{e}", parent=self)
            return
        self.panel.fresh_install = fresh
        self.panel.apply_config(cfg)
        self.folder_var.set(CONFIG_DIR)

    # ---- import existing setup

    def page_import(self):
        ttk.Label(self.body, text="Bring across existing buttons?", font=("TkDefaultFont", 14, "bold")).pack(anchor="w")
        ttk.Label(self.body, text="Optional — skip with Next if you're starting fresh.", foreground=MUTED,
                  padding=(0, 6, 0, 14)).pack(anchor="w")
        ttk.Button(self.body, text="Restore a Quickpad backup…", command=self.do_restore).pack(
            anchor="w", fill="x", pady=4)
        ttk.Button(self.body, text="Import from TypeItIn or a spreadsheet (CSV)…", command=self.do_import_other).pack(
            anchor="w", fill="x", pady=4)

    def do_restore(self):
        self.grab_release()
        try:
            self.panel.restore_backup()
        finally:
            if self.winfo_exists():
                self.grab_set()
                self.lift()
                self.focus_force()

    def do_import_other(self):
        self.finish()
        self.panel.open_settings()
        win = self.panel.settings_win
        if win is not None and "Buttons" in win.tabs:
            win.nb.select(win.tabs["Buttons"])

    # ---- dictation

    def page_dictation(self):
        ttk.Label(self.body, text="Set up dictation?", font=("TkDefaultFont", 14, "bold")).pack(anchor="w")
        ready, _ = engine_status()
        if ready:
            ttk.Label(self.body, text="Dictation is already set up on this computer.", foreground=MUTED,
                      padding=(0, 8, 0, 0)).pack(anchor="w")
            return
        info = machine_info()
        key = chosen_model(self.panel.cfg["settings"])
        m = model_info(key)
        ttk.Label(self.body, text=describe_machine(info), foreground=MUTED, wraplength=480, justify="left",
                  padding=(0, 6, 0, 4)).pack(anchor="w")
        ttk.Label(self.body, text=f"Suggested model: {m['name']} ({m['accuracy'].lower()} accuracy, about "
                                  f"{describe_wait(estimate_wait(m, info))} per note). Dictation listens when you "
                                  "click a Dictate button and types what you say, worked out on this computer — "
                                  "nothing is sent anywhere.", wraplength=480, justify="left").pack(anchor="w")
        self.dict_key = key
        self.dict_status = tk.StringVar(value="")
        self.setup_btn = ttk.Button(self.body, text="Set up dictation now", style="Big.TButton",
                                    command=self.start_dictation_setup)
        self.setup_btn.pack(anchor="w", pady=(12, 0))
        self.dict_bar = ttk.Progressbar(self.body, mode="indeterminate")
        ttk.Label(self.body, textvariable=self.dict_status, foreground=MUTED).pack(anchor="w", pady=(10, 0))

    def start_dictation_setup(self):
        if self.dict_busy:
            return
        self.dict_busy = True
        self.setup_btn.state(["disabled"])
        self.back_btn.state(["disabled"])
        self.next_btn.state(["disabled"])
        self.dict_status.set("Setting up…")
        self.dict_bar.pack(fill="x", pady=(8, 0))
        self.dict_bar.start(15)
        q, key = self.dict_q, self.dict_key

        def progress(done, total):
            q.put(("progress", done, total))

        def work():
            try:
                recorder = setup_dictation(key, lambda line: q.put(("say", line)), progress, self.dict_stop.is_set)
                q.put(("done", None, recorder))
            except Cancelled:
                q.put(("done", None, None))
            except DictationError as e:
                q.put(("done", str(e), None))
            except Exception as e:  # noqa: BLE001
                log.exception("dictation setup failed (first-run wizard)")
                q.put(("done", f"Something went wrong: {e}\n\nDetails are in {DICTATION_LOG}", None))
        threading.Thread(target=work, daemon=True).start()
        self.after(100, self.poll_dictation)

    def poll_dictation(self):
        if not self.winfo_exists():
            return
        try:
            while True:
                msg = self.dict_q.get_nowait()
                if msg[0] == "say":
                    self.dict_status.set(msg[1])
                elif msg[0] == "progress":
                    done, total = msg[1], msg[2]
                    if str(self.dict_bar.cget("mode")) != "determinate":
                        self.dict_bar.stop()
                        self.dict_bar.config(mode="determinate")
                    self.dict_bar.config(value=100 * done / max(1, total))
                elif msg[0] == "done":
                    problem = msg[1]
                    self.dict_busy = False
                    self.dict_bar.stop()
                    self.back_btn.state(["!disabled"])
                    self.next_btn.state(["!disabled"])
                    self.dict_status.set(problem if problem else "Dictation is ready.")
                    return
        except queue.Empty:
            pass
        if self.dict_busy:
            self.after(100, self.poll_dictation)

    # ---- tour

    def page_tour(self):
        ttk.Label(self.body, text="You're ready to go", font=("TkDefaultFont", 14, "bold")).pack(anchor="w")
        for head, rest in [("Click a button", "to type what it says, or run what it does."),
                           ("Edit buttons", "add, rename or reorganise your buttons and groups."),
                           ("Settings", "dictation, backups, your data folder and more."),
                           ("Back up… / Restore…", "save a dated copy, or bring one back.")]:
            row = ttk.Frame(self.body)
            row.pack(fill="x", pady=4, anchor="w")
            ttk.Label(row, text=head, font=("TkDefaultFont", 10, "bold")).pack(side="left")
            ttk.Label(row, text=" " + rest, foreground=MUTED).pack(side="left")
        ttk.Label(self.body, text="Everything here (dictation, your data folder) can be changed again any time in "
                                  "Settings.", foreground=MUTED, wraplength=480, justify="left",
                  padding=(0, 14, 0, 0)).pack(anchor="w")


def setup_dictation_cli():
    """`quickpad --setup-dictation`: the installers run this so dictation is ready on first launch. Uses the model
    chosen in Settings if there is one, otherwise the one suggested for this computer."""
    settings = {}
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            settings = json.load(f).get("settings", {})
    except (OSError, ValueError):
        pass
    key = chosen_model(settings)
    print(describe_machine(machine_info()))
    print(f"Speech model: {model_info(key)['name']}")
    last = [-1]

    def progress(done, total):
        pct = int(100 * done / max(1, total))
        if pct >= last[0] + 10:
            last[0] = pct
            print(f"  {pct}%", flush=True)
    try:
        setup_dictation(key, say=lambda line: print(line, flush=True), progress=progress)
    except DictationError as e:
        print(f"\nDictation wasn't set up: {e}\nQuickpad works without it; try again later from Settings > Dictation.")
        return 1
    return 0


def main():
    if "--setup-dictation" in sys.argv:
        sys.exit(setup_dictation_cli())
    setup_logging()
    inst = SingleInstance()
    if "--restart" in sys.argv:
        inst.wait_until_free()
    if inst.already_running():
        return                                   # the copy that's already open was asked to come to the front
    holder = {}
    if not inst.claim(lambda: holder["panel"].post(holder["panel"].bring_to_front) if "panel" in holder else None) \
            and inst.duplicate:
        return                                   # another copy started at the same moment and won
    panel = holder["panel"] = Panel()
    panel.instance = inst
    if "--child" in sys.argv:                    # being watched after an update: the panel is up, so it did start
        try:
            with open(STARTED_PATH, "w", encoding="utf-8") as f:
                f.write("ok")
        except OSError:
            pass
    panel.run()


if __name__ == "__main__":
    main()

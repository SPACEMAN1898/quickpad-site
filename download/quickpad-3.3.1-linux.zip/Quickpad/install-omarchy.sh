#!/usr/bin/env bash
# Quickpad installer for Omarchy (Arch + Hyprland).
# Usage: ./install-omarchy.sh [--no-dictation]
set -e
cd "$(dirname "$0")"

sudo pacman -S --needed --noconfirm python tk wtype portaudio alsa-utils   # the last two: dictation's microphone

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
install -m 755 quickpad.py "$HOME/.local/bin/quickpad"

cat > "$HOME/.local/share/applications/quickpad.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Quickpad
Comment=Button panel that types text and keystrokes
Exec=$HOME/.local/bin/quickpad
Icon=accessories-text-editor
StartupWMClass=Quickpad
Terminal=false
Categories=Utility;
EOF

# Make the panel float and stay pinned across workspaces instead of being tiled.
HYPR_DIR="$HOME/.config/hypr"
RULES="$HYPR_DIR/quickpad.conf"
mkdir -p "$HYPR_DIR"
cat > "$RULES" <<'EOF'
# Quickpad window rules
windowrulev2 = float, title:^(Quickpad)$
windowrulev2 = pin, title:^(Quickpad)$
windowrulev2 = size 340 620, title:^(Quickpad)$
windowrulev2 = move 100%-360 60, title:^(Quickpad)$
windowrulev2 = float, title:^(Quickpad — .*)$
EOF

if ! grep -q "quickpad.conf" "$HYPR_DIR/hyprland.conf" 2>/dev/null; then
  echo "source = $RULES" >> "$HYPR_DIR/hyprland.conf"
fi
hyprctl reload >/dev/null 2>&1 || true

if [[ " $* " != *" --no-dictation "* ]]; then
  echo "Setting up dictation (a few minutes; needs the internet)…"
  "$HOME/.local/bin/quickpad" --setup-dictation || echo "Dictation can be set up later in Settings > Dictation."
fi

echo "Installed. Launch with: quickpad  (or from the app launcher)"
echo "Tip: bind it to a key in hyprland.conf, e.g.  bind = SUPER SHIFT, Q, exec, quickpad"

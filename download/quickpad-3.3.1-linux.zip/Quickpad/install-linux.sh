#!/usr/bin/env bash
# Quickpad installer for any Linux distro. Detects the package manager and session type.
# Usage: ./install-linux.sh [--autostart] [--no-dictation]
set -e
cd "$(dirname "$0")"

WAYLAND=0
if [ -n "$HYPRLAND_INSTANCE_SIGNATURE" ] || [ "$XDG_SESSION_TYPE" = "wayland" ]; then WAYLAND=1; fi
TOOL=xdotool; [ "$WAYLAND" = 1 ] && TOOL=wtype

# The extra packages on each line are for dictation: a private Python space for its engine, and the microphone.
if   command -v apt    >/dev/null; then sudo apt install -y python3-tk "$TOOL" python3-venv libportaudio2 alsa-utils
elif command -v pacman >/dev/null; then sudo pacman -S --needed --noconfirm python tk "$TOOL" portaudio alsa-utils
elif command -v dnf    >/dev/null; then sudo dnf install -y python3-tkinter "$TOOL" portaudio alsa-utils
elif command -v zypper >/dev/null; then sudo zypper install -y python3-tk "$TOOL" portaudio alsa-utils
else echo "Install python3 with tkinter and $TOOL using your package manager, then re-run."; exit 1
fi

if [ -n "$HYPRLAND_INSTANCE_SIGNATURE" ] && [ -f install-omarchy.sh ]; then
  exec bash install-omarchy.sh "$@"
fi

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
install -m 755 quickpad.py "$HOME/.local/bin/quickpad"

cat > "$HOME/.local/share/applications/quickpad.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Quickpad
Comment=Button panel that types text and keystrokes
Exec=$HOME/.local/bin/quickpad
Icon=accessories-text-editor
StartupWMClass=Quickpad
Terminal=false
Categories=Utility;
EOF

if [[ " $* " == *" --autostart "* ]]; then
  mkdir -p "$HOME/.config/autostart"
  cp "$HOME/.local/share/applications/quickpad.desktop" "$HOME/.config/autostart/"
fi

[ "$XDG_CURRENT_DESKTOP" = "GNOME" ] && [ "$WAYLAND" = 1 ] && \
  echo "Note: GNOME on Wayland blocks simulated typing. Use the 'GNOME on Xorg' session for Quickpad."

if [[ " $* " != *" --no-dictation "* ]]; then
  echo "Setting up dictation (a few minutes; needs the internet)…"
  "$HOME/.local/bin/quickpad" --setup-dictation || echo "Dictation can be set up later in Settings > Dictation."
fi

echo "Installed. Launch with: quickpad"

Quickpad for Mac — install in a minute
=========================================

1. Unzip this folder if you haven't already (double-click the .zip in
   Finder).

2. Right-click install-mac.command and choose "Open" — do NOT just
   double-click it the first time. macOS blocks apps it doesn't
   recognise from opening by a plain double-click; right-click > Open
   is the correct way past that, the first time only.

3. A dialog appears warning it's from an unidentified developer — click
   "Open" again to confirm.

4. A Terminal window opens and installs Quickpad. This is normal —
   leave it alone until it says "Installed to ~/Applications/Quickpad.app".

5. macOS will ask for two permissions while this runs — say yes to both:
     - Accessibility: so Quickpad can type for you in other programs.
       (System Settings > Privacy & Security > Accessibility: turn
       Quickpad on if it doesn't ask automatically.)
     - Microphone: only needed if you use Dictate buttons.
   Note: because of how Quickpad currently runs on Mac, these
   permissions may show up labelled "Python" rather than "Quickpad" in
   System Settings — that's expected for now; it's the same app.

6. Quickpad opens on its own once installed, from ~/Applications.

Where are the Settings?
   Settings is a button inside the Quickpad panel itself — the small
   floating window with your buttons on it. Look at the top: Edit
   buttons, Settings, Back up…, Restore….

Problems? Email Nick.

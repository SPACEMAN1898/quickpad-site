Quickpad for Windows — install in a minute
============================================

1. Unzip this folder if you haven't already (right-click the .zip > Extract All).

2. Double-click install-windows.bat.

3. Windows will very likely show a blue "Windows protected your PC" screen.
   This is normal for a small app like Quickpad that isn't yet registered
   with Microsoft — it does NOT mean anything is wrong.
     - Click "More info"
     - Click "Run anyway"
   You do NOT need to "Run as administrator" — that's not required and
   skips past a different (unrelated) prompt, not this one.

4. A black Command Prompt window opens and does the install. This is
   normal — leave it alone until it says "Installed."

5. First time only: if Python isn't already on your computer, the script
   installs it for you (no admin needed), then asks you to close the
   window and double-click install-windows.bat again to finish.

6. Quickpad opens on its own once installed. Next time, find "Quickpad"
   in the Start menu.

Where are the Settings?
   Settings is a button inside the Quickpad panel itself — it's the small
   floating window with your buttons on it. Look at the top: there are
   four buttons in a 2x2 layout — Edit buttons, Settings, Back up…,
   Restore…. If the panel looks very narrow and these are cut off, drag
   the bottom-right corner of the panel outward to make it wider.

Problems? Email Nick.

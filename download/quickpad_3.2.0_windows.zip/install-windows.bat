@echo off
REM Quickpad installer for Windows. Double-click to run.
setlocal
cd /d "%~dp0"

where pythonw >nul 2>nul
if errorlevel 1 (
  echo Python isn't installed. Installing it with winget ^(just for your account, no admin needed^)...
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  echo.
  echo Python installed. Close this window and double-click install-windows.bat again.
  pause
  exit /b
)

set "DEST=%APPDATA%\Quickpad"
if not exist "%DEST%" mkdir "%DEST%"
copy /y quickpad.py "%DEST%\quickpad.pyw" >nul
if exist assets\Quickpad.ico copy /y assets\Quickpad.ico "%DEST%\Quickpad.ico" >nul

for /f "delims=" %%P in ('where pythonw') do set "PYW=%%P" & goto found
:found
for /f "delims=" %%P in ('where python') do set "PYC=%%P" & goto foundc
:foundc

powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Programs')+'\Quickpad.lnk');" ^
  "$s.TargetPath='%PYW%'; $s.Arguments='\"%DEST%\quickpad.pyw\"'; $s.WorkingDirectory='%DEST%';" ^
  "if (Test-Path '%DEST%\Quickpad.ico') { $s.IconLocation='%DEST%\Quickpad.ico' }; $s.Save()"

if /i "%1"=="--autostart" (
  copy /y "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Quickpad.lnk" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\" >nul
  echo Quickpad will start on login.
)

if /i not "%1"=="--no-dictation" if /i not "%2"=="--no-dictation" (
  echo.
  echo Setting up dictation ^(a few minutes; needs the internet^)...
  "%PYC%" "%DEST%\quickpad.pyw" --setup-dictation || echo Dictation can be set up later in Settings ^> Dictation.
  echo If Windows asks, let Python use the microphone ^(Settings ^> Privacy ^> Microphone ^> desktop apps^).
)

echo Installed. Find "Quickpad" in the Start menu.
start "" "%PYW%" "%DEST%\quickpad.pyw"
